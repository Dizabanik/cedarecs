#ifndef CEDARECS_HELPERS_H
#define CEDARECS_HELPERS_H

// Compatibility include: all C11 conveniences now live in cedar.h.
#include <cedarecs/cedar.h>

#endif

