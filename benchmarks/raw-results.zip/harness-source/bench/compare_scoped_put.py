#!/usr/bin/env python3
"""Complete paired scoped-put measurements; retain every sample and failure."""
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import statistics
import subprocess

ROOT = Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--baseline', type=Path, required=True)
    parser.add_argument('--candidate', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--repeats', type=int, default=16)
    args = parser.parse_args()
    assert args.repeats >= 16 and args.repeats % 16 == 0
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    binaries = {}
    for key, source, letter in [('baseline', args.baseline, 'a'), ('candidate', args.candidate, 'b')]:
        binaries[key] = out / ('engine-' + letter)
        shutil.copy2(source, binaries[key])
    shutil.copy2(__file__, out / 'runner.py')
    shutil.copy2(ROOT / 'bench/scoped_put.cpp', out / 'scoped_put.cpp')
    meta = dict(started_utc=datetime.now(timezone.utc).isoformat(), repeats=args.repeats,
                binary_sha256={k: sha(v) for k, v in binaries.items()},
                workload_sha256=sha(out / 'scoped_put.cpp'),
                method='Complete 16-case sweep; equal-length executable paths, eight crossed environment paddings, alternating AB/BA; all samples retained. Full payload verification after every measured loop. No timer pauses inside loops.')
    (out / 'metadata.json').write_text(json.dumps(meta, indent=2) + '\n')
    raw = []
    for trial in range(args.repeats):
        for size in (8, 48, 256, 512):
            for count in (1024, 65536):
                for mode in ('present', 'cycle'):
                    # Fixed equal operation count, not calibration per engine.
                    passes = max(1, 2097152 // count)
                    order = ('baseline', 'candidate') if trial % 2 else ('candidate', 'baseline')
                    for position, key in enumerate(order):
                        env = dict(os.environ, CEDAR_BENCH_STACK_PAD='x' * ((trial // 2) % 8) * 16)
                        result = subprocess.run([str(binaries[key]), str(size), str(count), str(passes), mode],
                                                env=env, capture_output=True, text=True, check=True, timeout=60)
                        row = json.loads(result.stdout)
                        assert (row['bytes'], row['entities'], row['passes'], row['cycle']) == (size, count, passes, mode == 'cycle')
                        assert row['ns_per_op'] > 0
                        row.update(which=key, trial=trial, position=position, mode=mode)
                        raw.append(row)
                        with (out / 'raw.jsonl').open('a') as f:
                            f.write(json.dumps(row) + '\n')
        print(f'{trial + 1}/{args.repeats}: all 16 cases verified', flush=True)
    summary = []
    for size in (8, 48, 256, 512):
        for count in (1024, 65536):
            for mode in ('present', 'cycle'):
                samples = [x for x in raw if (x['bytes'], x['entities'], x['mode']) == (size, count, mode)]
                assert len({x['checksum'] for x in samples}) == 1
                row = dict(bytes=size, entities=count, mode=mode)
                for key in binaries:
                    values = [x['ns_per_op'] for x in samples if x['which'] == key]
                    assert len(values) == args.repeats
                    q = statistics.quantiles(values, n=4, method='inclusive')
                    row[key + '_median_ns'] = statistics.median(values)
                    row[key + '_p25_ns'], row[key + '_p75_ns'] = q[0], q[2]
                row['candidate_over_baseline'] = row['candidate_median_ns'] / row['baseline_median_ns']
                row['within_4_percent'] = row['candidate_over_baseline'] <= 1.04
                summary.append(row)
    with (out / 'summary.csv').open('w', newline='') as f:
        writer = csv.DictWriter(f, list(summary[0]))
        writer.writeheader()
        writer.writerows(summary)
    meta.update(completed_utc=datetime.now(timezone.utc).isoformat(), cases=len(summary),
                samples=len(raw), regressions=[r for r in summary if not r['within_4_percent']])
    (out / 'metadata.json').write_text(json.dumps(meta, indent=2) + '\n')
    print(f"Completed {len(summary)} cases; {len(meta['regressions'])} exceed 4%.")


if __name__ == '__main__':
    main()
