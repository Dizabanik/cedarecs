#!/usr/bin/env python3
"""Additive harness: same frozen workloads/kernels, raw monotonic timer on macOS."""
import argparse
import hashlib
import json
from pathlib import Path
import platform
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--baseline-label', required=True)
    p.add_argument('--candidate-label', required=True)
    p.add_argument('--baseline-dependency-root', type=Path,
                   help='Preserved root containing kama/ for snapshots predating dependency capture')
    p.add_argument('--max-expanded-iterations', type=int, default=10000,
                   help='Bounded iteration limit in the shared generated harness; frozen main.c stays unchanged')
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    assert 10000 <= args.max_expanded_iterations <= 20000000
    assert platform.system() == 'Darwin', 'This additive timer diagnostic targets macOS'
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    flags = ['clang', '-std=c11', '-D_POSIX_C_SOURCE=200809L', '-D_DARWIN_C_SOURCE', '-pthread',
             '-O3', '-DNDEBUG', '-march=native', '-Wall', '-Wextra']
    commands, clocks, kernels = [], {}, {}
    shared = out / 'shared'
    shared.mkdir()
    for suite, folder in [('original', 'bench'), ('expanded', 'bench/expanded')]:
        source = ROOT / folder / 'main.c'
        text = source.read_text()
        old, new = 'clock_gettime(CLOCK_MONOTONIC,', 'clock_gettime(CLOCK_MONOTONIC_RAW,'
        assert text.count(old) == 1
        generated = shared / (suite + '-main.c')
        modified = text.replace(old, new)
        edits = ['CLOCK_MONOTONIC -> CLOCK_MONOTONIC_RAW']
        if suite == 'expanded' and args.max_expanded_iterations != 10000:
            assert modified.count('c.iterations <= 10000)') == 1
            modified = modified.replace('c.iterations <= 10000)',
                                        f'c.iterations <= {args.max_expanded_iterations})')
            edits.append(f'bounded iteration limit 10000 -> {args.max_expanded_iterations}')
        generated.write_text(modified)
        restored = generated.read_text().replace(new, old)
        if suite == 'expanded':
            restored = restored.replace(f'c.iterations <= {args.max_expanded_iterations})',
                                        'c.iterations <= 10000)')
        assert restored == text
        target = shared / (suite + '-main.o')
        command = flags + ['-I' + str(ROOT / folder), '-c', str(generated), '-o', str(target)]
        subprocess.run(command, check=True)
        commands.append(command)
        clocks[suite] = dict(original_sha256=sha(source), generated_sha256=sha(generated),
                             object_sha256=sha(target), edits=edits)
        if suite == 'expanded':
            clocks[suite]['max_iterations'] = args.max_expanded_iterations
        kernel = ROOT / ('build/bench/kernel.o' if suite == 'original' else 'build/expanded/kernels.o')
        shutil.copy2(kernel, shared / (suite + '-kernel.o'))
        kernels[suite] = sha(kernel)
    for key, label in [('baseline', args.baseline_label), ('candidate', args.candidate_label)]:
        snapshot = ROOT / 'variants' / label
        provenance = json.loads((snapshot / 'provenance.json').read_text())
        engine = provenance['cedarecs']
        assert engine['label'] == label
        for name, digest in engine['files'].items():
            assert sha(snapshot / name) == digest, name
        dest = out / key
        dest.mkdir()
        dependency = (args.baseline_dependency_root.resolve() if key == 'baseline' and args.baseline_dependency_root
                      else snapshot if (snapshot / 'kama/kama.h').is_file() else ROOT)
        assert sha(dependency / 'kama/kama.h') == provenance['kama']['header_sha256'], 'Dependency pin mismatch'
        includes = ['-I' + str(dependency), '-I' + str(snapshot), '-I' + str(ROOT), '-I' + str(ROOT / 'bench')]
        objects = []
        for source in [*sorted((snapshot / 'cedarecs/ecs').glob('*.c')), snapshot / 'cedarecs/wexds.c']:
            obj = dest / (source.stem + '.o')
            command = flags + includes + ['-c', str(source), '-o', str(obj)]
            subprocess.run(command, check=True)
            commands.append(command)
            objects.append(obj)
        for suite in ('original', 'packed', 'indexed'):
            expanded = suite != 'original'
            backend = snapshot / ('expanded/cedar.c' if expanded else 'cedar_backend.c')
            current = ROOT / ('bench/expanded/cedar.c' if expanded else 'bench/cedar_backend.c')
            assert sha(backend) == sha(current), 'Backend differs between snapshots'
            obj = dest / (suite + '-backend.o')
            command = flags + includes + ['-I' + str(ROOT / 'bench/expanded'),
                '-DCEDAR_SNAPSHOT="' + engine['snapshot_sha256'] + '"']
            if suite == 'indexed':
                command += ['-DCEDAR_INDEXED_STORAGE']
            command += ['-c', str(backend), '-o', str(obj)]
            subprocess.run(command, check=True)
            commands.append(command)
            shared_suite = 'expanded' if expanded else 'original'
            inputs = [shared / (shared_suite + '-main.o'), shared / (shared_suite + '-kernel.o'), obj, *objects]
            command = flags + list(map(str, inputs)) + ['-lm', '-o', str(dest / suite)]
            subprocess.run(command, check=True)
            commands.append(command)
        (dest / 'manifest.json').write_text(json.dumps(dict(engine=engine, kama=provenance['kama'],
            binaries={s: sha(dest / s) for s in ('original', 'packed', 'indexed')},
            timer='CLOCK_MONOTONIC_RAW', shared_clocks=clocks, shared_kernels=kernels), indent=2) + '\n')
    shutil.copy2(__file__, out / 'build.py')
    (out / 'build.json').write_text(json.dumps(dict(commands=commands, shared_clocks=clocks,
        shared_kernels=kernels, compiler=subprocess.check_output(['clang', '--version'], text=True)), indent=2) + '\n')


if __name__ == '__main__':
    main()
