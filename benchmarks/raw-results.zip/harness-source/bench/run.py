#!/usr/bin/env python3
"""Run independent, serialized process samples and retain all measurements."""
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import random
import statistics
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
ENGINES = ("cedarecs", "flecs")
BINARY_DIR = ROOT / "build"
SERIAL = ("create_empty", "create_pv", "iterate", "iterate_fragmented", "random_get",
          "write_existing", "set_existing", "add_remove", "defer_add_remove", "delete_pv")
SINGLE_PASS = {"create_empty", "create_pv", "delete_pv"}


def command(args, **kwargs):
    return subprocess.check_output(args, text=True, cwd=ROOT, **kwargs).strip()


def verify_sources():
    manifest = json.loads((ROOT / "provenance.json").read_text())
    actual = {}
    for path in sorted((ROOT / "cedarecs").rglob("*")):
        if path.is_file() and '.git' not in path.relative_to(ROOT/'cedarecs').parts:
            actual[str(path.relative_to(ROOT))] = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != manifest["cedarecs"]["files"]:
        raise RuntimeError("Cedar snapshot differs from provenance.json; record a new variant before measuring")
    if hashlib.sha256((ROOT / "kama/kama.h").read_bytes()).hexdigest() != manifest["kama"]["header_sha256"]:
        raise RuntimeError("Kama header differs from the pinned snapshot")
    if command(["git", "-C", "flecs", "rev-parse", "HEAD"]) != manifest["flecs"]["commit"]:
        raise RuntimeError("Flecs checkout differs from the pinned revision")
    if command(["git", "-C", "flecs", "status", "--porcelain"]):
        raise RuntimeError("Flecs checkout is modified")
    return manifest


def execute(engine, scenario, n, iterations, threads):
    proc = subprocess.run([str(BINARY_DIR / f"bench_{engine}"), scenario,
                           str(n), str(iterations), str(threads)], cwd=ROOT,
                          text=True, capture_output=True, timeout=180,
                          env={**os.environ, "LC_ALL": "C"})
    if proc.returncode:
        raise RuntimeError(f"{engine} {scenario} n={n} iterations={iterations} threads={threads}\n"
                           f"exit={proc.returncode}\n{proc.stdout}\n{proc.stderr}")
    result = json.loads(proc.stdout)
    if proc.stderr:
        raise RuntimeError(f"Unexpected benchmark diagnostics: {proc.stderr}")
    return result


def parity(pair):
    fields = ("scenario", "entities", "iterations", "threads", "operations", "archetypes", "checksum")
    for field in fields:
        if pair[0][field] != pair[1][field]:
            raise RuntimeError(f"Cross-library correctness mismatch in {field}: {pair}")


def percentile(values, fraction):
    ordered = sorted(values)
    position = (len(ordered) - 1) * fraction
    low = math.floor(position)
    return ordered[low] + (ordered[math.ceil(position)] - ordered[low]) * (position - low)


def system_info():
    def sysctl(name):
        try:
            return command(["sysctl", "-n", name])
        except subprocess.CalledProcessError:
            return None
    return {"platform": platform.platform(), "machine": platform.machine(),
            "cpu": sysctl("machdep.cpu.brand_string") if sys.platform == "darwin" else platform.processor(),
            "logical_cpus": os.cpu_count(), "memory_bytes": sysctl("hw.memsize") if sys.platform == "darwin" else None,
            "performance_cores": sysctl("hw.perflevel0.logicalcpu") if sys.platform == "darwin" else None,
            "efficiency_cores": sysctl("hw.perflevel1.logicalcpu") if sys.platform == "darwin" else None,
            "compiler": command(["clang", "--version"]),
            "macos_qos": "QOS_CLASS_USER_INITIATED" if sys.platform == "darwin" else None}


def smoke():
    count = 0
    for n in (1, 1031):
        for scenario, threads in [(s, 1) for s in SERIAL] + [(s, t) for s in ("frame_light", "frame_heavy") for t in (1, 2, 4)]:
            iterations = 1 if scenario in SINGLE_PASS else 3
            pair = [execute(e, scenario, n, iterations, threads) for e in ENGINES]
            parity(pair)
            count += 1
    print(f"Correctness smoke passed: {count} workload/size/thread combinations, both libraries", flush=True)


def write_summary(destination, records, metadata):
    grouped = {}
    for row in records:
        key = (row["scenario"], row["entities"], row["threads"])
        grouped.setdefault(key, {}).setdefault(row["engine"], []).append(row)
    summaries = []
    for (scenario, n, threads), engines in grouped.items():
        row = {"scenario": scenario, "entities": n, "threads": threads,
               "iterations": engines["cedarecs"][0]["iterations"], "samples_per_engine": len(engines["cedarecs"])}
        for engine, samples in engines.items():
            ns = [s["ns_per_op"] for s in samples]
            row[f"{engine}_median_ns"] = statistics.median(ns)
            row[f"{engine}_min_ns"] = min(ns)
            row[f"{engine}_max_ns"] = max(ns)
            row[f"{engine}_p25_ns"] = percentile(ns, .25)
            row[f"{engine}_p75_ns"] = percentile(ns, .75)
            row[f"{engine}_median_peak_rss_mib"] = statistics.median(s["peak_rss_bytes"] for s in samples) / 1048576
        row["flecs_over_cedar"] = row["flecs_median_ns"] / row["cedarecs_median_ns"]
        summaries.append(row)
    with (destination / "summary.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, list(summaries[0]))
        writer.writeheader(); writer.writerows(summaries)
    lines = ["# Cedar ECS versus Flecs", "", f"Run started: {metadata['started_utc']}.",
             f"Host: {metadata['system']['cpu']}; {metadata['system']['logical_cpus']} logical CPUs; {metadata['system']['platform']}.", "",
             "Median ns per operation; lower is better. `Flecs / Cedar` above 1 favors Cedar; below 1 favors Flecs.",
             "Creation/deletion: one entity. Iteration/frame: one entity-update. Mutations: one add/set or one removal.",
             "Native frame measurements include different scheduling/merge APIs; see README.md for scope and interpretation.", "",
             "| Scenario | Entities | Threads | Cedar ns/op | Flecs ns/op | Flecs / Cedar |",
             "| --- | ---: | ---: | ---: | ---: | ---: |"]
    for r in summaries:
        lines.append(f"| {r['scenario']} | {r['entities']:,} | {r['threads']} | {r['cedarecs_median_ns']:.3f} | {r['flecs_median_ns']:.3f} | {r['flecs_over_cedar']:.2f} |")
    lines += ["", "The CSV includes interquartile ranges, min/max, and process peak RSS. Raw samples include checksums and exact operation counts.",
              "These are synthetic workloads on one machine, not a feature-complete or universal ranking.", ""]
    (destination / "comparison.md").write_text("\n".join(lines))
    return summaries


def main():
    global BINARY_DIR
    parser = argparse.ArgumentParser()
    parser.add_argument("--smoke", action="store_true")
    parser.add_argument("--binary-dir", type=Path, default=ROOT / "build")
    parser.add_argument("--sizes", default="10000,100000,1000000")
    parser.add_argument("--threads", default="1,2,4,8,14")
    parser.add_argument("--repeats", type=int, default=9)
    parser.add_argument("--warmups", type=int, default=2)
    parser.add_argument("--target-ms", type=float, default=60)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    BINARY_DIR = args.binary_dir if args.binary_dir.is_absolute() else ROOT / args.binary_dir
    provenance = verify_sources()
    if args.smoke:
        smoke(); return
    sizes = [int(x) for x in args.sizes.split(",")]
    threads = [int(x) for x in args.threads.split(",")]
    if args.repeats < 3 or args.warmups < 1 or args.target_ms <= 0 or not all(0 < n <= 10000000 for n in sizes) or not all(0 < t <= 256 for t in threads):
        parser.error("Invalid sizes, repeats, warmups, threads, or target duration")
    started = datetime.now(timezone.utc)
    output = args.output or ROOT / "results" / started.strftime("%Y%m%dT%H%M%SZ")
    if not output.is_absolute(): output = ROOT / output
    output.mkdir(parents=True, exist_ok=False)
    source_hashes = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT / "bench").rglob("*")) if p.is_file() and "__pycache__" not in str(p)}
    metadata = {"started_utc": started.isoformat(), "system": system_info(), "provenance": provenance,
                "repeats": args.repeats, "discarded_warmup_processes": args.warmups,
                "target_ms": args.target_ms, "sizes": sizes, "threads": threads,
                "build_flags": "-std=c11 -D_POSIX_C_SOURCE=200809L -D_DARWIN_C_SOURCE -pthread -O3 -DNDEBUG -march=native",
                "flecs_flags": "FLECS_CUSTOM_BUILD FLECS_SYSTEM FLECS_PIPELINE FLECS_OS_API_IMPL",
                "harness_sha256": source_hashes,
                "binaries_sha256": {e: hashlib.sha256((BINARY_DIR / f"bench_{e}").read_bytes()).hexdigest() for e in ENGINES},
                "kernel_object_sha256": hashlib.sha256((ROOT / "build/bench/kernel.o").read_bytes()).hexdigest(),
                "makefile": (ROOT / "Makefile").read_text(), "execution": "one process at a time; alternating engine order per trial; deterministic job shuffle",
                "warmup": "5 untimed update passes/frames per query/frame sample; one untimed mutation cycle; pre-read random access"}
    (output / "metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")
    jobs = [(s, n, 1) for n in sizes for s in SERIAL]
    jobs += [(s, n, t) for n in sizes if n >= 100000 for s in ("frame_light", "frame_heavy") for t in threads]
    random.Random(0xCEDA).shuffle(jobs)
    records, calibration = [], []
    start_time = time.monotonic()
    with (output / "raw.jsonl").open("w") as raw:
        for job_index, (scenario, n, thread_count) in enumerate(jobs):
            estimated = [execute(e, scenario, n, 1, thread_count) for e in ENGINES]
            parity(estimated)
            calibration += estimated
            if scenario in SINGLE_PASS: iterations = 1
            else:
                fastest = min(r["elapsed_ns"] for r in estimated)
                iterations = max(1, min(100000, 50000000 // n, math.ceil(args.target_ms * 1e6 / fastest)))
            checksums = set()
            for trial in range(-args.warmups, args.repeats):
                order = ENGINES if (job_index + trial) % 2 == 0 else ENGINES[::-1]
                pair = []
                for order_index, engine in enumerate(order):
                    row = execute(engine, scenario, n, iterations, thread_count)
                    row.update(trial=trial, order_index=order_index)
                    pair.append(row)
                    if trial >= 0:
                        records.append(row)
                        raw.write(json.dumps(row) + "\n"); raw.flush()
                parity(pair)
                checksums.add(pair[0]["checksum"])
            if len(checksums) != 1:
                raise RuntimeError(f"Run-to-run checksum mismatch: {scenario}, {n}, {thread_count}")
            samples = [r for r in records if (r["scenario"], r["entities"], r["threads"]) == (scenario, n, thread_count)]
            medians = {e: statistics.median(r["ns_per_op"] for r in samples if r["engine"] == e) for e in ENGINES}
            print(f"[{job_index+1}/{len(jobs)}] {scenario:20s} N={n:7d} T={thread_count:2d} I={iterations:5d} "
                  f"Cedar={medians['cedarecs']:.3f} Flecs={medians['flecs']:.3f} ns/op "
                  f"({time.monotonic()-start_time:.0f}s)", flush=True)
    (output / "calibration.json").write_text(json.dumps(calibration, indent=2) + "\n")
    metadata["completed_utc"] = datetime.now(timezone.utc).isoformat()
    metadata["wall_seconds"] = time.monotonic() - start_time
    (output / "metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")
    write_summary(output, records, metadata)
    print(f"Results: {output}", flush=True)

if __name__ == "__main__":
    main()
