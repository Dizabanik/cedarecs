"""Link both C engines with the same additive raw-clock harness and kernels."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser()
parser.add_argument('--build-root',type=Path,default=ROOT/'build/kama-v107-paired')
args=parser.parse_args()
OUT=args.build_root.resolve()
dest=OUT/'references'; dest.mkdir(exist_ok=False)
flags=['clang','-std=c11','-D_POSIX_C_SOURCE=200809L','-D_DARWIN_C_SOURCE','-pthread',
       '-O3','-DNDEBUG','-march=native','-Wall','-Wextra','-I'+str(ROOT),'-I'+str(ROOT/'bench')]
flecs=['-DFLECS_CUSTOM_BUILD','-DFLECS_SYSTEM','-DFLECS_PIPELINE','-DFLECS_OS_API_IMPL','-I'+str(ROOT/'flecs/distr')]
commands=[]
def run(command):
    subprocess.run(command,check=True); commands.append(command)
run([*flags,*flecs,'-c',str(ROOT/'flecs/distr/flecs.c'),'-o',str(dest/'flecs.o')])
pin=json.loads((ROOT/'provenance.json').read_text())['flecs']['commit']
assert subprocess.check_output(['git','-C',str(ROOT/'flecs'),'rev-parse','HEAD'],text=True).strip()==pin
assert not subprocess.check_output(['git','-C',str(ROOT/'flecs'),'status','--porcelain']).strip()
for suite,backend in [('original',ROOT/'bench/flecs_backend.c'),('expanded',ROOT/'bench/expanded/flecs.c')]:
    obj=dest/(suite+'-backend.o')
    run([*flags,*flecs,'-DFLECS_COMMIT="'+pin+'"','-c',str(backend),'-o',str(obj)])
    run([*flags,str(OUT/'shared'/(suite+'-main.o')),str(OUT/'shared'/(suite+'-kernel.o')),
         str(obj),str(dest/'flecs.o'),'-lm','-o',str(dest/suite)])
shutil.copy2(__file__,dest/'build.py')
(dest/'build.json').write_text(json.dumps(dict(commands=commands,pin=pin,
    source_sha256={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
                   for p in [ROOT/'flecs/distr/flecs.c',ROOT/'flecs/distr/flecs.h',
                             ROOT/'bench/flecs_backend.c',ROOT/'bench/expanded/flecs.c']},
    binaries={s:hashlib.sha256((dest/s).read_bytes()).hexdigest() for s in ('original','expanded')}),indent=2)+'\n')
