#!/usr/bin/env python3
"""Audit fixed workloads, stored sources, final binaries and indexed results."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, shutil
ROOT=Path(__file__).resolve().parents[1]
VALID=ROOT/'validation/indexed-v25'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def meta(run):return json.loads((ROOT/'results'/run/'metadata.json').read_text())
manifest=json.loads((ROOT/'provenance.json').read_text())
assert manifest['cedarecs']['label']=='indexed-v25'
for path,h in manifest['cedarecs']['files'].items():assert digest(ROOT/path)==h,path
baseline=ROOT/'variants/baseline'
for p in (baseline/'cedarecs').rglob('*'):
    if p.is_file():assert p.read_bytes()==(ROOT.parent/'include/cedarecs'/p.relative_to(baseline/'cedarecs')).read_bytes()
for name in ('workloads.inc','kernel.c','main.c','flecs_backend.c','bench.h'):
    assert (ROOT/'bench'/name).read_bytes()==(baseline/name).read_bytes()
assert digest(ROOT/'kama/kama.h')==manifest['kama']['header_sha256']
assert not subprocess.check_output(['git','-C',str(ROOT/'flecs'),'status','--porcelain'],text=True).strip()
assert subprocess.check_output(['git','-C',str(ROOT/'flecs'),'rev-parse','HEAD'],text=True).strip()==manifest['flecs']['commit']
base=meta('query-access-v16-expanded')
packed=meta('indexed-v25-packed');slots=meta('indexed-v25-slots')
assert packed['cedar_storage']=='archetype' and slots['cedar_storage']=='indexed'
assert packed['cases']==slots['cases']==base['cases']
for m in (packed,slots):
    assert m['binaries_sha256']['flecs']==base['binaries_sha256']['flecs']
    assert m['kernel_object_sha256']==base['kernel_object_sha256']
    for name in ('catalog.py','flecs.c','kernels.c','main.c','suite.h','workloads.inc'):
        p='bench/expanded/'+name
        assert m['harness_sha256'][p]==base['harness_sha256'][p],p
for run in ('indexed-v25-packed','indexed-v25-slots'):
    m=meta(run)
    for name,h in m['harness_sha256'].items():assert digest(ROOT/'results'/run/'source'/name)==h,(run,name)
    binary=ROOT/'build'/('expanded-indexed' if m['cedar_storage']=='indexed' else 'expanded')/'cedarecs'
    assert digest(binary)==m['binaries_sha256']['cedarecs']
    assert ('cedar-storage:'+m['cedar_storage']).encode() in binary.read_bytes()
    subprocess.run(['python3',str(ROOT/'bench/expanded/validate.py'),str(ROOT/'results'/run)],check=True)
subprocess.run(['python3',str(ROOT/'bench/validate_results.py'),str(ROOT/'results/indexed-v25-original')],check=True)
prior=meta('multi-ecs-query-access-v16')
checked=meta('multi-ecs-indexed-initialized-v24')
known=meta('multi-ecs-indexed-known-live-v25')
assert checked['repeats']==known['repeats']==9
assert known['cedar_read_mode']=='known-live'
assert digest(ROOT/'build/interop/cedar-entities')==checked['binary_sha256']['cedar']
assert digest(ROOT/'build/interop/cedar-entities-known-live')==known['binary_sha256']['cedar']
for f in ('entt','pico','flecs'):
    assert prior['binary_sha256'][f]==checked['binary_sha256'][f]==known['binary_sha256'][f]
    assert digest(ROOT/'build/interop'/(f+'-entities'))==known['binary_sha256'][f]
for run in ('multi-ecs-indexed-initialized-v24','multi-ecs-indexed-known-live-v25'):
    m=meta(run)
    for name,h in m['adapter_sha256'].items():assert digest(ROOT/'results'/run/'source'/name)==h,(run,name)
    subprocess.run(['python3',str(ROOT/'interop/abeimler/validate.py'),str(ROOT/'results'/run)],check=True)
# Verify every retained prototype, rather than retaining only favorable trials.
prototypes=[]
for run in sorted((ROOT/'results').glob('multi-ecs-indexed-*')):
    if run.name in ('multi-ecs-indexed-initialized-v24','multi-ecs-indexed-known-live-v25'):continue
    subprocess.run(['python3',str(ROOT/'interop/abeimler/validate.py'),str(run)],check=True)
    m=meta(run.name)
    for name,h in m['adapter_sha256'].items():assert digest(run/'source'/name)==h
    prototypes.append(run.name)
plots=json.loads((ROOT/'results/indexed-v25-packed/indexed-plot-metadata.json').read_text())
for p,h in plots['inputs'].items():assert digest(ROOT/p)==h
for p,h in plots['outputs'].items():assert digest(ROOT/'results/indexed-v25-packed'/p)==h
checks=(VALID/'checks.log').read_text()
assert 'ECS tests passed (archetype and indexed storage)' in checks
assert checks.count('Expanded smoke passed: 374')==4
assert checks.count('Expanded smoke passed: 12')==2
assert 'ASan/UBSan passed: checked' in checks and 'ASan/UBSan passed: known-live' in checks
assert '100% tests passed' in (VALID/'interop.log').read_text()
tests=VALID/'source/tests';tests.mkdir(parents=True,exist_ok=True)
for p in (ROOT/'tests').glob('*'):
    if p.is_file():shutil.copy2(p,tests/p.name)
record=dict(verified_utc=datetime.now(timezone.utc).isoformat(),
    cedar_snapshot=manifest['cedarecs']['snapshot_sha256'],production_equals_initial_baseline=True,
    original_five_common_files_unchanged=True,expanded_timed_workloads_and_case_matrix_unchanged=True,
    shared_kernels_and_all_competing_executables_unchanged=True,
    checked_final_executable_identical_to_measured_v24=True,
    checked_and_known_live_read_contracts_reported_separately=True,
    packed_and_indexed_C_policies_reported_separately=True,
    all_final_results_and_source_archives_audited=True,
    final_C_samples=900+2*6948,final_four_framework_samples=2*1008,
    preserved_prototypes=prototypes,
    checks='Core ASan/UBSan/TSan, 65/320 components, parking-only, queries and workers in both storage modes; expanded release+ASan/UBSan both engines/policies; Cedar TSan worker commands both policies; C++ checked+known-live ASan/UBSan and CTest',
    test_source_sha256={str(p.relative_to(ROOT)):digest(p) for p in (ROOT/'tests').glob('*') if p.is_file()},
    evidence_sha256={p.name:digest(p) for p in VALID.glob('*.log') if p.name!='audit.log'},
    unresolved_diagnostic='Earlier Flecs development native pipeline/query TSan races remain retained separately; no external source edits or suppressions')
(VALID/'verification.json').write_text(json.dumps(record,indent=2)+'\n')
print('Verified manifests, fixed workloads, all competitor binaries, separate contracts/policies, prototypes, plots and retained samples.')
