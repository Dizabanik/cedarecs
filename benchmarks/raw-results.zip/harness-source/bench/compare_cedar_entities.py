#!/usr/bin/env python3
"""Compare an exact checked control with a checked C++ candidate, paired."""
import argparse,csv,hashlib,json,statistics,subprocess,shutil,os
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True)
    p.add_argument('--control-label',default='checked-final-v53',
                   choices=sorted(x.name for x in (ROOT/'build/controls').iterdir() if (x/'manifest.json').is_file()),
                   help='Preserved exact control; defaults to the accepted v53 reference')
    p.add_argument('--repeats',type=int,default=9);p.add_argument('--min-time',type=float,default=.05)
    p.add_argument('--balanced-layout',action='store_true',help='Use equal-length binary/output paths and eight crossed stack paddings')
    p.add_argument('--self-control',action='store_true',help='Run the selected exact control on both sides to measure harness noise')
    args=p.parse_args()
    assert args.repeats>=3
    if args.balanced_layout:assert args.repeats%16==0,'Balanced layout requires complete 16-round cycles'
    controls=ROOT/'build/controls'/args.control_label
    old=json.loads((controls/'manifest.json').read_text());current=json.loads((ROOT/'provenance.json').read_text())['cedarecs']
    for name,digest in current['files'].items():assert sha(ROOT/name)==digest,name
    binaries={'baseline':controls/'entities','candidate':ROOT/'build/interop/cedar-entities'}
    if args.self_control:binaries['candidate']=binaries['baseline']
    assert sha(binaries['baseline'])==old['binaries']['entities']
    versions={'baseline':old['engine']['snapshot_sha256'],'candidate':(old['engine'] if args.self_control else current)['snapshot_sha256']}
    previous={r['benchmark']:r for r in csv.DictReader((ROOT/'results/multi-ecs-checked-final-v53/summary.csv').open())}
    out=args.output.resolve();out.mkdir(parents=True,exist_ok=False);raw=[]
    shutil.copy2(__file__,out/'compare-source.py')
    if args.balanced_layout:
        copies={}
        for which,letter in (('baseline','a'),('candidate','b')):
            target=out/('engine-'+letter)
            shutil.copy2(binaries[which],target);assert sha(target)==sha(binaries[which])
            copies[which]=target
        binaries=copies
    meta=dict(suite='cedar-paired-entities-v1',started_utc=datetime.now(timezone.utc).isoformat(),repeats=args.repeats,min_time=args.min_time,
              binary_sha256={k:sha(v) for k,v in binaries.items()},versions=versions,regression_limit=1.04,
              candidate=old['engine'] if args.self_control else current,active_cedar=current,
              control_label=args.control_label,
              balanced_layout=args.balanced_layout,self_control=args.self_control,
              runner_sha256=sha(Path(__file__)),
              method='Sequential processes, rotating AB/BA each round; same complete 28-case filter, checked contracts and native timing boundaries. Balanced mode copies byte-identical executables to equal-length paths, uses equal-length output names, and crosses eight environment padding lengths with both process orders in each 16-round cycle. No result/variant selection.')
    (out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
    for trial in range(args.repeats):
        order=('baseline','candidate') if trial%2 else ('candidate','baseline')
        for position,which in enumerate(order):
            letter='a' if which=='baseline' else 'b'
            dest=out/(f'{letter}{trial:03}.json' if args.balanced_layout else f'{which}-{trial}.json')
            command=[str(binaries[which]),r'--benchmark_filter=(^BM_CreateNoEntities$|^BM_.*/(1|1024|65536)$)',f'--benchmark_min_time={args.min_time}s','--benchmark_repetitions=1','--benchmark_out_format=json',f'--benchmark_out={dest}']
            environment=dict(os.environ)
            padding=((trial//2)%8)*16 if args.balanced_layout else None
            if padding is not None:environment['CEDAR_BENCH_STACK_PAD']='x'*padding
            with (out/f'{which}-{trial}.log').open('w') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=300,env=environment)
            result=json.loads(dest.read_text());assert result['context']['cedar.read_contract']=='checked'
            assert result['context']['cedar.snapshot']==versions[which]
            assert {r['name'] for r in result['benchmarks']}==set(previous)
            for r in result['benchmarks']:
                assert not r.get('error_occurred') and r['time_unit']=='ns'
                raw.append(dict(which=which,trial=trial,order=position,stack_padding=padding,**r))
            print(f'{trial+1}/{args.repeats} {which}: 28 checked cases',flush=True)
    summary=[]
    for name in sorted(previous):
        row=dict(case=name)
        for counter in ('entities','components_one','components_two','components_three'):
            assert len({r.get(counter,0) for r in raw if r['name']==name})==1
        for which in binaries:
            samples=[r['cpu_time'] for r in raw if r['which']==which and r['name']==name]
            assert len(samples)==args.repeats
            q=statistics.quantiles(samples,n=4,method='inclusive')
            row[which+'_median_ns']=statistics.median(samples);row[which+'_p25_ns']=q[0];row[which+'_p75_ns']=q[2]
        row['candidate_over_baseline']=row['candidate_median_ns']/row['baseline_median_ns']
        row['within_4_percent']=row['candidate_over_baseline']<=1.04
        row['candidate_over_historical']=row['candidate_median_ns']/float(previous[name]['cedar_cpu_median_ns'])
        row['baseline_over_historical']=row['baseline_median_ns']/float(previous[name]['cedar_cpu_median_ns'])
        summary.append(row)
    (out/'raw.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in raw))
    with (out/'summary.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,list(summary[0]));w.writeheader();w.writerows(summary)
    meta.update(completed_utc=datetime.now(timezone.utc).isoformat(),cases=28,samples=len(raw),all_within_4_percent=all(r['within_4_percent'] for r in summary),regressions=[r for r in summary if not r['within_4_percent']])
    (out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
    for r in meta['regressions']:print('FAIL',r['case'],r['candidate_over_baseline'])
    print('Completed 28 cases;',len(meta['regressions']),'exceed the 4% ceiling.')
if __name__=='__main__':main()
