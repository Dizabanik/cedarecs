#!/usr/bin/env python3
"""Shareable figures from every retained v53 case; no selected best runs."""
import csv
import hashlib
import json
import math
from pathlib import Path
import statistics
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm, LinearSegmentedColormap
from matplotlib.patches import FancyBboxPatch
from matplotlib.colors import to_rgb
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'promotion/checked-v53'
BG='#091b18'; PANEL='#112923'; INK='#f3f6ed'; MUTED='#a5b9ae'; MINT='#a8f18b'; ORANGE='#ffb47d'; GRID='#29443b'
COLORS=LinearSegmentedColormap.from_list('cedar',['#a85c3a',PANEL,'#235f44','#8ed272'])
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'text.color':INK,
                     'axes.labelcolor':INK,'xtick.color':MUTED,'ytick.color':INK,
                     'axes.edgecolor':GRID,'svg.fonttype':'none','pdf.fonttype':42})

def read(p):return list(csv.DictReader(p.open()))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def gm(values):return math.exp(statistics.mean(math.log(x) for x in values))
def speed_color(value):
    if value < 1:
        a,b,t=to_rgb('#754830'),to_rgb('#d4864d'),min(1,abs(math.log2(value))/4)
    else:
        a,b,t=to_rgb('#194936'),to_rgb('#a8f18b'),min(1,math.log2(value)/math.log2(75))
    return tuple(x+(y-x)*t for x,y in zip(a,b))
def text(fig,x,y,s,size=12,color=INK,weight='normal',**kw):
    return fig.text(x,y,s,fontsize=size,color=color,fontweight=weight,**kw)
def rect(fig,x,y,w,h,color=PANEL,r=.02):
    fig.patches.append(FancyBboxPatch((x,y),w,h,boxstyle=f'round,pad=0,rounding_size={r}',
                                    facecolor=color,edgecolor='none',transform=fig.transFigure,zorder=-1))
def save(fig,name):
    for ext in ('png','svg','pdf'):
        p=OUT/(name+'.'+ext);fig.savefig(p,dpi=190,facecolor=BG);outputs.append(p)
    plt.close(fig)

OUT.mkdir(parents=True,exist_ok=True)
entity=ROOT/'results/multi-ecs-checked-final-v53'
meta=json.loads((entity/'metadata.json').read_text())
assert meta['cedar_read_mode']=='checked' and meta['repeats']==9
rows=read(entity/'summary.csv');assert len(rows)==28
frameworks=('entt','pico','flecs');names={'entt':'EnTT','pico':'pico_ecs','flecs':'Flecs'}
ratios={f:[float(r[f+'_cpu_median_ns'])/float(r['cedar_cpu_median_ns']) for r in rows] for f in frameworks}
wins={f:sum(x>1 for x in ratios[f]) for f in frameworks}
assert sum(wins.values())==83
outputs=[]
derived=[]
for r in rows:
    for f in frameworks:
        c=float(r['cedar_cpu_median_ns']);other=float(r[f+'_cpu_median_ns'])
        cq=(float(r['cedar_cpu_p25_ns']),float(r['cedar_cpu_p75_ns']))
        oq=(float(r[f+'_cpu_p25_ns']),float(r[f+'_cpu_p75_ns']))
        derived.append(dict(case=r['benchmark'],competitor=f,cedar_cpu_median_ns=c,
                            competitor_cpu_median_ns=other,speedup=other/c,
                            spread='cedar-disjoint-IQR' if cq[1]<oq[0] else ('competitor-disjoint-IQR' if oq[1]<cq[0] else 'overlap')))
p=OUT/'entity-speedups.csv'
with p.open('w',newline='') as out:
    writer=csv.DictWriter(out,list(derived[0]));writer.writeheader();writer.writerows(derived)
outputs.append(p)

# Hero: case scores and full-distribution strips make the large and small wins visible.
fig=plt.figure(figsize=(14,8.8),facecolor=BG)
text(fig,.045,.944,'CEDAR ECS  /  PERFORMANCE SNAPSHOT',12,MINT,'bold')
text(fig,.045,.807,'83',88,MINT,'bold')
text(fig,.225,.827,'/ 84',43,INK,'bold')
text(fig,.39,.858,'A faster way to build worlds.',28,INK,'bold')
text(fig,.39,.805,'Median wins across 28 entity benchmarks × 3 competitors.',12,MUTED)
for i,f in enumerate(frameworks):
    x=.045+i*.31;rect(fig,x,.258,.29,.48)
    text(fig,x+.022,.687,'CEDAR vs '+names[f],14,INK,'bold')
    text(fig,x+.022,.588,f'{wins[f]}/28',42,MINT,'bold')
    text(fig,x+.022,.547,'CASES WON',10,MUTED,'bold')
    text(fig,x+.022,.464,f'{gm(ratios[f]):.2f}×',32,INK,'bold')
    text(fig,x+.022,.424,'geometric mean speedup · all 28 cases',9.7,MUTED)
    ax=fig.add_axes([x+.022,.303,.246,.079],facecolor=PANEL)
    values=sorted(ratios[f]);ys=[j%3 for j in range(len(values))]
    ax.scatter(values,ys,s=21,c=[MINT if v>1 else ORANGE for v in values],alpha=.9,linewidth=0)
    ax.axvline(1,color=INK,lw=1,alpha=.7);ax.set_xscale('log',base=2)
    ax.set_xlim(.75,90);ax.set_ylim(-1,3);ax.set_xticks([1,4,16,64],['1×','4×','16×','64×'])
    ax.tick_params(axis='x',labelsize=8,length=0,pad=2);ax.set_yticks([])
    for spine in ax.spines.values():spine.set_visible(False)
text(fig,.052,.22,'EVERY CASE SHOWN ABOVE  •  Right of 1× favors Cedar; logarithmic scale. Orange marks the one loss.',10,MUTED)
text(fig,.052,.169,'ALSO MEASURED vs FLECS',10,MINT,'bold')
text(fig,.29,.168,'47/50 original C  ·  342/386 packed C  ·  276/386 indexed C',13,INK,'bold')
text(fig,.052,.105,'Apple M4 Pro · macOS ARM64 · checked indexed Cedar v53 · pinned EnTT 3.13.2 / pico_ecs / Flecs 4.0.1.',9,MUTED)
text(fig,.052,.078,'9 independent process rounds · 30 ms target. Equal case weights; includes teardown and timer-dominated additions.',9,MUTED)
text(fig,.052,.051,'Median wins are not significance claims: 3 pico cases have overlapping IQRs. One host; full methodology and raw data accompany these figures.',8.5,MUTED)
save(fig,'cedar-scorecard')

# The complete entity matrix preserves every case, including zero/single-entity overhead.
labels={'BM_AddComponent':'Add a component','BM_CreateEmptyEntities':'Create empty entities',
        'BM_CreateEntities':'Create populated entities','BM_CreateNoEntities':'Empty-world lifecycle',
        'BM_DestroyEntities':'Destroy entities','BM_RemoveAddComponent':'Remove + add component',
        'BM_UnpackNoComponent':'Check absent component','BM_UnpackOneComponent':'Read one component',
        'BM_UnpackTwoComponents':'Read two components','BM_UnpackThreeComponents':'Read three components'}
fig=plt.figure(figsize=(11,12.3),facecolor=BG)
text(fig,.055,.955,'CEDAR ECS  /  EVERY ENTITY CASE',12,MINT,'bold')
text(fig,.055,.907,'The full picture. 83 wins. One loss.',25,INK,'bold')
text(fig,.055,.873,'Speedup = competitor median CPU time ÷ Cedar median CPU time. Higher favors Cedar.',10,MUTED)
ax=fig.add_axes([.48,.182,.46,.644],facecolor=BG)
matrix=np.array([[float(r[f+'_cpu_median_ns'])/float(r['cedar_cpu_median_ns']) for f in frameworks] for r in rows])
ax.imshow(np.array([[speed_color(v) for v in row] for row in matrix]),aspect='auto')
ax.set_xticks(range(3),[names[f] for f in frameworks]);ax.xaxis.tick_top();ax.tick_params(length=0,pad=12)
ax.set_yticks([])
for i,r in enumerate(rows):
    case=r['benchmark'];base,_,n=case.partition('/')
    label=labels[base]+('  /  '+f'{int(n):,}' if n else '')
    ax.text(-.64,i,label,ha='right',va='center',fontsize=9.2,clip_on=False)
    for j,f in enumerate(frameworks):
        overlap=next(d['spread']=='overlap' for d in derived if d['case']==case and d['competitor']==f)
        value=matrix[i,j]
        s=f'{value:.2f}×'+(' *' if overlap else '')
        if 1 < value < 1.01:s=f'{value:.3f}×'+(' *' if overlap else '')
        ax.text(j,i,s,ha='center',va='center',fontweight='bold',fontsize=11,color=INK if value<12 else BG)
    ax.axhline(i+.5,color=BG,lw=1.7)
for j in (.5,1.5):ax.axvline(j,color=BG,lw=3)
for s in ax.spines.values():s.set_visible(False)
text(fig,.055,.136,'1× = equal time. Mint = Cedar faster. Orange = competitor faster. * = observed interquartile ranges overlap.',9,MUTED)
text(fig,.055,.111,'All 28 cases; no best-case filtering. Input suffixes are upstream parameters, not always live entity counts.',9,MUTED)
text(fig,.055,.086,'Three-component /1,024 and /65,536 cases report 512 and 32,768 entities with all three components respectively.',9,MUTED)
text(fig,.055,.061,'Checked indexed Cedar v53 · 9 rounds / 30 ms · Apple M4 Pro / macOS · CPU-time ratios; native factory timing boundaries.',9,MUTED)
text(fig,.055,.036,'Includes teardown; addition timings are dominated by timer pause/resume. One-host benchmark comparison, not a universal ranking.',8.7,MUTED)
save(fig,'cedar-all-entity-cases')

# Full C suites: every family in both fixed storage policies, never best-of-policy selection.
packed=ROOT/'results/checked-final-v53-packed/summary.csv'
indexed=ROOT/'results/checked-final-v53-slots/summary.csv'
original=ROOT/'results/checked-final-v53-original/summary.csv'
family_names={'creation':'Creation','lifecycle':'Entity lifecycle','lookup':'Lookup','transitions':'Transitions',
              'queries':'Query iteration','query_lifecycle':'Query construction','frames':'Frames',
              'frame_commands':'Worker commands','systems':'Many systems','payload':'Payload width','redundant':'Repeated operations'}
families=list(family_names)
fig=plt.figure(figsize=(12,8.7),facecolor=BG)
text(fig,.055,.947,'CEDAR ECS  /  THE C WORKLOAD SUITES',12,MINT,'bold')
text(fig,.055,.886,'Hundreds of cases. Two storage policies.',25,INK,'bold')
text(fig,.055,.845,'Each cell summarizes every configuration in its family. Both policies run the same 386 cases.',10,MUTED)
datasets=[read(packed),read(indexed)]
for col,(data,title) in enumerate(zip(datasets,['PACKED CEDAR','INDEXED CEDAR'])):
    x=.30+col*.335
    text(fig,x,.783,title,14,INK,'bold')
    for i,family in enumerate(families):
        group=[r for r in data if r['family']==family]; assert group
        values=[float(r['flecs_over_cedar']) for r in group];m=gm(values);w=sum(v>1 for v in values)
        y=.727-i*.043
        rect(fig,x-.005,y-.015,.29,.039,color=speed_color(m),r=.006)
        text(fig,x+.009,y-.002,f'{m:.2f}×',12,INK,'bold')
        text(fig,x+.135,y-.002,f'{w}/{len(group)} wins',10,INK)
        if col==0:text(fig,.055,y-.002,family_names[family],11,INK)
    total=sum(float(r['flecs_over_cedar'])>1 for r in data)
    text(fig,x,.215,f'{total}/386',29,MINT,'bold')
    text(fig,x,.183,'median case wins vs Flecs',9.5,MUTED)
text(fig,.055,.125,'Ratios are equal-case geometric means of Flecs/Cedar wall-time medians. Higher favors Cedar; every loss remains counted.',9,MUTED)
text(fig,.055,.096,'9 paired rounds · fixed policies · checked C APIs · one Apple M4 Pro host · Flecs development pin; separate from entity suite.',9,MUTED)
text(fig,.055,.067,'Original C suite: 47/50 wins; its frame adapter uses automatic batching. Expanded explicit grains and shared workloads are unchanged.',9,MUTED)
text(fig,.055,.038,'Indexed mode trades transition speed for slot-capacity memory; inspect individual cases and memory measurements before choosing a policy.',9,MUTED)
save(fig,'cedar-c-workloads')

inputs=[entity/'summary.csv',entity/'metadata.json',packed,indexed,original]
manifest=dict(cedar_snapshot=meta['cedar']['snapshot_sha256'],
              inputs={str(p.relative_to(ROOT)):sha(p) for p in inputs},
              outputs={p.name:sha(p) for p in outputs},
              policy='Every retained case, full fixed datasets, median ratios; equal-case geometric means are labeled and are not total application throughput; all timings predate these graphics; no engine changes.',
              wins=wins,geometric_mean_speedups={f:gm(v) for f,v in ratios.items()})
(OUT/'provenance.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Exported three complete performance figures as PNG/SVG/PDF, plus source ratios and hashes:',OUT)
