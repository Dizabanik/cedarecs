"""Deterministic parameter matrix; identical selection for every engine."""

DEFAULTS = dict(
    entities=1000,
    threads=1,
    width=1,
    bytes=8,
    bits=0,
    terms=0,
    percent=10,
    grain=1024,
    systems=1,
    rounds=1,
    reserve=0,
    shuffled=0,
)
SINGLE_PASS = {"create", "create_incremental", "delete"}


def case_id(c):
    return (
        c["scenario"]
        + "/"
        + ",".join(
            f"{k}={v}"
            for k, v in c.items()
            if k not in ("scenario", "family")
            and (k in ("entities", "threads") or v != DEFAULTS[k])
        )
    )


def cases():
    out = []

    def add(family, scenario, **kwargs):
        c = dict(scenario=scenario, **DEFAULTS)
        c.update(kwargs)
        c["family"] = family
        if c["entities"] * (c["width"] + 1) * max(8, c["bytes"]) <= 512 * 1024 * 1024:
            out.append(c)

    for n in (1000, 100000):
        for width in (1, 8, 32):
            for order in (0, 1):
                add("lookup", "get_hit", entities=n, width=width, shuffled=order)
        for width in (1, 32):
            for order in (0, 1):
                add("lookup", "get_miss", entities=n, width=width, shuffled=order)
        for s in ("get_empty", "get_stale"):
            for order in (0, 1):
                add("lookup", s, entities=n, shuffled=order)
        for p in (10, 50, 90):
            for order in (0, 1):
                add("lookup", "has_mixed", entities=n, percent=p, shuffled=order)
    for n in (1000, 10000, 100000):
        add("lookup", "pointer_chase", entities=n)
    for n in (1000, 10000):
        for width in (1, 2, 8, 16, 32):
            for size in (0, 8):
                for s in (
                    "toggle_entity",
                    "toggle_phase",
                    "defer_phase",
                    "defer_cancel",
                ):
                    add("transitions", s, entities=n, width=width, bytes=size)
        for size in (64, 256, 4096):
            add("payload", "toggle_phase", entities=n, bytes=size)
    for n in (1000, 100000):
        for width in (1, 8, 32):
            for size in (0, 8):
                for s in ("add_existing", "remove_absent"):
                    add("redundant", s, entities=n, width=width, bytes=size)
    for n in (1000, 10000, 100000):
        for size in (8, 64, 256, 4096):
            for order in (0, 1):
                add("payload", "set_payload", entities=n, bytes=size, shuffled=order)
    for n in (1000, 100000):
        for width in (1, 8, 32):
            for reserve in (0, 1):
                for s in ("create", "create_incremental"):
                    add("creation", s, entities=n, width=width, reserve=reserve)
    for reserve in (0, 1):
        for s in ("create", "create_incremental"):
            add("creation", s, entities=10000, width=8, bytes=64, reserve=reserve)
    for n in (1000, 10000):
        for width in (1, 8):
            for size in (8, 256):
                for order in (0, 1):
                    for s in ("delete", "recycle"):
                        add(
                            "lifecycle",
                            s,
                            entities=n,
                            width=width,
                            bytes=size,
                            shuffled=order,
                        )
    for n in (10000, 100000):
        for p in (1, 10, 50):
            add("lifecycle", "churn", entities=n, width=2, percent=p, shuffled=1)
    for n in (1000, 100000):
        for bits in (6, 10):
            for terms in (1, 4, 8):
                if terms <= bits:
                    for s in ("query_tags", "query_data"):
                        add("queries", s, entities=n, bits=bits, terms=terms)
            for s in ("query_optional", "query_not", "query_empty"):
                add("queries", s, entities=n, bits=bits)
            for terms in (1, 4):
                add(
                    "query_lifecycle", "query_build", entities=n, bits=bits, terms=terms
                )
        for bits in (0, 6):
            for width in (1, 4, 8, 16):
                add("queries", "query_plain", entities=n, width=width, bits=bits)
            add("query_lifecycle", "query_churn", entities=n, bits=bits)
    for n in (1000, 100000, 1000000):
        for t in (1, 2, 4, 8, 14):
            for grain in (64, 1024, 16384):
                add("frames", "frame", entities=n, threads=t, grain=grain)
    for n in (1000, 100000):
        for t in (1, 4, 14):
            for grain in (64, 1024):
                add(
                    "frame_commands",
                    "frame_commands",
                    entities=n,
                    threads=t,
                    grain=grain,
                )
    for bits in (6, 10):
        for t in (1, 4, 14):
            add("frames", "frame", entities=100000, threads=t, bits=bits)
    for n in (100000, 1000000):
        for t in (1, 2, 4, 8, 14):
            add("frames", "frame", entities=n, threads=t, width=4, rounds=32)
    for n in (1000, 100000):
        for t in (1, 4):
            for systems in (1, 8, 32):
                add("systems", "frame", entities=n, threads=t, width=4, systems=systems)
    assert len({case_id(c) for c in out}) == len(out)
    return out


def operations(c, iterations):
    s = c["scenario"]
    n = c["entities"]
    width = c["width"]
    if s.startswith(("toggle", "defer")):
        return n * iterations * 2 * width
    if s in ("add_existing", "remove_absent"):
        return n * iterations * width
    if s in ("recycle", "churn"):
        return (
            2 * (n if s == "recycle" else max(1, n * c["percent"] // 100)) * iterations
        )
    if s.startswith("query_"):
        return iterations
    if s.startswith("frame"):
        return n * c["systems"] * iterations
    return n * iterations
