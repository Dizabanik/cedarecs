#!/usr/bin/env python3
"""Paired measurements, independent from the frozen original suite."""

import argparse
import csv
import hashlib
import importlib.util
import json
import math
import os
import random
import statistics
import shutil
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path
from catalog import cases, case_id, operations, SINGLE_PASS, DEFAULTS

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location("legacy_bench", ROOT / "bench/run.py")
legacy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(legacy)
ENGINES = ("cedarecs", "flecs")


def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def execute(binary, engine, c, iterations):
    command = [str(binary / engine), c["scenario"]]
    for k in DEFAULTS:
        command += ["--" + k, str(c[k])]
    command += ["--iterations", str(iterations)]
    p = subprocess.run(
        command,
        text=True,
        capture_output=True,
        cwd=ROOT,
        timeout=240,
        env={**os.environ, "LC_ALL": "C"},
    )
    if p.returncode or p.stderr:
        raise RuntimeError(
            f"{engine} {case_id(c)} I={iterations}: exit {p.returncode}\n{p.stdout}\n{p.stderr}"
        )
    r = json.loads(p.stdout)
    for k in DEFAULTS:
        assert r[k] == c[k], (k, r, c)
    assert (
        r["scenario"] == c["scenario"]
        and r["engine"] == engine
        and r["iterations"] == iterations
    )
    assert r["operations"] == operations(c, iterations)
    return r


def parity(pair):
    for k in ("checksum", "operations", "matched", "unit"):
        if pair[0][k] != pair[1][k]:
            raise RuntimeError(f"Parity mismatch {k}: {pair}")


def summarize(out, records, jobs):
    rows = []
    for c in jobs:
        key = case_id(c)
        group = [r for r in records if r["case"] == key]
        row = dict(
            case=key,
            **c,
            iterations=group[0]["iterations"],
            matched=group[0]["matched"],
            unit=group[0]["unit"],
        )
        for e in ENGINES:
            samples = [r for r in group if r["engine"] == e]
            v = [r["ns_per_op"] for r in samples]
            row.update(
                {
                    f"{e}_median_ns": statistics.median(v),
                    f"{e}_p25_ns": legacy.percentile(v, 0.25),
                    f"{e}_p75_ns": legacy.percentile(v, 0.75),
                    f"{e}_min_ns": min(v),
                    f"{e}_max_ns": max(v),
                    f"{e}_median_peak_rss_mib": statistics.median(
                        r["peak_rss_bytes"] for r in samples
                    )
                    / 1048576,
                }
            )
        row["flecs_over_cedar"] = row["flecs_median_ns"] / row["cedarecs_median_ns"]
        rows.append(row)
    with (out / "summary.csv").open("w", newline="") as f:
        w = csv.DictWriter(f, list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    lines = [
        "# Expanded Cedar / Flecs comparison",
        "",
        "Lower ns/op is better. Units vary; compare within each row. Query passes include an empty result; matched is the visited entity count. Frame operations are entity-system updates. Deferred operations count logical requests, which engines can coalesce differently.",
        "",
        "| Case | Unit | Matched | Cedar ns/op | Flecs ns/op | Flecs / Cedar |",
        "| --- | --- | ---: | ---: | ---: | ---: |",
    ]
    for r in rows:
        lines.append(
            f"| {r['case']} | {r['unit']} | {r['matched']} | {r['cedarecs_median_ns']:.3f} | {r['flecs_median_ns']:.3f} | {r['flecs_over_cedar']:.3f} |"
        )
    (out / "comparison.md").write_text("\n".join(lines) + "\n")
    return rows


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--smoke", action="store_true")
    p.add_argument("--cedar-storage", choices=("archetype", "indexed"), default="archetype")
    p.add_argument("--list", action="store_true")
    p.add_argument("--engine", choices=ENGINES)
    p.add_argument("--family")
    p.add_argument("--scenario")
    p.add_argument("--binary-dir", type=Path, default=ROOT / "build/expanded")
    p.add_argument("--repeats", type=int, default=9)
    p.add_argument("--warmups", type=int, default=2)
    p.add_argument("--target-ms", type=float, default=20)
    p.add_argument("--max-operations", type=int, default=5000000)
    p.add_argument("--output", type=Path)
    args = p.parse_args()
    if args.cedar_storage == "indexed" and args.binary_dir == ROOT / "build/expanded":
        args.binary_dir = ROOT / "build/expanded-indexed"
    if not args.list and args.engine != "flecs":
        assert ("cedar-storage:" + args.cedar_storage).encode() in (args.binary_dir / "cedarecs").read_bytes(), "Cedar storage label does not match the executable"
    jobs = [
        c
        for c in cases()
        if (not args.family or c["family"] in args.family.split(","))
        and (not args.scenario or c["scenario"] == args.scenario)
    ]
    assert (
        jobs
        and args.repeats >= 3
        and args.warmups >= 1
        and args.target_ms > 0
        and args.max_operations > 0
    )
    if args.list:
        print(json.dumps(jobs, indent=2))
        return
    assert args.smoke or not args.engine, (
        "Single-engine runs are for correctness checks only"
    )
    engines = (args.engine,) if args.engine else ENGINES
    provenance = legacy.verify_sources()
    binary = (
        args.binary_dir if args.binary_dir.is_absolute() else ROOT / args.binary_dir
    )
    if args.smoke:
        shapes = {
            json.dumps(
                {k: v for k, v in c.items() if k != "entities"}, sort_keys=True
            ): c
            for c in jobs
        }
        count = 0
        for c in shapes.values():
            for n in (1, 1031):
                c = {**c, "entities": n}
                iterations = 1 if c["scenario"] in SINGLE_PASS else 3
                pair = [execute(binary, e, c, iterations) for e in engines]
                if len(pair) == 2:
                    parity(pair)
                count += 1
        print(
            f"Expanded smoke passed: {count} parameter/size cases, engines: {engines}."
        )
        return
    started = datetime.now(timezone.utc)
    out = args.output or ROOT / "results" / started.strftime("expanded-%Y%m%dT%H%M%SZ")
    out = out if out.is_absolute() else ROOT / out
    out.mkdir(parents=True, exist_ok=False)
    files = [
        *sorted((ROOT / "bench/expanded").glob("*")),
        ROOT / "bench/bench.h",
        ROOT / "bench/run.py",
        ROOT / "Makefile",
    ]
    meta = dict(
        suite="expanded-v1",
        cedar_storage=args.cedar_storage,
        started_utc=started.isoformat(),
        system=legacy.system_info(),
        provenance=provenance,
        repeats=args.repeats,
        discarded_warmup_processes=args.warmups,
        target_ms=args.target_ms,
        max_operations=args.max_operations,
        cases=jobs,
        harness_sha256={
            str(f.relative_to(ROOT)): digest(f) for f in files if f.is_file()
        },
        binaries_sha256={e: digest(binary / e) for e in ENGINES},
        kernel_object_sha256=digest(ROOT / "build/expanded/kernels.o"),
        build_flags="C11 -O3 -DNDEBUG -march=native -pthread; no LTO/fast-math; Flecs minimal system/pipeline/OS build",
        execution="serialized; alternating engines; deterministic shuffled cases; no outliers removed",
    )
    for relative in meta["harness_sha256"]:
        destination = out / "source" / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / relative, destination)
    (out / "metadata.json").write_text(json.dumps(meta, indent=2) + "\n")
    (out / "cases.json").write_text(json.dumps(jobs, indent=2) + "\n")
    random.Random(0xCEDA2026).shuffle(jobs)
    records = []
    calibration = []
    begin = time.monotonic()
    with (out / "raw.jsonl").open("w") as raw:
        for index, c in enumerate(jobs):
            pilot = [execute(binary, e, c, 1) for e in ENGINES]
            parity(pilot)
            calibration.append(dict(case=case_id(c), samples=pilot))
            fastest = min(r["elapsed_ns"] for r in pilot)
            iterations = (
                1
                if c["scenario"] in SINGLE_PASS
                else max(
                    1,
                    min(
                        10000,
                        args.max_operations // max(1, operations(c, 1)),
                        math.ceil(args.target_ms * 1e6 / max(1, fastest)),
                    ),
                )
            )
            checks = set()
            for trial in range(-args.warmups, args.repeats):
                pair = []
                for order, e in enumerate(
                    ENGINES if (trial + index) % 2 == 0 else ENGINES[::-1]
                ):
                    row = execute(binary, e, c, iterations)
                    row.update(
                        case=case_id(c),
                        family=c["family"],
                        trial=trial,
                        order_index=order,
                    )
                    pair.append(row)
                    if trial >= 0:
                        records.append(row)
                        raw.write(json.dumps(row) + "\n")
                        raw.flush()
                parity(pair)
                checks.add(pair[0]["checksum"])
            assert len(checks) == 1, (c, checks)
            r = [v for v in records if v["case"] == case_id(c)]
            med = {
                e: statistics.median(x["ns_per_op"] for x in r if x["engine"] == e)
                for e in ENGINES
            }
            print(
                f"[{index + 1}/{len(jobs)}] {case_id(c)} C={med['cedarecs']:.3f} F={med['flecs']:.3f} ({time.monotonic() - begin:.0f}s)",
                flush=True,
            )
    (out / "calibration.json").write_text(json.dumps(calibration, indent=2) + "\n")
    meta.update(
        completed_utc=datetime.now(timezone.utc).isoformat(),
        wall_seconds=time.monotonic() - begin,
    )
    (out / "metadata.json").write_text(json.dumps(meta, indent=2) + "\n")
    summarize(out, records, jobs)
    print("Results:", out, flush=True)


if __name__ == "__main__":
    main()
