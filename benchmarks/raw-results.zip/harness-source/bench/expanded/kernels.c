#include "suite.h"
// One compiled object, linked unchanged into every expanded backend. No LTO.
uint64_t x_sum(const void *const *columns, size_t fields, size_t count, size_t bytes) {
    uint64_t sum = 0;
    for (size_t f = 0; f < fields; f++) {
        if (!columns[f])
            continue;
        const unsigned char *p = columns[f];
        for (size_t i = 0; i < count; i++) {
            uint64_t v;
            memcpy(&v, p + i * bytes, 8);
            sum += v;
        }
    }
    return sum;
}
void x_update(void *const *columns, size_t fields, size_t count, size_t rounds) {
    for (size_t f = 0; f < fields; f++) {
        uint64_t *p = columns[f];
        for (size_t i = 0; i < count; i++) {
            uint64_t v = p[i];
            for (size_t r = 0; r < rounds; r++)
                v = v * UINT64_C(1664525) + UINT64_C(1013904223);
            p[i] = v;
        }
    }
}
