# Expanded C suite

This suite adds **28 scenario types and 386 configurations** to the original 50-case comparison. It uses the existing, unchanged experimental Cedar source and pinned Flecs development source. The original benchmark sources, executables, and historical results remain separate.

## Run

From `testing/`:

```sh
make expanded
make smoke-expanded            # 374 shape/size combinations for BOTH engines
make sanitize-expanded         # same sweep under ASan/UBSan
make tsan-expanded             # Cedar's worker-command cases under TSan
python3 bench/expanded/run.py --list
python3 bench/expanded/run.py --output results/my-expanded-run
python3 bench/expanded/validate.py results/my-expanded-run
```

Use `--family lookup` or `--scenario query_data` for a focused run; comma-separated families are supported. `--engine` is available only for correctness smoke checks; performance runs always pair both libraries. Default retained samples: nine per library and case, after two discarded process warmups. Creation/deletion use one timed population, preserving their allocation workload. Other cases select the same iterations for both engines from a pilot, targeting 20 ms for the faster implementation, capped at 10,000 passes and five million reported operations. Some samples remain short, especially fresh single-pass creation/deletion and tiny queries/frames; retain their IQRs and avoid interpreting small differences as established wins.

For sustained frame measurements, raise the operation cap while keeping both engines paired:

```sh
python3 bench/expanded/run.py --family frames,systems,frame_commands --max-operations 500000000 --output results/my-sustained-frames
```

The completed sustained run covers 85 configurations and retains 1,530 samples. The two complete 386-configuration runs retain 13,896 samples. Source files used for each measured harness are archived under that run's `source/` directory and checked against its metadata hashes. Changes made after an older run remain distinguishable from the measured version. To reproduce a saved harness, restore its archived files to their recorded paths under `testing/`, restore the matching Cedar variant/provenance, and use the pinned dependency revisions before rebuilding. The aborted preflight dataset is explicitly labeled incomplete and excluded from conclusions.

`make tsan-expanded-flecs` runs the equivalent Flecs diagnostic. On this macOS/ARM64 host the pinned development revision produces TSan reports in its frame/pipeline/query code; a plain frame without commands reproduces reports too. These are preserved under `validation/expanded/`. The cause has not been resolved, and no suppressions or source patches are applied. Do not describe Flecs as race-detector clean. Release and ASan/UBSan runs independently check output parity.

## Coverage

| Family | Configurations | Cases |
| --- | ---: | --- |
| Lookup | 43 | Present/absent/empty-entity lookups, explicitly guarded stale handles, mixed presence, sequential/shuffled order, dependent pointer chase |
| Transitions | 80 | Per-entity vs phased add/remove; tags vs 8-byte data; widths 1/2/8/16/32; phased deferred commands and same-flush cancellation |
| Payload | 28 | 8/64/256/4096-byte setters; sequential/shuffled writes; migration retaining a large anchor payload |
| Redundant operations | 24 | Add an existing tag/data component; remove an absent tag/data component; widths 1/8/32 |
| Creation | 28 | Prepared final signatures vs incremental upserts plus common initialization; widths 1/8/32; natural growth vs prewarmed storage |
| Lifecycle | 38 | Sequential/shuffled deletion, delete-create recycling, 1/10/50% churn, varied widths and payloads |
| Queries | 48 | 1/4/8/16 projected data columns plus the anchor; signatures defined by 6/10 tag/data bits; 1/4/8 constraints; NOT, optional, and empty results |
| Query lifecycle | 12 | Repeated cached-query construction/destruction; structural changes while reusing a cached query |
| Native frames | 61 | 1K/100K/1M entities; 1/2/4/8/14 threads; Cedar grain 64/1024/16384; fragmentation and heavier kernels |
| Worker commands | 12 | Disjoint parallel updates plus deferred tag additions/removals, including merge cost |
| Multiple systems | 12 | 1/8/32 sequential systems, each internally parallel; four fields; 1K/100K entities and 1/4 threads |

The catalog is declarative in `catalog.py`; its list is recorded with every run. Payload estimates cap cases at 512 MiB. The largest payload configurations use smaller populations. Tag/data widths and scalar query widths are separate axes. The workload can expose weaknesses as well as strengths; the matrix is not tuned to preserve an engine's win count.

## Data, API contracts, and timing

Each nonempty entity has a persistent anchor plus its configured data/tag signature. The anchor's first word holds its application ordinal, independent of native entity IDs. Anchor and data storage have the selected payload size (tags have zero bytes). Deterministic byte patterns and independently calculated first words permit full payload checking after migration. Scalar query and update cases use unsigned 64-bit values, including defined modular arithmetic in update kernels. The same compiled `kernels.o` is linked into both executables, with no LTO or fast-math.

Signatures follow a deterministic permutation over 0, 64, or 1024 signature slots; they are not copied from a library's entity IDs or unspecified random generator. All signature tables are prepared before timing, including unoccupied slots. Query population, matching counts, and results are calculated independently from the signature rules. A query can match zero rows; it still reports a whole query pass. Required columns use public ordinal field access. Optional fields follow each library's public optional-access path.

`get_stale` measures an explicit liveness guard rejecting a recycled handle. Both engines call their public liveness check before deciding whether to get data. Flecs's raw get API requires a live handle, so directly passing a stale ID would not be a valid equivalent workload. Ordinary hit/miss cases use valid live handles without adding this guard. Lookup results are consumed; compiler barriers prevent repeated checked work from becoming unobserved. Scenario names are resolved outside timed entity loops.

Creation always writes the full checked payload through common initialization. Incremental creation first performs one public upsert per component with the shared seed value, then applies that same common initialization; prepared creation starts in its final signature. Thus the incremental case includes those additional setter/value-copy calls and is not a pure archetype-transition-only measurement.

`reserve=1` means **prewarmed storage**: request entity-ID capacity using the public API, populate the whole dataset, and delete it outside timing. This leaves reusable entity slots and row capacity in both libraries. It is intentionally labeled separately from fresh creation. It does not pretend Flecs has a public row-reserve API equivalent to Cedar's prepared-plan reserve.

Phased mutation adds to the entire population, flushes when deferred, then removes from the population and flushes again. The `defer_cancel` workload instead queues additions and removals per entity before one flush, allowing each engine's normal command coalescing. Its unit is a logical submitted command, not a guaranteed physical migration. An untimed add phase validates every added component/tag and value; final validation checks absence and the unchanged anchor payload. Existing data additions use the normal public setter/upsert path, whose notification and hook features differ between the libraries.

Frames run each library's native scheduler and include merge cost. Cedar preserves its requested maximum grain; Flecs chooses its own worker partitions. Changing `grain` changes Cedar's partitioning only, so some Flecs configurations intentionally repeat. Both requested thread counts include the caller. Worker-command systems declare their output to Flecs and use the pinned API's `it->stage`; field update kernels remain identical. Read queries use `EcsQueryCacheAll`. Worker-command system queries use `EcsQueryCacheAuto` because their explicit output-only term has no entity source; eligible matching terms remain cached. Multiple-system cases give each system its own query and serialize systems that touch the same fields. They include Cedar's single cached job-plan switching behavior and Flecs's scheduling behavior. This is not a task-graph equivalence claim.

Queries report ns per complete pass (or construction/drop pair), with the matched entity count retained. Frames report ns per entity-system update. Transitions report each add/set or removal; lifecycle churn reports each deletion/creation including reinitialization. Do not average these units or treat a raw case-win count as a feature-complete ranking. Setup, checksum generation, and full value verification occur outside timing; public-API failure checks used by common initialization remain part of creation/recycling work.

## Inputs and broader comparison

Sander Mertens's [Bevy gist](https://gist.github.com/SanderMertens/b98ea829a1477f9b8620dd5878f707a3) suggested hit/miss access, wide tag/data transitions, deferred changes, recycling, and queries over varied signatures. This is an independently written C adaptation of those categories, with deterministic data, explicit operation units, output validation, and separate coalescing cases. It does not reproduce the Rust harness or compare its historical scores. Hierarchy deletion is not ported because Cedar does not currently provide Flecs/Bevy relationship and cascade semantics.

The additional payload, ordering, churn, filter, grain, fragmentation, and system-count sweeps extend beyond that gist. `references.json` records its revision and source hash.

The [abeimler/ecs_benchmark](https://github.com/abeimler/ecs_benchmark) integration lives separately in `interop/abeimler/`. It adds Cedar to that repository's common entity template alongside EnTT, pico_ecs, and a compatible Flecs release. Its Google Benchmark timings, older dependency pins, C++ bridge overhead, and timing boundaries differ from this suite; compare within each dataset.


### Comparing indexed storage

`make -C testing expanded-indexed smoke-indexed sanitize-indexed tsan-indexed`
builds and checks the additional fixed storage policy. From the project root,
run `python3 testing/bench/expanded/run.py --cedar-storage indexed --output
results/NEW-indexed`. The runner selects the indexed binary, verifies its storage
marker, and records the policy. Default runs retain packed archetype storage.
Both execute every requested case with the same common workloads, kernels and
Flecs binary; results are separate, with no best-policy selection per row. Both
C policies use checked access. The C++ known-live experiment is separate.


The v42 packed adapter binds `ced_Access` once per world and uses its checked
mutable accessor uniformly for random access and setup. Indexed mode continues
using its prepared indexed readers. Both validate bounds, component presence
and the full generation. This uses public APIs throughout; the common workloads,
case catalog, kernels and Flecs adapter are unchanged. Earlier results used
out-of-line packed getters; the Cedar adapter and source manifest identify this
change explicitly.

The current [checked candidate](../../OPTIMIZATIONS_CHECKED.md) retains this
expanded Cedar adapter byte-for-byte from v42, including every explicit maximum
grain. Its new public automatic batching API is used by the separate original
50-case suite. The packed and indexed policies remain fixed for their respective
complete 386-case runs; results are not selected per case from different policies.
