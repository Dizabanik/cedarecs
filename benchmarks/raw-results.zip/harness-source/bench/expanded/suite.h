#ifndef CEDAR_EXPANDED_SUITE_H
#define CEDAR_EXPANDED_SUITE_H
#include "../bench.h"
#include <stdatomic.h>
#define X_DATA 1
#define X_TAG 33
#define X_MISSING 65
#define X_KEYS 66
#define X_MAX 32

typedef struct XConfig {
    const char *scenario;
    size_t entities, iterations, threads, width, bytes, bits, terms;
    size_t percent, grain, systems, rounds, reserve, shuffled;
} XConfig;
typedef struct XResult {
    uint64_t elapsed_ns, operations, checksum, matched;
    const char *unit;
} XResult;
typedef struct XSignature {
    uint32_t data, tags;
    bool anchor;
} XSignature;

static inline bool is_case(const XConfig *c, const char *s) { return !strcmp(c->scenario, s); }
static inline bool starts(const XConfig *c, const char *s) {
    return !strncmp(c->scenario, s, strlen(s));
}
static inline uint32_t low_bits(size_t n) { return n == 32 ? UINT32_MAX : (UINT32_C(1) << n) - 1; }
static inline size_t group_for(const XConfig *c, size_t i) {
    return (i * 4051 + 17) & low_bits(c->bits);
}
static inline XSignature signature(const XConfig *c, size_t group) {
    XSignature s = {low_bits(c->width), (uint32_t)group, true};
    if (starts(c, "toggle") || starts(c, "defer") || is_case(c, "remove_absent"))
        s.data = 0;
    if (is_case(c, "add_existing") && !c->bytes) {
        s.data = 0;
        s.tags = low_bits(c->width);
    }
    if (is_case(c, "get_empty"))
        s = (XSignature){0};
    if (is_case(c, "query_data") || is_case(c, "query_optional")) {
        s.data = (uint32_t)group;
        s.tags = 0;
    }
    return s;
}
static inline bool data_present(const XConfig *c, size_t i, size_t field) {
    return !!(signature(c, group_for(c, i)).data & (UINT32_C(1) << field));
}
static inline uint64_t initial_word(size_t i, size_t field) {
    return (uint64_t)(i + 1) * (field + 3) + 7;
}
static inline uint64_t hash_word(uint64_t h, uint64_t v) {
    return (h ^ v) * UINT64_C(1099511628211);
}
static inline void observe(const void *p) {
#if defined(__clang__) || defined(__GNUC__)
    __asm__ __volatile__("" : : "r"(p) : "memory");
#else
    (void)p;
    atomic_signal_fence(memory_order_seq_cst);
#endif
}
uint64_t x_sum(const void *const *columns, size_t fields, size_t count, size_t bytes);
void x_update(void *const *columns, size_t fields, size_t count, size_t rounds);
XResult x_execute(const XConfig *c);
#endif
