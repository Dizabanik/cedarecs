#include "suite.h"
#include <flecs.h>
const char *bench_engine(void) { return "flecs"; }
const char *bench_version(void) { return FLECS_COMMIT; }
typedef struct Query {
    ecs_query_t *query;
    size_t fields;
    bool optional;
} Query;
typedef struct World {
    ecs_world_t *ecs, *commands;
    ecs_entity_t ids[X_KEYS];
    ecs_table_t **plans;
    const XConfig *c;
    bool frame_add;
} World;
static World *world_new(const XConfig *c) {
    World *w = calloc(1, sizeof(*w));
    CHECK(w);
    w->c = c;
    w->ecs = ecs_init();
    CHECK(w->ecs);
    w->commands = w->ecs;
    w->frame_add = true;
    for (size_t k = 0; k < X_KEYS; k++) {
        char name[32];
        snprintf(name, sizeof(name), "Expanded%zu", k);
        ecs_entity_t id =
            ecs_entity_init(w->ecs, &(ecs_entity_desc_t){.name = name, .use_low_id = true});
        CHECK(id);
        size_t bytes = k >= X_TAG && k < X_MISSING ? 0 : (c->bytes ? c->bytes : 8);
        if (bytes)
            CHECK(ecs_component_init(w->ecs,
                                     &(ecs_component_desc_t){.entity = id,
                                                             .type = {.size = (ecs_size_t)bytes,
                                                                      .alignment = 8}}) == id);
        w->ids[k] = id;
    }
    size_t groups = (size_t)1 << c->bits;
    w->plans = calloc(groups, sizeof(*w->plans));
    CHECK(w->plans);
    for (size_t g = 0; g < groups; g++) {
        XSignature s = signature(c, g);
        ecs_id_t ids[X_KEYS];
        int32_t n = 0;
        if (s.anchor)
            ids[n++] = w->ids[0];
        for (size_t i = 0; i < 32; i++)
            if (s.data & (UINT32_C(1) << i))
                ids[n++] = w->ids[X_DATA + i];
        for (size_t i = 0; i < 32; i++)
            if (s.tags & (UINT32_C(1) << i))
                ids[n++] = w->ids[X_TAG + i];
        w->plans[g] = ecs_table_find(w->ecs, ids, n);
        CHECK(w->plans[g]);
    }
    if (c->reserve)
        ecs_dim(w->ecs, (int32_t)c->entities);
    return w;
}
static void world_delete(World *w) {
    ecs_fini(w->ecs);
    free(w->plans);
    free(w);
}
static inline Entity spawn(World *w, size_t g) { return ecs_new_w_table(w->ecs, w->plans[g]); }
static inline Entity spawn_empty(World *w) { return ecs_new(w->ecs); }
static inline void kill(World *w, Entity e) { ecs_delete(w->ecs, e); }
static inline bool alive(World *w, Entity e) { return ecs_is_alive(w->ecs, e); }
static inline void *get(World *w, Entity e, size_t k) {
    return ecs_get_mut_id(w->ecs, e, w->ids[k]);
}
static inline bool has(World *w, Entity e, size_t k) { return ecs_has_id(w->ecs, e, w->ids[k]); }
static inline void put(World *w, Entity e, size_t k, const void *v, bool defer) {
    ecs_world_t *target = defer ? w->commands : w->ecs;
    if (k >= X_TAG && k < X_MISSING)
        ecs_add_id(target, e, w->ids[k]);
    else
        ecs_set_id(target, e, w->ids[k], w->c->bytes ? w->c->bytes : 8, v);
}
static inline void remove_key(World *w, Entity e, size_t k, bool defer) {
    ecs_remove_id(defer ? w->commands : w->ecs, e, w->ids[k]);
}
static inline void begin_commands(World *w) { w->commands = ecs_get_stage(w->ecs, 0); }
static inline void flush_commands(World *w) {
    ecs_merge(w->commands);
    w->commands = w->ecs;
}
static ecs_query_desc_t query_desc(World *w, bool frame, size_t *fields) {
    const XConfig *c = w->c;
    ecs_query_desc_t d = {.cache_kind = EcsQueryCacheAll};
    size_t n = 0;
    *fields = 0;
    if (frame) {
        for (size_t i = 0; i < c->width; i++)
            d.terms[n++] = (ecs_term_t){.id = w->ids[X_DATA + i], .inout = EcsInOut};
        *fields = c->width;
    } else if (is_case(c, "query_empty")) {
        d.terms[n++] = (ecs_term_t){.id = w->ids[X_MISSING], .inout = EcsIn};
        *fields = 1;
    } else {
        d.terms[n++] = (ecs_term_t){.id = w->ids[0], .inout = EcsIn};
        *fields = 1;
        size_t columns = is_case(c, "query_data") ? c->terms : c->width;
        if (is_case(c, "query_optional"))
            columns = 0;
        for (size_t i = 0; i < columns; i++) {
            d.terms[n++] = (ecs_term_t){.id = w->ids[X_DATA + i], .inout = EcsIn};
            (*fields)++;
        }
        if (is_case(c, "query_optional")) {
            d.terms[n++] = (ecs_term_t){.id = w->ids[X_DATA], .inout = EcsIn, .oper = EcsOptional};
            (*fields)++;
        }
        if (is_case(c, "query_tags") || is_case(c, "query_build"))
            for (size_t i = 0; i < c->terms; i++)
                d.terms[n++] = (ecs_term_t){.id = w->ids[X_TAG + i], .inout = EcsInOutNone};
        if (is_case(c, "query_not"))
            d.terms[n++] = (ecs_term_t){.id = w->ids[X_TAG], .inout = EcsInOutNone, .oper = EcsNot};
    }
    if (frame && is_case(c, "frame_commands")) {
        d.terms[n++] =
            (ecs_term_t){.id = w->ids[X_TAG + 31], .src.id = EcsIsEntity, .inout = EcsOut};
        d.cache_kind = EcsQueryCacheAuto;
    }
    CHECK(n <= FLECS_TERM_COUNT_MAX);
    return d;
}
static Query query_new(World *w, bool frame) {
    size_t fields;
    ecs_query_desc_t d = query_desc(w, frame, &fields);
    ecs_query_t *q = ecs_query_init(w->ecs, &d);
    CHECK(q);
    return (Query){q, fields, is_case(w->c, "query_optional")};
}
static void query_drop(Query *q) {
    ecs_query_fini(q->query);
    q->query = NULL;
}
static uint64_t query_sum(World *w, Query *q, uint64_t *matched) {
    uint64_t result = 0;
    *matched = 0;
    ecs_iter_t it = ecs_query_iter(w->ecs, q->query);
    while (ecs_query_next(&it)) {
        const void *columns[32];
        for (size_t f = 0; f < q->fields; f++)
            columns[f] = ecs_field_w_size(&it, w->c->bytes ? w->c->bytes : 8, (int8_t)f);
        result += x_sum(columns, q->fields, (size_t)it.count, w->c->bytes ? w->c->bytes : 8);
        *matched += (size_t)it.count;
    }
    return result;
}
static void frame_callback(ecs_iter_t *it) {
    World *w = it->ctx;
    void *fields[8];
    for (size_t f = 0; f < w->c->width; f++)
        fields[f] = ecs_field_w_size(it, 8, (int8_t)f);
    x_update(fields, w->c->width, (size_t)it->count, w->c->rounds);
    if (is_case(w->c, "frame_commands"))
        for (int32_t i = 0; i < it->count; i++) {
            if (w->frame_add)
                ecs_add_id(it->stage, it->entities[i], w->ids[X_TAG + 31]);
            else
                ecs_remove_id(it->stage, it->entities[i], w->ids[X_TAG + 31]);
        }
}
static void frame_prepare(World *w) {
    for (size_t i = 0; i < w->c->systems; i++) {
        size_t fields;
        ecs_query_desc_t d = query_desc(w, true, &fields);
        CHECK(ecs_system_init(w->ecs, &(ecs_system_desc_t){.query = d,
                                                           .phase = EcsOnUpdate,
                                                           .callback = frame_callback,
                                                           .ctx = w,
                                                           .multi_threaded = true}));
    }
    ecs_set_threads(w->ecs, (int32_t)w->c->threads);
}
static void frame_move(World *w) {
    CHECK(ecs_progress(w->ecs, 1.0f / 60));
    w->frame_add = !w->frame_add;
}
#include "workloads.inc"
