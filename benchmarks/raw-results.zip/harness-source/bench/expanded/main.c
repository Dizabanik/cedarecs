#define _POSIX_C_SOURCE 200809L
#include "suite.h"
#include <time.h>
#include <errno.h>
#include <sys/resource.h>
#if defined(__APPLE__)
#include <pthread/qos.h>
#endif
uint64_t bench_now(void) {
    struct timespec t;
    CHECK(!clock_gettime(CLOCK_MONOTONIC, &t));
    return (uint64_t)t.tv_sec * 1000000000 + t.tv_nsec;
}
static size_t number(const char *s) {
    char *end;
    errno = 0;
    unsigned long long v = strtoull(s, &end, 10);
    CHECK(!errno && *s && !*end && s[0] != '-' && v <= SIZE_MAX);
    return (size_t)v;
}
int main(int argc, char **argv) {
    CHECK(argc >= 2 && !(argc % 2));
    XConfig c = {.scenario = argv[1],
                 .entities = 1000,
                 .iterations = 1,
                 .threads = 1,
                 .width = 1,
                 .bytes = 8,
                 .percent = 10,
                 .grain = 1024,
                 .systems = 1,
                 .rounds = 1};
    for (int i = 2; i < argc; i += 2) {
        size_t v = number(argv[i + 1]);
#define OPT(name)                                                                                  \
    if (!strcmp(argv[i], "--" #name))                                                              \
    c.name = v
        OPT(entities);
        else OPT(iterations);
        else OPT(threads);
        else OPT(width);
        else OPT(bytes);
        else OPT(bits);
        else OPT(terms);
        else OPT(percent);
        else OPT(grain);
        else OPT(systems);
        else OPT(rounds);
        else OPT(reserve);
        else OPT(shuffled);
        else CHECK(false);
#undef OPT
    }
    CHECK(c.entities && c.entities <= 1000000 && c.iterations && c.iterations <= 10000);
    CHECK(c.threads && c.threads <= 256 && c.width && c.width <= 32 && c.bits <= 10 &&
          c.terms <= c.bits);
    CHECK(c.bytes <= 4096 && !(c.bytes % 8) && c.percent <= 100 && c.percent > 0 && c.grain > 0 &&
          c.systems > 0 && c.systems <= 32 && c.rounds > 0 && c.rounds <= 64);
    CHECK(c.reserve <= 1 && c.shuffled <= 1);
    // Required data fields plus the anchor and tag constraints must fit each
    // backend's query descriptor. Wider creation/transition cases remain valid.
    CHECK(!starts(&c, "query_") || c.width <= 16);
    CHECK(!starts(&c, "frame") || (c.bytes == 8 && c.width <= 8));
    CHECK(starts(&c, "frame") || c.threads == 1);
#if defined(__APPLE__)
    CHECK(!pthread_set_qos_class_self_np(QOS_CLASS_USER_INITIATED, 0));
#endif
    XResult r = x_execute(&c);
    CHECK(r.operations);
    struct rusage u;
    CHECK(!getrusage(RUSAGE_SELF, &u));
    uint64_t rss = u.ru_maxrss;
#if !defined(__APPLE__)
    rss *= 1024;
#endif
    printf("{\"engine\":\"%s\",\"version\":\"%s\",\"scenario\":\"%s\",", bench_engine(),
           bench_version(), c.scenario);
#define FIELD(n) printf("\"" #n "\":%zu,", c.n)
    FIELD(entities);
    FIELD(iterations);
    FIELD(threads);
    FIELD(width);
    FIELD(bytes);
    FIELD(bits);
    FIELD(terms);
    FIELD(percent);
    FIELD(grain);
    FIELD(systems);
    FIELD(rounds);
    FIELD(reserve);
    FIELD(shuffled);
#undef FIELD
    printf("\"elapsed_ns\":%llu,\"operations\":%llu,\"unit\":\"%s\",\"matched\":%llu,\"ns_per_op\":"
           "%.9f,\"checksum\":\"%016llx\",\"peak_rss_bytes\":%llu}\n",
           (unsigned long long)r.elapsed_ns, (unsigned long long)r.operations, r.unit,
           (unsigned long long)r.matched, (double)r.elapsed_ns / r.operations,
           (unsigned long long)r.checksum, (unsigned long long)rss);
    return 0;
}
