#include "suite.h"
#include <cedarecs/cedar.h>
#ifdef CEDAR_INDEXED_STORAGE
const char cedar_storage_marker[] = "cedar-storage:indexed";
#else
const char cedar_storage_marker[] = "cedar-storage:archetype";
#endif
const char *bench_engine(void) { return "cedarecs"; }
const char *bench_version(void) { return CEDAR_SNAPSHOT; }
typedef struct Query {
    ced_View *view;
    size_t fields;
    bool optional;
} Query;
typedef struct World {
    ced_World *ecs;
    ced_Access access;
    ced_Component ids[X_KEYS];
#ifdef CEDAR_INDEXED_STORAGE
    ced_IndexedReader readers[X_KEYS];
#endif
    ced_SpawnPlan *plans;
    Query frame_queries[32];
    const XConfig *c;
    bool frame_add;
} World;
static World *world_new(const XConfig *c) {
    World *w = calloc(1, sizeof(*w));
    CHECK(w);
    w->c = c;
    #ifdef CEDAR_INDEXED_STORAGE
    w->ecs = ced_init_indexed();
#else
    w->ecs = ced_world();
#endif
    CHECK(w->ecs);
    w->access = ced_access(w->ecs);
    w->frame_add = true;
    for (size_t k = 0; k < X_KEYS; k++) {
        char name[32];
        snprintf(name, sizeof(name), "Expanded%zu", k);
        size_t bytes = k >= X_TAG && k < X_MISSING ? 0 : (c->bytes ? c->bytes : 8);
        w->ids[k] = ced_component_register(w->ecs, name, bytes, bytes ? 8 : 1);
        CHECK(w->ids[k] != ced_component_none);
#ifdef CEDAR_INDEXED_STORAGE
        w->readers[k] = ced_indexed_reader(w->ecs, w->ids[k]);
#endif
    }
    size_t groups = (size_t)1 << c->bits;
    w->plans = calloc(groups, sizeof(*w->plans));
    CHECK(w->plans);
    for (size_t g = 0; g < groups; g++) {
        XSignature s = signature(c, g);
        ced_Component ids[X_KEYS];
        size_t n = 0;
        if (s.anchor)
            ids[n++] = w->ids[0];
        for (size_t i = 0; i < 32; i++)
            if (s.data & (UINT32_C(1) << i))
                ids[n++] = w->ids[X_DATA + i];
        for (size_t i = 0; i < 32; i++)
            if (s.tags & (UINT32_C(1) << i))
                ids[n++] = w->ids[X_TAG + i];
        w->plans[g] = ced_spawn_plan_init(w->ecs, n, ids);
        CHECK(w->plans[g].archetype);
    }
    if (c->reserve)
        CHECK(ced_reserve_entities(w->ecs, c->entities));
    return w;
}
static void world_delete(World *w) {
    ced_drop(w->ecs);
    free(w->plans);
    free(w);
}
static inline Entity spawn(World *w, size_t group) {
    Entity e = ced_entity_from_plan(w->ecs, &w->plans[group]);
    return e;
}
static inline Entity spawn_empty(World *w) { return ced_entity(w->ecs); }
static inline void kill(World *w, Entity e) { ced_kill(w->ecs, e); }
static inline bool alive(World *w, Entity e) { return ced_is_alive(w->ecs, e); }
static inline void *get(World *w, Entity e, size_t key) {
#ifdef CEDAR_INDEXED_STORAGE
    return (void *)ced_indexed_get(&w->readers[key], e);
#else
    return ced_access_get(&w->access, e, w->ids[key]);
#endif
}
static inline bool has(World *w, Entity e, size_t key) {
    return ced_has_component(w->ecs, e, w->ids[key]);
}
static inline void put(World *w, Entity e, size_t key, const void *value, bool defer) {
    if (key >= X_TAG && key < X_MISSING) {
        if (defer)
            ced_defer_add_component(w->ecs, e, w->ids[key]);
        else
            ced_add_component(w->ecs, e, w->ids[key]);
    } else if (defer)
        ced_defer_add_set_component(w->ecs, e, w->ids[key], value);
    else
        ced_add_set_component(w->ecs, e, w->ids[key], value);
}
static inline void remove_key(World *w, Entity e, size_t key, bool defer) {
    if (defer)
        ced_defer_remove_component(w->ecs, e, w->ids[key]);
    else
        ced_remove_component(w->ecs, e, w->ids[key]);
}
static inline void begin_commands(World *w) { CHECK(ced_commands_begin(w->ecs)); }
static inline void flush_commands(World *w) { CHECK(ced_commands_end(w->ecs)); ced_flush(w->ecs); }
static Query query_new(World *w, bool frame) {
    const XConfig *c = w->c;
    ced_Component all[32], none[1];
    size_t n = 0, nn = 0, fields = 0;
    bool optional = is_case(c, "query_optional");
    if (frame) {
        for (size_t i = 0; i < c->width; i++)
            all[n++] = w->ids[X_DATA + i];
        fields = c->width;
    } else if (is_case(c, "query_empty")) {
        all[n++] = w->ids[X_MISSING];
        fields = 1;
    } else {
        all[n++] = w->ids[0];
        fields = 1;
        size_t columns = is_case(c, "query_data") ? c->terms : c->width;
        if (optional)
            columns = 0;
        for (size_t i = 0; i < columns; i++) {
            all[n++] = w->ids[X_DATA + i];
            fields++;
        }
        if (is_case(c, "query_tags") || is_case(c, "query_build"))
            for (size_t i = 0; i < c->terms; i++)
                all[n++] = w->ids[X_TAG + i];
        if (is_case(c, "query_not"))
            none[nn++] = w->ids[X_TAG];
        if (optional)
            fields++;
    }
    CHECK(n <= 32);
    ced_View *view = ced_view_init(
        w->ecs, &(ced_ViewDesc){.all_count = n, .all = all, .none_count = nn, .none = none});
    CHECK(view);
    return (Query){view, fields, optional};
}
static void query_drop(Query *q) {
    ced_view_free(q->view);
    q->view = NULL;
}
static uint64_t query_sum(World *w, Query *q, uint64_t *matched) {
    uint64_t result = 0;
    *matched = 0;
    ced_view_each(q->view, batch) {
        const void *columns[32];
        for (size_t f = 0; f < q->fields; f++)
            columns[f] = q->optional && f == 1 ? ced_batch_col(batch, w->ids[X_DATA])
                                               : ced_batch_field(batch, f);
        result += x_sum(columns, q->fields, batch->count, w->c->bytes ? w->c->bytes : 8);
        *matched += batch->count;
    }
    return result;
}
static World *active;
static void frame_batch(ced_World *ecs, const ced_Batch *batch, void *context) {
    (void)ecs;
    World *w = context;
    void *fields[8];
    for (size_t f = 0; f < w->c->width; f++)
        fields[f] = ced_batch_field(batch, f);
    x_update(fields, w->c->width, batch->count, w->c->rounds);
    if (is_case(w->c, "frame_commands")) {
        CHECK(ced_commands_begin(w->ecs));
        for (size_t i = 0; i < batch->count; i++) {
            if (w->frame_add)
                ced_defer_add_component(w->ecs, batch->entities[i], w->ids[X_TAG + 31]);
            else
                ced_defer_remove_component(w->ecs, batch->entities[i], w->ids[X_TAG + 31]);
        }
        CHECK(ced_commands_end(w->ecs));
    }
}
static uint8_t frame_system(ced_World *ecs, int index, double dt) {
    (void)ecs;
    (void)dt;
    CHECK(ced_parallel_each(active->frame_queries[index].view, active->c->grain, frame_batch,
                            active));
    return 0;
}
static void frame_prepare(World *w) {
    active = w;
    CHECK(ced_set_threads(w->ecs, w->c->threads));
    for (size_t s = 0; s < w->c->systems; s++) {
        w->frame_queries[s] = query_new(w, true);
        ced_add_update_system(w->ecs, frame_system);
    }
}
static void frame_move(World *w) {
    ced_update_frame(w->ecs, 1.0 / 60);
    w->frame_add = !w->frame_add;
}
#include "workloads.inc"
