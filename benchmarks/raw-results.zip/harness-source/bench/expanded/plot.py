#!/usr/bin/env python3
"""Standalone overview figures; timings and their recorded source stay untouched."""

import argparse
import csv
import hashlib
import json
from pathlib import Path
from datetime import datetime, timezone
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import ScalarFormatter

p = argparse.ArgumentParser()
p.add_argument("results", type=Path)
args = p.parse_args()
root = args.results
rows = list(csv.DictReader((root / "summary.csv").open()))
colors = ["#23785a", "#b8b6af", "#c26d47"]
plt.rcParams.update(
    {
        "font.family": "DejaVu Sans",
        "font.size": 10,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "figure.facecolor": "#fbfaf7",
        "axes.facecolor": "#fbfaf7",
        "savefig.facecolor": "#fbfaf7",
    }
)
families = [
    "lookup",
    "creation",
    "lifecycle",
    "transitions",
    "redundant",
    "payload",
    "queries",
    "query_lifecycle",
    "frames",
    "frame_commands",
    "systems",
]
families = [f for f in families if any(r["family"] == f for r in rows)]
fig, ax = plt.subplots(figsize=(10, 6.4))
for index, f in enumerate(families):
    data = [r for r in rows if r["family"] == f]
    win = sum(float(r["cedarecs_p75_ns"]) < float(r["flecs_p25_ns"]) for r in data)
    loss = sum(float(r["flecs_p75_ns"]) < float(r["cedarecs_p25_ns"]) for r in data)
    counts = [win, len(data) - win - loss, loss]
    left = 0
    for j, count in enumerate(counts):
        ax.barh(
            index,
            count,
            left=left,
            color=colors[j],
            height=0.62,
            label=[
                "Cedar lower · disjoint IQR",
                "Overlapping IQR",
                "Flecs lower · disjoint IQR",
            ][j]
            if index == 0
            else None,
        )
        if count >= 4:
            ax.text(
                left + count / 2,
                index,
                str(count),
                ha="center",
                va="center",
                color="white" if j != 1 else "#333333",
                fontsize=9,
            )
        left += count
    ax.text(left + 1, index, f"n={len(data)}", va="center", fontsize=9, color="#555555")
ax.set_yticks(
    range(len(families)), [s.replace("_", " ").capitalize() for s in families]
)
ax.invert_yaxis()
ax.set_xlim(0, 94)
ax.set_xlabel("Configurations · compare within each case and unit")
ax.grid(axis="x", alpha=0.12)
ax.set_axisbelow(True)
ax.legend(loc="lower right", frameon=False, fontsize=8)
fig.suptitle(
    f"Expanded C suite · {len(rows)} configurations",
    x=0.035,
    ha="left",
    fontsize=19,
    fontweight="bold",
)
fig.text(
    0.035,
    0.91,
    "Apple M4 Pro · nine retained samples per engine per case · current experimental Cedar / pinned Flecs development build",
    fontsize=9,
    color="#555555",
)
fig.text(
    0.035,
    0.025,
    "IQR overlap is not a proof of equivalence. Different axes deliberately change case weighting; this is not a combined ranking.\nNative frames use different partitioning/merge APIs. Deferred commands can coalesce. See README.md and comparison.md.",
    fontsize=8,
    color="#555555",
)
fig.tight_layout(rect=(0.02, 0.08, 0.99, 0.9))
fig.savefig(root / "overview.png", dpi=180)
fig.savefig(root / "overview.svg")
plt.close(fig)

fig, axes = plt.subplots(1, 3, figsize=(12, 4.5), squeeze=False)
for ax, n in zip(axes[0], (1000, 100000, 1000000)):
    data = [
        r
        for r in rows
        if r["scenario"] == "frame"
        and int(r["entities"]) == n
        and r["width"] == "1"
        and r["bits"] == "0"
        and r["systems"] == "1"
        and r["rounds"] == "1"
    ]
    for grain, color in zip((64, 1024, 16384), ("#6ab193", "#23785a", "#185640")):
        subset = sorted(
            [r for r in data if int(r["grain"]) == grain],
            key=lambda r: int(r["threads"]),
        )
        ax.plot(
            [int(r["threads"]) for r in subset],
            [float(r["cedarecs_median_ns"]) * n / 1000 for r in subset],
            "o-",
            label=f"Cedar grain {grain}",
            color=color,
            markersize=4,
        )
    subset = sorted(
        [r for r in data if r["grain"] == "1024"], key=lambda r: int(r["threads"])
    )
    ax.plot(
        [int(r["threads"]) for r in subset],
        [float(r["flecs_median_ns"]) * n / 1000 for r in subset],
        "o-",
        label="Flecs native partition",
        color="#5658b8",
        markersize=4,
    )
    ax.set_title(f"{n:,} entities", loc="left")
    ax.set_xticks((1, 2, 4, 8, 14))
    ax.set_xlabel("Threads, including caller")
    ax.set_ylabel("Microseconds / frame")
    ax.set_yscale("log")
    ax.yaxis.set_major_formatter(ScalarFormatter())
    ax.grid(alpha=0.15)
axes[0, 0].legend(frameon=False, fontsize=7)
fig.suptitle(
    "Grain sensitivity · one system, one uint64 field",
    x=0.035,
    ha="left",
    fontsize=18,
    fontweight="bold",
)
fig.text(
    0.035,
    0.025,
    "Lower is better; logarithmic time axes. Flecs chooses its own partitions; its shown reference is the grain=1024 paired case.\nAll same-workload Flecs repeats remain in the raw data. Shared compiled kernel, no CPU affinity or frequency controls.",
    fontsize=8,
    color="#555555",
)
fig.tight_layout(rect=(0.02, 0.11, 0.99, 0.91))
fig.savefig(root / "grain.png", dpi=180)
fig.savefig(root / "grain.svg")
plt.close(fig)
(root / "plot_metadata.json").write_text(
    json.dumps(
        {
            "matplotlib": matplotlib.__version__,
            "rendered_utc": datetime.now(timezone.utc).isoformat(),
            "plot_script_sha256": hashlib.sha256(
                Path(__file__).read_bytes()
            ).hexdigest(),
            "summary_sha256": hashlib.sha256(
                (root / "summary.csv").read_bytes()
            ).hexdigest(),
        },
        indent=2,
    )
    + "\n"
)
print(root / "overview.png")
