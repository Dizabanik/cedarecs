#!/usr/bin/env python3
"""Audit every retained parameterized measurement, without rerunning timings."""

import argparse
import csv
import hashlib
import json
import statistics
from collections import defaultdict
from pathlib import Path
from catalog import DEFAULTS, case_id, operations


def validate(root):
    meta = json.loads((root / "metadata.json").read_text())
    assert meta["suite"] == "expanded-v1" and "completed_utc" in meta
    configs = {case_id(c): c for c in meta["cases"]}
    assert len(configs) == len(meta["cases"])
    groups = defaultdict(list)
    for line in (root / "raw.jsonl").read_text().splitlines():
        r = json.loads(line)
        assert r["case"] in configs
        groups[r["case"]].append(r)
    summary = {r["case"]: r for r in csv.DictReader((root / "summary.csv").open())}
    assert set(groups) == set(configs) == set(summary)
    count = 0
    for key, rows in groups.items():
        c = configs[key]
        s = summary[key]
        count += len(rows)
        assert len(rows) == meta["repeats"] * 2
        assert (
            len({r["checksum"] for r in rows})
            == len({r["iterations"] for r in rows})
            == len({r["unit"] for r in rows})
            == len({r["matched"] for r in rows})
            == 1
        )
        for t in range(meta["repeats"]):
            pair = [r for r in rows if r["trial"] == t]
            assert len(pair) == 2 and {r["engine"] for r in pair} == {
                "cedarecs",
                "flecs",
            }
            assert {r["order_index"] for r in pair} == {0, 1}
        for e in ("cedarecs", "flecs"):
            samples = [r for r in rows if r["engine"] == e]
            assert len(samples) == meta["repeats"]
            version = meta["provenance"][e][
                "snapshot_sha256" if e == "cedarecs" else "commit"
            ]
            for r in samples:
                assert (
                    r["version"] == version
                    and r["scenario"] == c["scenario"]
                    and r["family"] == c["family"]
                )
                assert all(r[k] == c[k] for k in DEFAULTS)
                assert r["operations"] == operations(c, r["iterations"])
                assert r["elapsed_ns"] > 0 and r["peak_rss_bytes"] > 0
                assert abs(r["ns_per_op"] - r["elapsed_ns"] / r["operations"]) < 1e-8
            values = [r["ns_per_op"] for r in samples]
            q = statistics.quantiles(values, n=4, method="inclusive")
            expected = {
                "median": statistics.median(values),
                "p25": q[0],
                "p75": q[2],
                "min": min(values),
                "max": max(values),
            }
            for stat, value in expected.items():
                assert abs(float(s[f"{e}_{stat}_ns"]) - value) < 1e-8
        assert (
            abs(
                float(s["flecs_over_cedar"])
                - float(s["flecs_median_ns"]) / float(s["cedarecs_median_ns"])
            )
            < 1e-10
        )
    if (root / "plot_metadata.json").exists():
        p = json.loads((root / "plot_metadata.json").read_text())
        assert (
            p["summary_sha256"]
            == hashlib.sha256((root / "summary.csv").read_bytes()).hexdigest()
        )
    print(
        f"Verified {count} samples, {len(configs)} configurations, all parameters, checksums, pairing, source versions, operations, and summary statistics."
    )


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("results", type=Path)
    validate(p.parse_args().results)
