#!/usr/bin/env python3
"""Export all 386 packed case ratios; no selection or best-policy aggregation."""
import csv
import hashlib
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'results/memory-access-v42-packed'
before = ROOT / 'results/indexed-v25-packed/summary.csv'
after = OUT / 'summary.csv'
old = {r['case']: r for r in csv.DictReader(before.open())}
new = list(csv.DictReader(after.open()))
assert set(old) == {r['case'] for r in new} and len(new) == 386
labels = {'lookup':'Lookup', 'transitions':'Transitions', 'queries':'Queries',
          'query_lifecycle':'Queries', 'frames':'Frames/systems',
          'frame_commands':'Frames/systems', 'systems':'Frames/systems',
          'creation':'Entity lifecycle', 'lifecycle':'Entity lifecycle',
          'payload':'Payload/redundancy', 'redundant':'Payload/redundancy'}
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
fig, ax = plt.subplots(figsize=(8.8,7.2))
data = []
for r in new:
    previous = old[r['case']]
    data.append(dict(case=r['case'], family=r['family'],
                     previous_cedar_over_flecs=1/float(previous['flecs_over_cedar']),
                     current_cedar_over_flecs=1/float(r['flecs_over_cedar'])))
for group, color in zip(dict.fromkeys(labels.values()), ['#287c8e','#d28b30','#8164a9','#45876c','#b8646a','#7c8795']):
    subset = [r for r in data if labels[r['family']] == group]
    ax.scatter([r['previous_cedar_over_flecs'] for r in subset],
               [r['current_cedar_over_flecs'] for r in subset], s=27, alpha=.65,
               label=group, c=color, edgecolors='none')
values = [r[k] for r in data for k in ('previous_cedar_over_flecs','current_cedar_over_flecs')]
lo, hi = min(values)*.75, max(values)*1.3
ax.plot([lo,hi],[lo,hi],ls='--',lw=1,color='#888',label='Same paired ratio')
ax.axvline(1,color='#444',lw=1);ax.axhline(1,color='#444',lw=1)
ax.set(xscale='log',yscale='log',xlim=(lo,hi),ylim=(lo,hi),
       xlabel='Previous packed Cedar / paired Flecs median ns/op',
       ylabel='Current packed Cedar / paired Flecs median ns/op')
ax.grid(alpha=.13,which='both');ax.set_axisbelow(True)
ax.set_title('All 386 checked C cases: before and after',loc='left',fontweight='bold',fontsize=16,pad=18)
ax.legend(frameon=False,fontsize=9,loc='upper left')
fig.text(.13,.025,'Below 1 favors Cedar; below the diagonal improves the paired ratio. Each run measures both engines.\nBoth use the packed world policy. Workloads, kernels and competing binaries are fixed.',fontsize=9,color='#555')
fig.subplots_adjust(left=.13,right=.98,top=.9,bottom=.14)
outputs=[]
for ext in ('png','svg'):
    p=OUT/('before-after.'+ext);fig.savefig(p,dpi=180,facecolor='white');outputs.append(p)
plt.close(fig)
p=OUT/'before-after.csv'
with p.open('w',newline='') as f:
    writer=csv.DictWriter(f,list(data[0]));writer.writeheader();writer.writerows(data)
outputs.append(p)
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(OUT/'memory-plot-metadata.json').write_text(json.dumps(dict(
    inputs={str(p.relative_to(ROOT)):digest(p) for p in (before,after)},
    outputs={p.name:digest(p) for p in outputs}),indent=2)+'\n')
print('Exported all 386 case ratios to PNG, SVG and CSV')
