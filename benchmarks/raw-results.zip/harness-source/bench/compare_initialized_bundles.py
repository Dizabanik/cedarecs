#!/usr/bin/env python3
"""Pair old API and initialized construction in byte-identical executables."""
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import itertools
import json
import os
from pathlib import Path
import shutil
import statistics
import subprocess

ROOT = Path(__file__).resolve().parents[1]


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--build', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    engine = json.loads((ROOT / 'provenance.json').read_text())['cedarecs']
    for name, digest in engine['files'].items():
        assert sha(ROOT / name) == digest, name
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    binaries = {}
    for size in (16, 64, 512):
        for side in ('a', 'b'):
            dest = out / f'engine-{size}-{side}'
            shutil.copy2(args.build / f'bundle-bench-{size}', dest)
            binaries[size, side] = dest
        assert sha(binaries[size, 'a']) == sha(binaries[size, 'b'])
    cases = []
    for size, indexed, n, reverse, reserved in itertools.product(
            (16, 64, 512), (False, True), (1031, 65537), (False, True), (False, True)):
        cases.append(dict(bytes=size, indexed=indexed, entities=n, reverse=reverse,
                          reserved=reserved, family='prepared', passes=4 if reserved else 1))
    for size, indexed, reverse in itertools.product((16, 64, 512), (False, True), (False, True)):
        cases.append(dict(bytes=size, indexed=indexed, entities=1031, reverse=reverse,
                          reserved=False, family='one-shot', passes=1))
    meta = dict(started_utc=datetime.now(timezone.utc).isoformat(), cases=len(cases), repeats=16,
        source_sha256=sha(ROOT / 'bench/initialized_bundles.c'),
        engine=engine,
        methodology='Complete predeclared case sweep. Sequential processes; equal-length byte-identical binary paths; eight crossed environment paddings and both orders. No per-entity timers or benchmark method dispatch. Old prepared pointer arrays are built once outside the spawning loop. Both APIs validate all payload words, presence, generations, counts and checksums outside timing. Constructors compare the checked typed spawn-plus-set API with one initialized spawn. All samples retained.',
        binary_sha256={str(k): sha(v) for k, v in binaries.items()})
    shutil.copy2(__file__, out / 'runner.py')
    shutil.copy2(ROOT / 'bench/initialized_bundles.c', out / 'workload.c')
    (out / 'metadata.json').write_text(json.dumps(meta, indent=2) + '\n')
    summary, raw = [], []
    for index, case in enumerate(cases):
        rows = []
        for trial in range(16):
            order = ('old', 'new') if trial % 2 else ('new', 'old')
            for position, which in enumerate(order):
                kind = (0 if case['family'] == 'prepared' else 2) + (which == 'new')
                command = [str(binaries[case['bytes'], 'a' if which == 'old' else 'b']),
                    str(int(case['indexed'])), str(case['entities']), str(int(case['reverse'])),
                    str(kind), str(int(case['reserved'])), str(case['passes'])]
                environment = dict(os.environ, CEDAR_BENCH_STACK_PAD='x' * ((trial // 2) % 8) * 16)
                result = subprocess.run(command, text=True, capture_output=True, check=True,
                                        env=environment, timeout=120)
                row = json.loads(result.stdout)
                for key in ('bytes', 'indexed', 'entities', 'reverse', 'reserved', 'passes'):
                    assert row[key] == case[key], (key, row, case)
                assert row['kind'] == kind and row['ns_per_entity'] > 0
                row.update(family=case['family'], which=which, trial=trial, position=position)
                rows.append(row)
                raw.append(row)
                with (out / 'raw.jsonl').open('a') as f:
                    f.write(json.dumps(row) + '\n')
        assert len({r['checksum'] for r in rows}) == 1, case
        row = dict(case)
        for side in ('old', 'new'):
            samples = [r['ns_per_entity'] for r in rows if r['which'] == side]
            q = statistics.quantiles(samples, n=4, method='inclusive')
            row[side + '_median_ns'] = statistics.median(samples)
            row[side + '_p25_ns'], row[side + '_p75_ns'] = q[0], q[2]
        row['new_over_old'] = row['new_median_ns'] / row['old_median_ns']
        row['within_4_percent'] = row['new_over_old'] <= 1.04
        summary.append(row)
        print(f"{index + 1}/{len(cases)} {case}: {row['new_over_old']:.4f}", flush=True)
    with (out / 'summary.csv').open('w', newline='') as f:
        w = csv.DictWriter(f, list(summary[0]))
        w.writeheader()
        w.writerows(summary)
    meta.update(completed_utc=datetime.now(timezone.utc).isoformat(), samples=len(raw),
                regressions=[r for r in summary if not r['within_4_percent']])
    (out / 'metadata.json').write_text(json.dumps(meta, indent=2) + '\n')
    print(f"Completed {len(summary)} cases; {len(meta['regressions'])} exceed 4%.")


if __name__ == '__main__':
    main()
