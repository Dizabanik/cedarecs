#!/usr/bin/env python3
"""Audit retained records, checksums, counts, and exported summary statistics."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import statistics

parser = argparse.ArgumentParser()
parser.add_argument("results", type=Path)
args = parser.parse_args()
root = args.results
meta = json.loads((root / "metadata.json").read_text())
records = [json.loads(line) for line in (root / "raw.jsonl").read_text().splitlines()]
summary = list(csv.DictReader((root / "summary.csv").open()))
repeats = meta["repeats"]
assert len(records) == len(summary) * repeats * 2
keys = set()
for row in summary:
    key = (row["scenario"], int(row["entities"]), int(row["threads"]))
    assert key not in keys
    keys.add(key)
    group = [r for r in records if (r["scenario"], r["entities"], r["threads"]) == key]
    assert len(group) == repeats * 2
    assert len({r["checksum"] for r in group}) == 1
    assert len({r["iterations"] for r in group}) == 1
    assert len({r["operations"] for r in group}) == 1
    for trial in range(repeats):
        pair = [r for r in group if r["trial"] == trial]
        assert len(pair) == 2 and {r["engine"] for r in pair} == {"cedarecs", "flecs"}
        assert {r["order_index"] for r in pair} == {0, 1}
    for engine in ("cedarecs", "flecs"):
        samples = [r for r in group if r["engine"] == engine]
        expected_version = meta["provenance"][engine]["snapshot_sha256" if engine == "cedarecs" else "commit"]
        assert len(samples) == repeats and all(r["version"] == expected_version for r in samples)
        for r in samples:
            factor = 2 if r["scenario"] in ("add_remove", "defer_add_remove") else 1
            assert r["operations"] == r["entities"] * r["iterations"] * factor
            assert r["elapsed_ns"] > 0 and r["peak_rss_bytes"] > 0
            assert abs(r["ns_per_op"] - r["elapsed_ns"] / r["operations"]) < 1e-8
        values = [r["ns_per_op"] for r in samples]
        assert abs(statistics.median(values) - float(row[f"{engine}_median_ns"])) < 1e-10
        quartiles = statistics.quantiles(values, n=4, method="inclusive")
        assert abs(quartiles[0] - float(row[f"{engine}_p25_ns"])) < 1e-10
        assert abs(quartiles[2] - float(row[f"{engine}_p75_ns"])) < 1e-10
    assert abs(float(row["flecs_over_cedar"]) - float(row["flecs_median_ns"]) / float(row["cedarecs_median_ns"])) < 1e-10
if (root / "plot_metadata.json").exists():
    plots = json.loads((root / "plot_metadata.json").read_text())
    assert plots["summary_sha256"] == hashlib.sha256((root / "summary.csv").read_bytes()).hexdigest()
print(f"Verified {len(records)} samples, {len(summary)} cases, matching checksums, paired order, source versions, operation counts, and summary statistics.")
