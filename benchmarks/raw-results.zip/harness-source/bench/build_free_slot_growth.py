#!/usr/bin/env python3
"""Build the same stress driver against two verified immutable ECS snapshots."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--baseline-label', required=True)
    p.add_argument('--candidate-label', required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    commands, versions, sources = {}, {}, {}
    for key, label in [('baseline', args.baseline_label), ('candidate', args.candidate_label)]:
        snapshot = ROOT / 'variants' / label
        engine = json.loads((snapshot / 'provenance.json').read_text())['cedarecs']
        assert engine['label'] == label
        for name, digest in engine['files'].items():
            assert sha(snapshot / name) == digest, name
        versions[key] = engine['snapshot_sha256']
        inputs = [ROOT / 'bench/free_slot_growth.c', *sorted((snapshot / 'cedarecs/ecs').glob('*.c')),
                  snapshot / 'cedarecs/wexds.c']
        command = ['clang', '-std=c11', '-D_POSIX_C_SOURCE=200809L', '-D_DARWIN_C_SOURCE', '-pthread',
                   '-O3', '-DNDEBUG', '-march=native', '-Wall', '-Wextra', '-Wpedantic', '-Werror',
                   '-I' + str(snapshot), '-I' + str(ROOT), '-DCEDAR_SNAPSHOT="' + versions[key] + '"',
                   *map(str, inputs), '-lm', '-o', str(out / key)]
        subprocess.run(command, check=True)
        commands[key] = command
        sources[key] = engine
    shutil.copy2(__file__, out / 'build.py')
    shutil.copy2(ROOT / 'bench/free_slot_growth.c', out / 'workload.c')
    (out / 'manifest.json').write_text(json.dumps(dict(commands=commands, versions=versions, sources=sources,
        compiler=subprocess.check_output(['clang', '--version'], text=True),
        binaries={k: sha(out / k) for k in commands}, workload_sha256=sha(out / 'workload.c')), indent=2) + '\n')


if __name__ == '__main__':
    main()
