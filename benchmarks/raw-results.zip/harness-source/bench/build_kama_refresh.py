"""Build exact before/after map probes and an isolated concurrent ECS registry."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'build/kama-refresh'
OUT.mkdir(exist_ok=True)
OLD = ROOT / 'validation/kama-refresh-v106/baseline'
CONCURRENT = ROOT
commands = []
flags = ['clang', '-std=c11', '-D_POSIX_C_SOURCE=200809L', '-D_DARWIN_C_SOURCE',
         '-O3', '-DNDEBUG', '-march=native', '-pthread', '-Wall', '-Wextra', '-Werror']
for key, folder in [('old', OLD), ('new', ROOT), ('conc', CONCURRENT)]:
    selected = [*flags, *(['-DCEDARECS_CONCURRENT_REGISTRY=1'] if key == 'conc' else [])]
    if key != 'conc':
        command = [*selected, '-I' + str(folder), '-DKAMA_VERSION="' + key + '"',
                   str(ROOT / 'bench/kama_workloads.c'), '-o', str(OUT / ('map-' + key))]
        subprocess.run(command, check=True); commands.append(command)
    sources = sorted((folder / 'cedarecs/ecs').glob('*.c')) + [folder / 'cedarecs/wexds.c']
    objects = []
    dest = OUT / key; dest.mkdir(exist_ok=True)
    for source in sources:
        obj = dest / (source.stem + '.o')
        command = [*selected, '-I' + str(folder), '-c', str(source), '-o', str(obj)]
        subprocess.run(command, check=True); commands.append(command); objects.append(obj)
    command = [*selected, '-I' + str(folder), '-DCEDAR_BUILD_SNAPSHOT="' + key + '"',
               str(ROOT / 'bench/registry_workloads.c'), *map(str, objects), '-lm',
               '-o', str(OUT / ('registry-' + key))]
    subprocess.run(command, check=True); commands.append(command)
(OUT / 'build.json').write_text(json.dumps(dict(commands=commands,
    inputs={str(p): hashlib.sha256(p.read_bytes()).hexdigest()
            for folder in (OLD, ROOT, CONCURRENT)
            for p in [*sorted((folder/'cedarecs').rglob('*.c')),
                      *sorted((folder/'cedarecs').rglob('*.h')), *sorted((folder/'kama').glob('*.h'))]},
    binaries={p.name: hashlib.sha256(p.read_bytes()).hexdigest()
              for p in OUT.iterdir() if p.is_file() and p.name != 'build.json'}), indent=2) + '\n')
print('Map and registry controls/candidates built')
