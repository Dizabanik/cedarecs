// Same source against both pinned dependencies; no replacement hash algorithm.
#include <kama/kama.h>
#include <assert.h>
#include <stdbool.h>
#include <inttypes.h>
#include <stdio.h>
#include <time.h>

#ifndef KAMA_VERSION
#define KAMA_VERSION "unknown"
#endif
kama_u64(numbers, uint64_t)
kama(strings, uint64_t)
kama_fixed(signatures, 32, uint64_t)

static uint64_t clock_ns(void) {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC_RAW, &t);
    return (uint64_t)t.tv_sec * UINT64_C(1000000000) + (uint64_t)t.tv_nsec;
}
static void require(bool ok) { if (!ok) abort(); }
static uint64_t mix(uint64_t n) { return n * UINT64_C(11400714819323198485); }

int main(int argc, char **argv) {
    if (argc != 5) return 2;
    unsigned kind = (unsigned)strtoul(argv[1], NULL, 10);
    size_t count = strtoull(argv[2], NULL, 10), passes = strtoull(argv[3], NULL, 10);
    bool long_names = atoi(argv[4]) != 0;
    require(count && !(count & (count - 1)) && passes && kind < 7);
    numbers_t ints = {0}; strings_t names = {0}; signatures_t masks = {0};
    char (*keys)[96] = calloc(count, sizeof(*keys));
    unsigned char (*bits)[32] = calloc(count, sizeof(*bits));
    require(keys && bits);
    size_t *lengths = calloc(count, sizeof(*lengths)); require(lengths != NULL);
    for (size_t i = 0; i < count; ++i) {
        int n = snprintf(keys[i], sizeof(keys[i]), long_names ?
            "game::simulation::component::%08zu::position_velocity_payload" : "%07zu", i);
        require(n > 0 && (size_t)n < sizeof(keys[i])); lengths[i] = (size_t)n;
        uint64_t key = mix(i + 1); memcpy(bits[i], &key, sizeof(key));
        if (kind != 0) require(numbers_put(&ints, mix(i), i + 7) != KAMA_ERROR);
        require(strings_put(&names, keys[i], lengths[i], i + 7) != KAMA_ERROR);
        require(signatures_put(&masks, bits[i], i + 7) != KAMA_ERROR);
    }
    uint64_t sum = 0, expected = 0, start = clock_ns();
    for (size_t p = 0; p < passes; ++p) {
        if (kind == 0) numbers_clear(&ints);
        for (size_t j = 0; j < count; ++j) {
            size_t i = (j * 8191 + 17) & (count - 1); uint64_t v = 0;
            switch (kind) {
            case 0: require(numbers_put(&ints, mix(i), i + 7) != KAMA_ERROR); break;
            case 1: require(numbers_get(&ints, mix(i), &v)); sum += v; break;
            case 2: require(numbers_put(&ints, mix(i), i + p + 7) != KAMA_ERROR); break;
            case 3: require(strings_get(&names, keys[i], lengths[i], &v)); sum += v; break;
            case 4: require(strings_put(&names, keys[i], lengths[i], i + p + 7) != KAMA_ERROR); break;
            case 5: require(signatures_get(&masks, bits[i], &v)); sum += v; break;
            case 6:
                require(numbers_delete(&ints, mix(i)));
                require(numbers_put(&ints, mix(i), i + 7) != KAMA_ERROR); break;
            }
        }
    }
    uint64_t elapsed = clock_ns() - start;
    if (kind == 1 || kind == 3 || kind == 5) {
        expected = passes * (count * (count - 1) / 2 + 7 * count); require(sum == expected);
    }
    for (size_t i = 0; i < count; ++i) {
        uint64_t v = 0;
        require(numbers_get(&ints, mix(i), &v));
        require(v == i + 7 + (kind == 2 ? passes - 1 : 0));
        require(strings_get(&names, keys[i], lengths[i], &v));
        require(v == i + 7 + (kind == 4 ? passes - 1 : 0));
        require(signatures_get(&masks, bits[i], &v) && v == i + 7);
    }
    printf("{\"version\":\"%s\",\"kind\":%u,\"count\":%zu,\"passes\":%zu,"
           "\"long_names\":%d,\"checksum\":%" PRIu64 ",\"operations\":%zu,\"ns_per_op\":%.9f}\n",
           KAMA_VERSION, kind, count, passes, long_names, sum,
           count * passes, (double)elapsed / (double)(count * passes));
    numbers_free(&ints); strings_free(&names); signatures_free(&masks);
    free(keys); free(bits); free(lengths); return 0;
}
