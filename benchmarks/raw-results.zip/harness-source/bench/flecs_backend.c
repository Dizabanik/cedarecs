#include "bench.h"
#include <flecs.h>

#ifndef FLECS_COMMIT
#define FLECS_COMMIT "unrecorded"
#endif
const char *bench_engine(void) { return "flecs"; }
const char *bench_version(void) { return FLECS_COMMIT; }

typedef struct World {
    ecs_world_t *ecs, *commands;
    ecs_entity_t position, velocity, health;
    ecs_table_t *tables[64];
    ecs_query_t *query;
    bool query_borrowed, heavy;
} World;
static ecs_entity_t component(World *w, const char *name, size_t size, size_t alignment) {
    ecs_entity_t entity = ecs_entity_init(w->ecs, &(ecs_entity_desc_t){.name = name, .use_low_id = true});
    CHECK(entity);
    if (!size) return entity;
    ecs_entity_t id = ecs_component_init(w->ecs, &(ecs_component_desc_t){.entity = entity, .type = {.size = (ecs_size_t)size, .alignment = (ecs_size_t)alignment}});
    CHECK(id); return id;
}
static World *world_new(size_t archetypes) {
    World *w = calloc(1, sizeof(*w)); CHECK(w);
    w->ecs = ecs_init(); CHECK(w->ecs); w->commands = w->ecs;
    w->position = component(w, "Position", sizeof(Position), _Alignof(Position));
    w->velocity = component(w, "Velocity", sizeof(Velocity), _Alignof(Velocity));
    w->health = component(w, "Health", sizeof(Health), _Alignof(Health));
    ecs_id_t tags[6];
    for (size_t i = 0; i < 6; i++) {
        char name[32]; snprintf(name, sizeof(name), "Group%zu", i);
        tags[i] = component(w, name, 0, 1);
    }
    for (size_t group = 0; group < archetypes; group++) {
        ecs_id_t type[8] = {w->position, w->velocity};
        int32_t count = 2;
        for (size_t i = 0; i < 6; i++) if (group & ((size_t)1 << i)) type[count++] = tags[i];
        // Registration uses monotonically allocated low IDs, so these are sorted.
        w->tables[group] = ecs_table_find(w->ecs, type, count); CHECK(w->tables[group]);
    }
    return w;
}
static void world_delete(World *w) {
    if (w->query && !w->query_borrowed) ecs_query_fini(w->query);
    ecs_fini(w->ecs); free(w);
}
static inline Entity entity_new_empty(World *w) { return ecs_new(w->ecs); }
static inline Entity entity_new_pv(World *w, size_t group) { return ecs_new_w_table(w->ecs, w->tables[group]); }
static inline void assign_initial(World *w, Entity e, size_t i) {
    *(Position *)ecs_get_mut_id(w->ecs, e, w->position) = initial_position(i);
    *(Velocity *)ecs_get_mut_id(w->ecs, e, w->velocity) = initial_velocity(i);
}
static inline const Position *entity_position(World *w, Entity e) { return ecs_get_id(w->ecs, e, w->position); }
static inline void entity_write_position(World *w, Entity e, Position p) { *(Position *)ecs_get_mut_id(w->ecs, e, w->position) = p; }
static inline void entity_set_position(World *w, Entity e, Position p) { ecs_set_id(w->ecs, e, w->position, sizeof(p), &p); }
static inline void entity_delete(World *w, Entity e) { ecs_delete(w->ecs, e); }
static inline bool entity_alive(World *w, Entity e) { return ecs_is_alive(w->ecs, e); }
static inline uint64_t entity_health_value(World *w, Entity e) { return ((const Health *)ecs_get_id(w->ecs, e, w->health))->value; }
static inline bool entity_has_health(World *w, Entity e) { return ecs_has_id(w->ecs, e, w->health); }
static inline void changes_begin(World *w, bool defer) { w->commands = defer ? ecs_get_stage(w->ecs, 0) : w->ecs; }
static inline void changes_end(World *w, bool defer) { if (defer) ecs_merge(w->commands); w->commands = w->ecs; }
static inline void entity_health(World *w, Entity e, uint64_t value) {
    Health health = {value}; ecs_set_id(w->commands, e, w->health, sizeof(health), &health);
}
static inline void entity_remove_health(World *w, Entity e) { ecs_remove_id(w->commands, e, w->health); }
static ecs_query_desc_t query_desc(World *w) {
    return (ecs_query_desc_t){.terms = {{.id = w->position, .inout = EcsInOut}, {.id = w->velocity, .inout = EcsIn}}, .cache_kind = EcsQueryCacheAll};
}
static void query_prepare(World *w) { ecs_query_desc_t desc = query_desc(w); w->query = ecs_query_init(w->ecs, &desc); CHECK(w->query); }
static void query_move(World *w) {
    ecs_iter_t it = ecs_query_iter(w->ecs, w->query);
    while (ecs_query_next(&it)) bench_light(ecs_field(&it, Position, 0), ecs_field(&it, Velocity, 1), (size_t)it.count);
}
static size_t query_entity_count(World *w) { return (size_t)ecs_query_count(w->query).entities; }
static void frame_callback(ecs_iter_t *it) {
    World *w = it->ctx;
    Position *p = ecs_field(it, Position, 0);
    const Velocity *v = ecs_field(it, Velocity, 1);
    if (w->heavy) bench_heavy(p, v, (size_t)it->count); else bench_light(p, v, (size_t)it->count);
}
static void frame_prepare(World *w, size_t threads, bool heavy) {
    w->heavy = heavy;
    ecs_entity_t system = ecs_system_init(w->ecs, &(ecs_system_desc_t){.query = query_desc(w), .phase = EcsOnUpdate, .callback = frame_callback, .ctx = w, .multi_threaded = true});
    CHECK(system);
    w->query = ecs_system_get(w->ecs, system)->query;
    w->query_borrowed = true;
    ecs_set_threads(w->ecs, (int32_t)threads);
}
static void frame_move(World *w) { CHECK(ecs_progress(w->ecs, 1.0f / 60.0f)); }
#include "workloads.inc"
