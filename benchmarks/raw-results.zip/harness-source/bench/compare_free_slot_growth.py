#!/usr/bin/env python3
"""Paired complete clear-and-grow stress cases, with full generation checks."""
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import itertools
import json
import os
from pathlib import Path
import shutil
import statistics
import subprocess


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--baseline', type=Path, required=True)
    p.add_argument('--candidate', type=Path, required=True)
    p.add_argument('--baseline-version', required=True)
    p.add_argument('--candidate-version', required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    binaries = {}
    versions = dict(baseline=args.baseline_version, candidate=args.candidate_version)
    for key, source, letter in [('baseline', args.baseline, 'a'), ('candidate', args.candidate, 'b')]:
        binaries[key] = out / ('engine-' + letter)
        shutil.copy2(source, binaries[key])
    shutil.copy2(__file__, out / 'runner.py')
    shutil.copy2(Path(__file__).with_name('free_slot_growth.c'), out / 'workload.c')
    cases = list(itertools.product((False, True), (1031, 65537, 262145), (1, 4097), (False, True)))
    meta = dict(started_utc=datetime.now(timezone.utc).isoformat(), versions=versions,
                binary_sha256={k: sha(v) for k, v in binaries.items()},
                workload_sha256=sha(out / 'workload.c'), repeats=16, cases=len(cases),
                method='Fixed eight clear/grow cycles; complete 24-case sweep; equal-length paths; alternating AB/BA crossed with eight environment paddings. No result selection. Full index uniqueness, generation, liveness and operation validation after timed loops.')
    (out / 'metadata.json').write_text(json.dumps(meta, indent=2) + '\n')
    summary, raw = [], []
    for index, (indexed, initial, step, reverse) in enumerate(cases):
        rows = []
        for trial in range(16):
            order = ('baseline', 'candidate') if trial % 2 else ('candidate', 'baseline')
            for position, key in enumerate(order):
                env = dict(os.environ, CEDAR_BENCH_STACK_PAD='x' * ((trial // 2) % 8) * 16)
                result = subprocess.run([str(binaries[key]), str(int(indexed)), str(initial), '8', str(step), str(int(reverse))],
                                        env=env, capture_output=True, text=True, check=True, timeout=60)
                row = json.loads(result.stdout)
                assert row['version'] == versions[key] and row['ns_per_op'] > 0
                assert (row['indexed'], row['initial'], row['cycles'], row['step'], row['reverse']) == (indexed, initial, 8, step, reverse)
                row.update(which=key, trial=trial, position=position)
                rows.append(row)
                raw.append(row)
                with (out / 'raw.jsonl').open('a') as f:
                    f.write(json.dumps(row) + '\n')
        for field in ('checksum', 'operations'):
            assert len({r[field] for r in rows}) == 1
        row = dict(indexed=indexed, initial=initial, step=step, reverse=reverse)
        for key in binaries:
            samples = [r['ns_per_op'] for r in rows if r['which'] == key]
            q = statistics.quantiles(samples, n=4, method='inclusive')
            row[key + '_median_ns'] = statistics.median(samples)
            row[key + '_p25_ns'], row[key + '_p75_ns'] = q[0], q[2]
        row['candidate_over_baseline'] = row['candidate_median_ns'] / row['baseline_median_ns']
        row['within_4_percent'] = row['candidate_over_baseline'] <= 1.04
        summary.append(row)
        print(f"{index + 1}/{len(cases)}: {indexed=} {initial=} {step=} {reverse=}: {row['candidate_over_baseline']:.4f}", flush=True)
    with (out / 'summary.csv').open('w', newline='') as f:
        writer = csv.DictWriter(f, list(summary[0]))
        writer.writeheader()
        writer.writerows(summary)
    meta.update(completed_utc=datetime.now(timezone.utc).isoformat(), samples=len(raw),
                regressions=[r for r in summary if not r['within_4_percent']])
    (out / 'metadata.json').write_text(json.dumps(meta, indent=2) + '\n')
    print(f"Completed {len(summary)} cases; {len(meta['regressions'])} exceed 4%.")


if __name__ == '__main__':
    main()
