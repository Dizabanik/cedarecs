#!/usr/bin/env python3
"""Record an explicitly named experimental Cedar revision before benchmarking."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('label')
args = parser.parse_args()
if not args.label.replace('-', '').replace('_', '').isalnum():
    parser.error('Use an alphanumeric variant name with hyphens/underscores')
baseline = ROOT / 'variants/baseline'
for name in ('workloads.inc', 'kernel.c', 'main.c', 'flecs_backend.c', 'bench.h'):
    if (ROOT / 'bench' / name).read_bytes() != (baseline / name).read_bytes():
        raise SystemExit(f'Frozen workload or Flecs adapter changed: {name}')
files = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
         for p in sorted((ROOT / 'cedarecs').rglob('*'))
         if p.is_file() and '.git' not in p.relative_to(ROOT/'cedarecs').parts}
manifest = json.loads((ROOT / 'provenance.json').read_text())
manifest['cedarecs'].update(label=args.label,
    derived_from=json.loads((baseline / 'provenance.json').read_text())['cedarecs']['snapshot_sha256'],
    recorded_utc=datetime.now(timezone.utc).isoformat(), files=files,
    snapshot_sha256=hashlib.sha256(''.join(k+':'+v+'\n' for k,v in files.items()).encode()).hexdigest(),
    benchmark_adapter_sha256=hashlib.sha256((ROOT/'bench/cedar_backend.c').read_bytes()).hexdigest())
destination = ROOT / 'variants' / args.label
destination.mkdir(parents=True, exist_ok=False)
shutil.copytree(ROOT/'cedarecs', destination/'cedarecs', ignore=shutil.ignore_patterns('.git'))
shutil.copytree(ROOT/'kama', destination/'kama', ignore=shutil.ignore_patterns('.git'))
shutil.copy2(ROOT/'bench/cedar_backend.c', destination/'cedar_backend.c')
shutil.copytree(ROOT/'bench/expanded', destination/'expanded',
                ignore=shutil.ignore_patterns('__pycache__'))
shutil.copytree(ROOT/'interop/abeimler', destination/'interop',
                ignore=shutil.ignore_patterns('__pycache__'))
for path in (ROOT/'provenance.json', destination/'provenance.json'):
    path.write_text(json.dumps(manifest, indent=2)+'\n')
print(args.label, manifest['cedarecs']['snapshot_sha256'])
