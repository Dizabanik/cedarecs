#!/usr/bin/env python3
"""Export every fixed-policy C result and paired entity read measurements."""
from pathlib import Path
import csv, json, hashlib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'results/indexed-v25-packed'
def rows(run):
    return list(csv.DictReader((ROOT/'results'/run/'summary.csv').open()))
packed={r['case']:r for r in rows('indexed-v25-packed')}
indexed={r['case']:r for r in rows('indexed-v25-slots')}
plt.rcParams.update({'font.family':'sans-serif','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
fig,ax=plt.subplots(figsize=(8.8,7.5))
labels={'lookup':'Lookup','transitions':'Transitions','queries':'Queries','query_lifecycle':'Queries','frames':'Frames/systems','frame_commands':'Frames/systems','systems':'Frames/systems','creation':'Entity lifecycle','lifecycle':'Entity lifecycle','payload':'Data/redundancy','redundant':'Data/redundancy'}
colors=dict(zip(dict.fromkeys(labels.values()),['#287c8e','#d28b30','#8164a9','#45876c','#b8646a','#7c8795']))
for group,color in colors.items():
    subset=[r for r in packed.values() if labels[r['family']]==group]
    x=[1/float(r['flecs_over_cedar']) for r in subset]
    y=[1/float(indexed[r['case']]['flecs_over_cedar']) for r in subset]
    ax.scatter(x,y,s=23,alpha=.62,c=color,label=group,edgecolors='none')
ax.axvline(1,color='#444',lw=1);ax.axhline(1,color='#444',lw=1)
ax.set_xscale('log');ax.set_yscale('log');ax.grid(alpha=.14,which='both');ax.set_axisbelow(True)
ax.set_xlabel('Packed Cedar / Flecs median ns/op (lower is better)')
ax.set_ylabel('Indexed Cedar / Flecs median ns/op (lower is better)')
ax.set_title('Storage tradeoffs across all 386 C cases',loc='left',fontweight='bold',fontsize=16,pad=18)
ax.legend(frameon=False,loc='upper left',fontsize=9)
fig.text(.13,.025,'Every dot is the same case measured under both fixed policies. Ratios below 1 favor Cedar.\nBoth C policies use checked access; no best-policy result is selected per case.',fontsize=9,color='#555')
fig.subplots_adjust(left=.13,right=.97,top=.9,bottom=.14)
outputs=[]
for ext in ('png','svg'):
    p=OUT/('storage-policies.'+ext);fig.savefig(p,dpi=180,facecolor='white');outputs.append(p)
plt.close(fig)
fig,axes=plt.subplots(1,2,figsize=(12.4,5.8),sharey=True)
frameworks=('cedar','entt','pico','flecs'); palette=['#27806a','#d69b38','#7760a7','#4b85b0']
inputs=[ROOT/'results'/r/'summary.csv' for r in ('indexed-v25-packed','indexed-v25-slots')]
for ax,(run,label) in zip(axes,[('multi-ecs-indexed-initialized-v24','Checked Cedar reads'),('multi-ecs-indexed-known-live-v25','Known-live required Cedar reads')]):
    data={r['benchmark']:r for r in rows(run)}
    raw=ROOT/'results'/run/'raw.jsonl'; inputs.extend([raw,ROOT/'results'/run/'summary.csv'])
    counts={r['name']:r.get('entities',0) for r in map(json.loads,raw.read_text().splitlines())}
    names=['BM_UnpackOneComponent/1024','BM_UnpackTwoComponents/1024','BM_UnpackThreeComponents/1024']
    x=np.arange(3); width=.18
    for j,(f,color) in enumerate(zip(frameworks,palette)):
        v=np.array([float(data[n][f+'_cpu_median_ns'])/counts[n] for n in names])
        low=np.array([float(data[n][f+'_cpu_p25_ns'])/counts[n] for n in names]);high=np.array([float(data[n][f+'_cpu_p75_ns'])/counts[n] for n in names])
        ax.bar(x+(j-1.5)*width,v,width,color=color,label=f,yerr=[v-low,high-v],capsize=2,error_kw={'lw':.8})
    ax.set_xticks(x,['Position','Position +\nVelocity','Position + Velocity\n+ optional Data'])
    ax.set_yscale('log');ax.set_title(label,loc='left',fontweight='bold',pad=14);ax.grid(axis='y',alpha=.15);ax.set_axisbelow(True)
axes[0].set_ylabel('Median CPU ns / iterated entity (log scale)')
axes[1].legend(frameon=False,fontsize=9)
fig.suptitle('Two access contracts, measured separately',x=.07,ha='left',fontsize=16,fontweight='bold')
fig.text(.07,.025,'Requested population: 1,024; three-component case iterates 512. Nine process rounds per framework per mode.\nCompetitors are measured within each paired run. Known-live Cedar reads require valid entities and required components.',fontsize=9,color='#555')
fig.subplots_adjust(left=.07,right=.985,top=.83,bottom=.2,wspace=.15)
for ext in ('png','svg'):
    p=OUT/('read-contracts.'+ext);fig.savefig(p,dpi=180,facecolor='white');outputs.append(p)
manifest={'inputs':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs},'outputs':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in outputs}}
(OUT/'indexed-plot-metadata.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Exported',*[str(p) for p in outputs])
