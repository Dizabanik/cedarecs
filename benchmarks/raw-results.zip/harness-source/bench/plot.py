#!/usr/bin/env python3
"""Render exported benchmark figures from summary.csv (optional Matplotlib)."""
import argparse
import csv
import json
import hashlib
from datetime import datetime, timezone
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import ScalarFormatter

parser = argparse.ArgumentParser()
parser.add_argument("results", type=Path)
args = parser.parse_args()
rows = list(csv.DictReader((args.results / "summary.csv").open()))
meta = json.loads((args.results / "metadata.json").read_text())
lookup = {(r["scenario"], int(r["entities"]), int(r["threads"])): r for r in rows}
colors = {"cedarecs": "#23785a", "flecs": "#5658b8"}
labels = {"cedarecs": "Cedar ECS", "flecs": "Flecs"}
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "axes.spines.top": False,
                     "axes.spines.right": False, "axes.titleweight": "bold", "figure.facecolor": "#fbfaf7",
                     "axes.facecolor": "#fbfaf7", "savefig.facecolor": "#fbfaf7", "axes.edgecolor": "#999999"})

scenarios = [("create_empty", "Create empty entity"), ("create_pv", "Create + initialize P/V"),
             ("iterate", "Cached query · 1 archetype"), ("iterate_fragmented", "Cached query · 64 archetypes"),
             ("random_get", "Random component lookup"), ("write_existing", "Get mutable + write"),
             ("set_existing", "Setter API"), ("add_remove", "Immediate add / remove"),
             ("defer_add_remove", "Deferred add / remove"), ("delete_pv", "Delete P/V entity")]
n = max(int(r["entities"]) for r in rows)
fig, ax = plt.subplots(figsize=(11, 7.2))
for engine, offset in (("cedarecs", -.18), ("flecs", .18)):
    values, lows, highs = [], [], []
    for scenario, _ in scenarios:
        r = lookup[scenario, n, 1]
        value = float(r[f"{engine}_median_ns"])
        values.append(value)
        lows.append(value - float(r[f"{engine}_p25_ns"]))
        highs.append(float(r[f"{engine}_p75_ns"]) - value)
    ax.errorbar(values, [i + offset for i in range(len(scenarios))],
                color=colors[engine], label=labels[engine], xerr=[lows, highs],
                fmt="o", markersize=6, capsize=3, linewidth=1.2)
ax.set_yticks(range(len(scenarios)), [label for _, label in scenarios])
ax.invert_yaxis(); ax.set_xscale("log")
ax.set_xlabel("Nanoseconds per operation · logarithmic scale · lower is better")
ax.xaxis.set_major_formatter(ScalarFormatter())
ax.grid(axis="x", which="major", alpha=.15); ax.set_axisbelow(True)
ax.legend(loc="lower right", frameon=False)
fig.suptitle(f"Cedar ECS vs Flecs · {n:,} entities", x=.04, ha="left", fontsize=19, fontweight="bold")
fig.text(.04, .923, f"{meta['system']['cpu']} · {meta['repeats']} samples per library · points: median, whiskers: interquartile range", color="#555555")
fig.text(.04, .025, "Query: one entity-update. Mutation: one add/set or removal. Setter APIs have different notification semantics.\nSynthetic release builds with matched data and kernels; feature sets differ. See comparison.md and README.md.", fontsize=8, color="#555555")
fig.tight_layout(rect=(.02, .07, .99, .9))
fig.savefig(args.results / "serial.png", dpi=180)
fig.savefig(args.results / "serial.svg")
plt.close(fig)

sizes = sorted({int(r["entities"]) for r in rows if r["scenario"].startswith("frame_")})
if sizes:
    fig, axes = plt.subplots(len(sizes), 2, figsize=(11, 3.4 * len(sizes)), squeeze=False)
    for row_index, count in enumerate(sizes):
        for col, scenario in enumerate(("frame_light", "frame_heavy")):
            ax = axes[row_index, col]
            threads = sorted(t for s, v, t in lookup if s == scenario and v == count)
            for engine in ("cedarecs", "flecs"):
                data = [lookup[scenario, count, t] for t in threads]
                values = [float(r[f"{engine}_median_ns"]) * count / 1e6 for r in data]
                lows = [float(r[f"{engine}_p25_ns"]) * count / 1e6 for r in data]
                highs = [float(r[f"{engine}_p75_ns"]) * count / 1e6 for r in data]
                ax.plot(threads, values, "o-", color=colors[engine], label=labels[engine], linewidth=2, markersize=4)
                ax.fill_between(threads, lows, highs, color=colors[engine], alpha=.12)
            ax.set_title(f"{'Light' if scenario == 'frame_light' else 'Compute-heavy'} kernel · {count:,} entities", loc="left")
            ax.set_xticks(threads); ax.set_xlabel("Threads (caller included)")
            ax.set_ylabel("Frame time (ms)"); ax.set_ylim(bottom=0)
            ax.grid(alpha=.15); ax.legend(frameon=False)
    fig.suptitle("Native frame execution and thread scaling", x=.035, ha="left", fontsize=19, fontweight="bold")
    fig.text(.035, .015, "Median ± IQR. Cedar: update_frame + parallel_each; Flecs: progress + multithreaded system.\nLower is better. Both use the identical compiled kernel; scheduler and merge overhead differ. No CPU affinity was enforced.", fontsize=8, color="#555555")
    fig.tight_layout(rect=(.02, .07, .99, .94))
    fig.savefig(args.results / "thread_scaling.png", dpi=180)
    fig.savefig(args.results / "thread_scaling.svg")
    plt.close(fig)
print(args.results / "serial.png")

(args.results / "plot_metadata.json").write_text(json.dumps({
    "rendered_utc": datetime.now(timezone.utc).isoformat(),
    "matplotlib": matplotlib.__version__,
    "plot_script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "summary_sha256": hashlib.sha256((args.results / "summary.csv").read_bytes()).hexdigest(),
}, indent=2) + "\n")
