#!/usr/bin/env python3
"""Apply the requested checked-performance floors to complete retained runs."""
import argparse
import csv
import json
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('--entities', type=Path, required=True)
p.add_argument('--original', type=Path, required=True)
p.add_argument('--packed', type=Path, required=True)
p.add_argument('--indexed', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
args = p.parse_args()


def load(path, expected):
    meta = json.loads((path/'metadata.json').read_text())
    rows = list(csv.DictReader((path/'summary.csv').open()))
    if 'completed_utc' not in meta or len(rows) != expected:
        raise SystemExit(f'Incomplete run: {path}')
    return meta, rows


em, entities = load(args.entities, 28)
if em.get('cedar_read_mode') != 'checked' or em['repeats'] < 9:
    raise SystemExit('Entity acceptance requires checked reads and nine process rounds')
for trial in range(em['repeats']):
    context = json.loads((args.entities/f'cedar-{trial}.json').read_text())['context']
    if context.get('cedar.read_contract') != 'checked' or context.get('cedar.snapshot') != em['cedar']['snapshot_sha256']:
        raise SystemExit('Compiled accessor contract or source snapshot mismatch')
gates = {}
for f, minimum in [('pico',26),('entt',27),('flecs',28)]:
    wins = sum(float(r['cedar_cpu_median_ns']) < float(r[f+'_cpu_median_ns']) for r in entities)
    gates['entities_vs_'+f] = dict(wins=wins, cases=28, minimum=minimum, passed=wins>=minimum)
for key, path, n, minimum in [('original',args.original,50,46),('packed',args.packed,386,341),('indexed',args.indexed,386,274)]:
    meta, rows = load(path,n)
    if meta['repeats'] < 9:
        raise SystemExit('C acceptance requires nine paired rounds')
    wins = sum(float(r['flecs_over_cedar']) > 1 for r in rows)
    gates[key] = dict(wins=wins, cases=n, minimum=minimum, passed=wins>=minimum)
result = dict(all_passed=all(g['passed'] for g in gates.values()), gates=gates,
              metric='lower paired medians per complete fixed dataset; no case/variant selection',
              limitations='Case floors are not a guarantee that every individual time is faster. Inspect IQRs and regressions in the full report.')
args.output.parent.mkdir(parents=True,exist_ok=True)
args.output.write_text(json.dumps(result,indent=2)+'\n')
for key, g in gates.items(): print(key, f"{g['wins']}/{g['cases']}", 'PASS' if g['passed'] else 'FAIL')
raise SystemExit(0 if result['all_passed'] else 1)
