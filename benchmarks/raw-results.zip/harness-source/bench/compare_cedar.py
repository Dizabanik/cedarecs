#!/usr/bin/env python3
"""Paired exact-control/candidate timings with a per-case 4% regression gate."""
import argparse
import csv
from datetime import datetime,timezone
import hashlib
import json
import math
import os
from pathlib import Path
import random
import re
import shutil
import statistics
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'bench/expanded'))
from catalog import DEFAULTS, operations, SINGLE_PASS
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    p=argparse.ArgumentParser();p.add_argument('--suite',choices=('original','packed','indexed'),required=True)
    p.add_argument('--control-label', default='checked-final-v53',
                   choices=sorted(x.name for x in (ROOT/'build/controls').iterdir() if (x/'manifest.json').is_file()),
                   help='Verified preserved control; defaults to the accepted v53 reference')
    p.add_argument('--scenario');p.add_argument('--repeats',type=int,default=9)
    p.add_argument('--case-filter',help='Optional regular expression on the complete case name')
    p.add_argument('--max-operations',type=int,default=2000000000)
    p.add_argument('--max-iterations',type=int,help='Override the iteration cap for very short queries; single-pass cases remain single-pass')
    p.add_argument('--target-ms',type=float,default=60)
    p.add_argument('--balanced-layout',action='store_true',help='Equal-length binary paths and eight crossed environment paddings')
    p.add_argument('--self-control',action='store_true',help='Measure the exact v53 binary on both sides')
    p.add_argument('--binary-set',type=Path,help='Verified additive harness build with baseline/candidate manifests')
    p.add_argument('--candidate-label',help='Measure an isolated immutable variant without activating it; requires --binary-set')
    p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    assert args.repeats>=3 and args.max_operations>0 and args.target_ms>0
    assert args.max_iterations is None or args.max_iterations>0
    if args.balanced_layout:assert args.repeats%16==0,'Balanced layout requires complete 16-round cycles'
    dataset='checked-final-v53-'+{'original':'original','packed':'packed','indexed':'slots'}[args.suite]
    reference=ROOT/'results'/dataset/'summary.csv'
    jobs=list(csv.DictReader(reference.open()))
    if args.scenario:jobs=[r for r in jobs if r['scenario'] in args.scenario.split(',')]
    if args.case_filter:
        jobs=[r for r in jobs if re.search(args.case_filter,r.get('case') or
            f"{r['scenario']}/entities={r['entities']},threads={r['threads']}")]
    assert jobs
    baseline=ROOT/'build/controls'/args.control_label/args.suite
    candidate=ROOT/'build'/dict(original='bench_cedarecs',packed='expanded/cedarecs',indexed='expanded-indexed/cedarecs')[args.suite]
    candidate_source=ROOT/'variants'/args.candidate_label if args.candidate_label else ROOT
    if args.candidate_label: assert args.binary_set, 'Isolated candidates require an exact binary-set manifest'
    provenance=json.loads((candidate_source/'provenance.json').read_text())['cedarecs']
    for name,digest in provenance['files'].items():assert sha(candidate_source/name)==digest,name
    old=json.loads((ROOT/'build/controls'/args.control_label/'manifest.json').read_text())
    harness=None
    if args.binary_set:
        folder=args.binary_set.resolve()
        alternate=json.loads((folder/'baseline/manifest.json').read_text())
        current=json.loads((folder/'candidate/manifest.json').read_text())
        assert alternate['engine']['snapshot_sha256']==old['engine']['snapshot_sha256']
        assert current['engine']['snapshot_sha256']==provenance['snapshot_sha256']
        for field in ('timer','shared_clocks','shared_kernels'):
            assert alternate[field]==current[field],field
        assert alternate['timer']=='CLOCK_MONOTONIC_RAW'
        baseline=folder/'baseline'/args.suite;candidate=folder/'candidate'/args.suite
        assert sha(candidate)==current['binaries'][args.suite]
        old=alternate
        harness={k:alternate[k] for k in ('timer','shared_clocks','shared_kernels')}
    assert sha(baseline)==old['binaries'][args.suite]
    if args.suite!='original' and args.max_iterations:
        supported=(harness or {}).get('shared_clocks',{}).get('expanded',{}).get('max_iterations',10000)
        assert args.max_iterations<=supported, 'Build an additive harness with the requested bounded iteration limit first'
    if args.self_control:candidate=baseline
    measured=old['engine'] if args.self_control else provenance
    versions={'baseline':old['engine']['snapshot_sha256'],'candidate':measured['snapshot_sha256']}
    iteration_limit=args.max_iterations or (10000 if args.suite!='original' else 100000)
    binaries={'baseline':baseline,'candidate':candidate}
    out=args.output.resolve();out.mkdir(parents=True,exist_ok=False)
    shutil.copy2(__file__,out/'compare-source.py')
    if args.balanced_layout:
        for which,letter in (('baseline','a'),('candidate','b')):
            target=out/('engine-'+letter)
            shutil.copy2(binaries[which],target);assert sha(target)==sha(binaries[which])
            binaries[which]=target
    meta=dict(suite='cedar-paired-native-v1',native_suite=args.suite,repeats=args.repeats,
              started_utc=datetime.now(timezone.utc).isoformat(),reference=str(reference),
              reference_sha256=sha(reference),binary_sha256={k:sha(v) for k,v in binaries.items()},
              versions=versions,candidate=measured,active_cedar=provenance,regression_limit=1.04,
              control_label=args.control_label,additive_harness=harness,
              balanced_layout=args.balanced_layout,self_control=args.self_control,
              target_ms=args.target_ms,max_operations=args.max_operations,
              max_iterations=iteration_limit,
              scenario_filter=args.scenario,case_filter=args.case_filter,runner_sha256=sha(Path(__file__)),
              methodology='One process at a time; identical iterations and inputs; alternating AB/BA within each case; two discarded warmup pairs; full checksum/operation parity. Optional balanced mode copies identical executables to equal-length paths and crosses eight environment padding lengths with both orders. Single-pass creation/deletion remain single-pass. All median regressions over 4% fail, regardless of case-win scores.')
    (out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
    def execute(which,r,iterations,padding=None):
        if args.suite=='original':
            command=[str(binaries[which]),r['scenario'],r['entities'],str(iterations),r['threads']]
        else:
            command=[str(binaries[which]),r['scenario']]
            for k in DEFAULTS:command+=['--'+k,str(r[k])]
            command+=['--iterations',str(iterations)]
        environment={**os.environ,'LC_ALL':'C'}
        if padding is not None:environment['CEDAR_BENCH_STACK_PAD']='x'*padding
        process=subprocess.run(command,text=True,capture_output=True,timeout=240,env=environment)
        if process.returncode or process.stderr:raise RuntimeError((command,process.returncode,process.stdout,process.stderr))
        result=json.loads(process.stdout)
        assert result['version']==versions[which] and result['elapsed_ns']>0
        if args.suite!='original':
            assert all(result[k]==int(r[k]) for k in DEFAULTS)
        return result
    def parity(a,b):
        for k in ('scenario','entities','iterations','threads','operations','checksum'):
            assert a[k]==b[k],(k,a,b)
        if args.suite!='original':
            for k in ('matched','unit'):assert a[k]==b[k],(k,a,b)
    rng=random.Random(0xCEDA);rng.shuffle(jobs);raw=[];summary=[]
    with (out/'raw.jsonl').open('w') as log:
        for i,r in enumerate(jobs):
            key=r.get('case') or f"{r['scenario']}/entities={r['entities']},threads={r['threads']}"
            single=r['scenario'] in (SINGLE_PASS if args.suite!='original' else {'create_empty','create_pv','delete_pv'})
            iterations=1 if single else int(r['iterations'])
            a=execute('baseline',r,iterations);b=execute('candidate',r,iterations);parity(a,b)
            if not single:
                factor=args.target_ms*1e6/min(a['elapsed_ns'],b['elapsed_ns'])
                desired=max(1,math.ceil(iterations*factor))
                per_iteration=a['operations']//iterations
                iterations=min(desired,iteration_limit,max(1,args.max_operations//max(1,per_iteration)))
            samples={'baseline':[],'candidate':[]}
            for trial in range(-2,args.repeats):
                order=('baseline','candidate') if (i+trial)%2 else ('candidate','baseline')
                padding=((max(trial,0)//2)%8)*16 if args.balanced_layout else None
                pair={}
                for position,which in enumerate(order):
                    result=execute(which,r,iterations,padding);pair[which]=result
                    if trial>=0:
                        record=dict(case=key,which=which,trial=trial,order=position,stack_padding=padding,**result)
                        raw.append(record);log.write(json.dumps(record)+'\n')
                        samples[which].append(result['ns_per_op'])
                parity(pair['baseline'],pair['candidate'])
            row=dict(case=key,iterations=iterations)
            for which,values in samples.items():
                q=statistics.quantiles(values,n=4,method='inclusive')
                row[which+'_median_ns']=statistics.median(values);row[which+'_p25_ns']=q[0];row[which+'_p75_ns']=q[2]
            row['candidate_over_baseline']=row['candidate_median_ns']/row['baseline_median_ns']
            row['within_4_percent']=row['candidate_over_baseline']<=1.04
            row['candidate_over_historical']=row['candidate_median_ns']/float(r['cedarecs_median_ns'])
            row['baseline_over_historical']=row['baseline_median_ns']/float(r['cedarecs_median_ns'])
            summary.append(row);log.flush()
            print(f"[{i+1}/{len(jobs)}] {key}: candidate/control {row['candidate_over_baseline']:.3f} {'PASS' if row['within_4_percent'] else 'FAIL'}",flush=True)
    with (out/'summary.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,list(summary[0]));writer.writeheader();writer.writerows(summary)
    meta.update(completed_utc=datetime.now(timezone.utc).isoformat(),cases=len(jobs),samples=len(raw),
                all_within_4_percent=all(r['within_4_percent'] for r in summary),
                regressions=[r for r in summary if not r['within_4_percent']])
    (out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
    print(f"Completed {len(jobs)} cases; {len(meta['regressions'])} exceed the 4% ceiling.")

if __name__=='__main__':main()
