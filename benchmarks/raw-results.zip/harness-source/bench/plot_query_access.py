#!/usr/bin/env python3
"""Export the fixed 1,024-population entity comparisons with quartile ranges."""
import csv
import hashlib
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
ROOT = Path(__file__).resolve().parents[1]
old = ROOT/'results/multi-ecs-20261026'
new = ROOT/'results/multi-ecs-query-access-v16'
out = ROOT/'results/query-access-v16-expanded'
def load(p):
    return {r['benchmark']: r for r in csv.DictReader((p/'summary.csv').open())}
a,b = load(old),load(new)
raw = [json.loads(s) for s in (new/'raw.jsonl').read_text().splitlines()]
counts = {r['name']: r['entities'] for r in raw if r.get('entities')}
cases = [('BM_CreateEntities','Create Position + Velocity'),
         ('BM_CreateEmptyEntities','Create empty entity'),
         ('BM_RemoveAddComponent','Remove + add Position'),
         ('BM_UnpackNoComponent','Read absent component'),
         ('BM_UnpackOneComponent','Read Position'),
         ('BM_UnpackTwoComponents','Read Position + Velocity')]
colors = ['#b9bec6','#22806b','#d99a32','#6757a8','#4d82ae']
labels = ['Previous\nCedar','Current\nCedar','EnTT\n3.13.2','pico_ecs\n2024 pin','Flecs\n4.0.1']
plt.rcParams.update({'font.family':'sans-serif','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
fig, axes = plt.subplots(2,3,figsize=(13,7.8))
for ax,(scenario,title) in zip(axes.flat,cases):
    name=scenario+'/1024'; n=counts[name]
    series=[(a[name],'cedar')]+[(b[name],k) for k in ('cedar','entt','pico','flecs')]
    mid=np.array([float(r[k+'_cpu_median_ns'])/n for r,k in series])
    low=np.array([float(r[k+'_cpu_p25_ns'])/n for r,k in series])
    high=np.array([float(r[k+'_cpu_p75_ns'])/n for r,k in series])
    ax.bar(range(5),mid,color=colors,width=.68,yerr=[mid-low,high-mid],capsize=3,error_kw={'lw':1})
    ax.set_yscale('log'); ax.set_xticks(range(5),labels,fontsize=9)
    ax.set_ylabel('CPU ns / entity (log scale)'); ax.set_title(title,loc='left',fontweight='bold',pad=16)
    ax.grid(axis='y',alpha=.15); ax.set_axisbelow(True)
    ax.set_ylim(min(mid)*.55,max(mid)*2.7)
    for i,v in enumerate(mid): ax.text(i,v*1.18,f'{v:.2f}',ha='center',va='bottom',fontsize=9)
fig.suptitle('Cedar improvements across four ECS implementations',x=.06,ha='left',fontsize=18,fontweight='bold')
fig.text(.06,.92,'Requested population: 1,024. Five independent process rounds; bars show medians, whiskers show p25–p75.',fontsize=11,color='#555555')
fig.text(.06,.025,'Apple M4 Pro · October 26, 2026 · Same upstream templates and competitor binaries\nCreation includes native registry teardown. These entity cases do not measure complete games or system integration.',fontsize=10,color='#555555')
fig.subplots_adjust(left=.06,right=.985,top=.85,bottom=.14,hspace=.48,wspace=.30)
files=[]
for ext in ('png','svg'):
    p=out/('entity-comparison.'+ext); fig.savefig(p,dpi=180,facecolor='white'); files.append(p)
manifest={'inputs': {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (old/'summary.csv',new/'summary.csv',new/'raw.jsonl')},
          'outputs': {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
(out/'entity-plot-metadata.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Exported',*[str(p) for p in files])
