"""Build and compare automatic policy, forced policies and exact v107 control."""
import argparse,csv,hashlib,itertools,json,os,shutil,statistics,subprocess
from datetime import datetime,timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--build-only',action='store_true');p.add_argument('--output',type=Path)
p.add_argument('--variant',default='automatic-registry-v110')
args=p.parse_args();build=ROOT/'build'/args.variant;build.mkdir(exist_ok=True)
source=ROOT/'variants'/args.variant
meta=json.loads((source/'provenance.json').read_text())
flags=['clang','-std=c11','-D_POSIX_C_SOURCE=200809L','-D_DARWIN_C_SOURCE','-pthread','-O3','-DNDEBUG','-march=native','-Wall','-Wextra','-Werror','-I'+str(source)]
commands=[]
if args.build_only:
    for key,mode in [('auto',2),('ordinary',0),('concurrent',1)]:
        out=build/key;out.mkdir(exist_ok=True);objects=[]
        for c in [*sorted((source/'cedarecs/ecs').glob('*.c')),source/'cedarecs/wexds.c']:
            obj=out/(c.stem+'.o');command=[*flags,'-DCEDARECS_CONCURRENT_REGISTRY='+str(mode),'-c',str(c),'-o',str(obj)]
            subprocess.run(command,check=True);commands.append(command);objects.append(obj)
        command=[*flags,'-DCEDAR_BUILD_SNAPSHOT="'+key+'"',str(ROOT/'bench/registry_workloads.c'),*map(str,objects),'-lm','-o',str(build/('registry-'+key))]
        subprocess.run(command,check=True);commands.append(command)
    (build/'build.json').write_text(json.dumps(dict(engine=meta,commands=commands),indent=2)+'\n')
    raise SystemExit
assert args.output
out=args.output.resolve();out.mkdir(parents=True,exist_ok=False)
before=ROOT/'results/kama-v107-registry'
old=json.loads((before/'metadata.json').read_text());assert hashlib.sha256((before/'engine-b').read_bytes()).hexdigest()==old['binaries']['new']
assert (before/'workload.c').read_bytes()==(ROOT/'bench/registry_workloads.c').read_bytes()
binaries={}
for (key,path),letter in zip([('before',before/'engine-b'),*[(k,build/('registry-'+k)) for k in ('auto','ordinary','concurrent')]],'abcd'):
    binaries[key]=out/('engine-'+letter);shutil.copy2(path,binaries[key])
shutil.copy2(__file__,out/'runner.py');shutil.copy2(ROOT/'bench/registry_workloads.c',out/'workload.c');shutil.copy2(build/'build.json',out/'build.json')
jobs=list(itertools.product((1,2,4,8),(1,2,8),(0,1)))
summary=[];m=dict(started_utc=datetime.now(timezone.utc).isoformat(),repeats=16,cases=len(jobs),engine=meta,
    binaries={k:hashlib.sha256(v.read_bytes()).hexdigest() for k,v in binaries.items()},
    methodology='Exact v107 ordinary control and three same-source policies. Timed code/source identical; mode labels selected before timing. Sequential processes, four rotated/reversed orders, eight environment pads, equal-length binary paths. Two discarded warmups; all samples, count/checksum parity. Auto discovery and promotion are inside timing, not prewarmed.')
(out/'metadata.json').write_text(json.dumps(m,indent=2)+'\n')
with (out/'raw.jsonl').open('w') as log:
    for index,(threads,worlds,commands_on) in enumerate(jobs):
        passes=((1000000 if worlds==1 else 100000) if not commands_on else 20000)//worlds;job=[threads,worlds,passes,commands_on]
        samples={k:[] for k in binaries};checks=set()
        for trial in range(-2,16):
            keys=list(binaries);order=keys[trial%4:]+keys[:trial%4]
            if trial%2:order.reverse()
            for position,key in enumerate(order):
                process=subprocess.run([str(binaries[key]),*map(str,job)],check=True,text=True,capture_output=True,timeout=120,
                    env=dict(os.environ,LC_ALL='C',CEDAR_BENCH_STACK_PAD='x'*((max(trial,0)//2)%8)*16))
                assert not process.stderr,process.stderr
                r=json.loads(process.stdout);assert r['version']==('new' if key=='before' else key)
                checks.add((r['checksum'],r['operations']))
                if trial>=0:
                    samples[key].append(r['ns_per_op']);log.write(json.dumps(dict(case=job,which=key,trial=trial,position=position,**r))+'\n')
        assert len(checks)==1
        row=dict(threads=threads,worlds=worlds,commands=commands_on)
        for key,values in samples.items():
            q=statistics.quantiles(values,n=4,method='inclusive');row.update({key+'_median_ns':statistics.median(values),key+'_p25_ns':q[0],key+'_p75_ns':q[2]})
        for key in ('before','ordinary','concurrent'):row['auto_over_'+key]=row['auto_median_ns']/row[key+'_median_ns']
        summary.append(row);log.flush()
        print(f'{index+1}/{len(jobs)} {job}: auto/before {row["auto_over_before"]:.3f}; auto/forced-ordinary {row["auto_over_ordinary"]:.3f}; auto/concurrent {row["auto_over_concurrent"]:.3f}',flush=True)
        with (out/'summary.csv').open('w',newline='') as f:
            w=csv.DictWriter(f,list(row));w.writeheader();w.writerows(summary)
m['completed_utc']=datetime.now(timezone.utc).isoformat();(out/'metadata.json').write_text(json.dumps(m,indent=2)+'\n')
