#include "bench.h"

// This exact object is linked into both executables. No LTO or fast-math.
void bench_light(Position *restrict p, const Velocity *restrict v, size_t count) {
    for (size_t i = 0; i < count; i++) {
        p[i].x += v[i].x; p[i].y += v[i].y;
        p[i].z += v[i].z; p[i].w += v[i].w;
    }
}
void bench_heavy(Position *restrict p, const Velocity *restrict v, size_t count) {
    for (size_t i = 0; i < count; i++) {
        Position x = p[i];
        for (int j = 0; j < 32; j++) {
            x.x = x.x * .999f + v[i].x;
            x.y = x.y * .998f + v[i].y;
            x.z = x.z * .997f + v[i].z;
            x.w = x.w * .996f + v[i].w;
        }
        p[i] = x;
    }
}
