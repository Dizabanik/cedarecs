#!/usr/bin/env python3
"""Report additional memory scenarios, capacity boundaries and world lifetimes."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import shutil
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Patch

FS=('cedar-packed','cedar-indexed','entt','pico','flecs')
NAMES={'cedar-packed':'Cedar packed','cedar-indexed':'Cedar indexed','entt':'EnTT','pico':'pico_ecs','flecs':'Flecs'}
COLORS={'cedar-packed':'#33a02c','cedar-indexed':'#249f91','entt':'#0033cc','pico':'#ff9900','flecs':'#ff3300'}
TEXT='#26374d';MUTED='#58697d';PLOT='#e5ecf6';MIB=1048576
SCENARIOS=[('sparse_payload_01','populated','0.1% Payload · P/V on all'),
           ('sparse_payload_10','populated','10% Payload · P/V on all'),
           ('payload_low_slots','populated','Payload only · first 1% of slots'),
           ('payload_high_slots','populated','Payload only · last 1% of slots'),
           ('component_cycle','readded','Four Payload remove / re-adds'),
           ('empty_refill','regrown','Four full delete / refills'),
           ('delete_99','deleted','99% of dense entities deleted'),
           ('world_cycles','recreated','Fifth world in one process'),
           ('signature_cycles','shifted','Four complement-signature flips'),
           ('growth_steps','populated','Full population after staged growth')]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    p=argparse.ArgumentParser();p.add_argument('results',type=Path);args=p.parse_args();root=args.results.resolve()
    m=json.loads((root/'metadata.json').read_text());assert m['suite']=='ecs-memory-v2' and m['selection']=='additional' and not m['smoke'] and m['repeats']>=5
    rows=list(csv.DictReader((root/'summary.csv').open()));sizes=sorted({c['entities'] for c in m['configurations']})
    largest=max(sizes)
    def row(scenario,phase,framework,n=largest):
        return max((r for r in rows if r['scenario']==scenario and r['phase']==phase and r['framework']==framework and int(r['entities'])==n),key=lambda r:int(r['step']))
    def value(r,metric='malloc_in_use_delta'):return float(r[metric+'_median'])/MIB
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'text.color':TEXT,'axes.labelcolor':TEXT,
                         'xtick.color':TEXT,'ytick.color':TEXT,'svg.fonttype':'none','pdf.fonttype':42})
    outputs=[]
    def save(fig,name):
        for ext in ('png','svg','pdf'):
            p=root/(name+'.'+ext);fig.savefig(p,dpi=180,facecolor='white');outputs.append(p)
        plt.close(fig)
    fig=plt.figure(figsize=(14,9.4),facecolor='white')
    fig.text(.055,.946,'Additional ECS memory comparison',fontsize=27,fontweight='bold')
    fig.text(.055,.898,f'{largest:,} initial entities · live heap above baseline in MiB · all ten new scenarios · lower is better',fontsize=11,color=MUTED)
    ax=fig.add_axes([.405,.225,.55,.57]);ax.set_xlim(-.5,4.5);ax.set_ylim(9.5,-.5)
    ax.set_xticks(range(5),['Cedar\npacked','Cedar\nindexed','EnTT','pico_ecs','Flecs']);ax.xaxis.tick_top()
    ax.tick_params(length=0,pad=13);ax.set_yticks([])
    for i,(s,phase,label) in enumerate(SCENARIOS):
        vals=[value(row(s,phase,f)) for f in FS];best=min(vals)
        ax.text(-.65,i,label,ha='right',va='center',fontsize=10,clip_on=False)
        for j,v in enumerate(vals):
            ax.add_patch(Rectangle((j-.48,i-.46),.96,.92,facecolor='#def1dc' if v==best else PLOT,lw=0))
            ax.text(j,i,f'{v:.2f}',ha='center',va='center',fontsize=12,fontweight='bold',color='#216e27' if v==best else TEXT)
    for spine in ax.spines.values():spine.set_visible(False)
    fig.text(.055,.151,f"{m['processes']:,} fresh Release processes · {m['checkpoints']:,} checkpoints · 5 repetitions · all five backends use identical 16 / 16 / 256 B values.",fontsize=10,color=MUTED)
    fig.text(.055,.115,'Last named phase of each scenario; all earlier mutations, world lifetimes and population checkpoints remain in the raw data and CSV.',fontsize=9.5,color=MUTED)
    fig.text(.055,.079,'Green marks the lowest observed median per row. Native capacities differ; the 99% deletion case retains native high-water capacity.',fontsize=9.5,color=MUTED)
    fig.text(.055,.043,'Apple M4 Pro / macOS · checked Cedar v53 · fixed dependency pins · no engine changes, reserve, shrink or allocator purge.',fontsize=9.5,color=MUTED)
    save(fig,'additional-memory-comparison')

    fig,axes=plt.subplots(1,2,figsize=(14,7.4),facecolor='white')
    fig.subplots_adjust(left=.075,right=.98,bottom=.265,top=.76,wspace=.24)
    fig.text(.075,.934,'Five worlds. One process.',fontsize=28,fontweight='bold')
    fig.text(.075,.875,f'Each world holds {largest:,} entities with all three components · live heap and physical footprint measured separately',fontsize=10.5,color=MUTED)
    for ax,metric,title in zip(axes,['malloc_in_use_delta','footprint_delta'],['Live heap delta','Physical footprint delta']):
        ax.set_facecolor(PLOT);ax.grid(axis='y',color='white');ax.set_axisbelow(True)
        for f in FS:
            selected=sorted((r for r in rows if r['scenario']=='world_cycles' and int(r['entities'])==largest and r['framework']==f and r['phase'] in ('populated','world_destroyed','recreated','destroyed')),key=lambda r:int(r['step']))
            assert len(selected)==10
            vals=[value(r,metric) for r in selected]
            ax.plot(range(10),vals,color=COLORS[f],marker='o',markersize=3,lw=1.5,label=NAMES[f])
            ax.fill_between(range(10),[float(r[metric+'_p25'])/MIB for r in selected],[float(r[metric+'_p75'])/MIB for r in selected],color=COLORS[f],alpha=.12)
        ax.set_xticks(range(10),[f'W{i//2+1} '+('live' if i%2==0 else 'freed') for i in range(10)],rotation=60,ha='right',fontsize=8)
        ax.set_title(title,loc='left',fontweight='bold',fontsize=13,pad=16);ax.set_ylabel('MiB above pre-world baseline')
        ax.set_ylim(bottom=min(0,ax.get_ylim()[0]));ax.tick_params(length=0,pad=8)
        for spine in ax.spines.values():spine.set_visible(False)
    fig.legend(handles=[Patch(facecolor=COLORS[f],label=NAMES[f]) for f in FS],loc='lower center',bbox_to_anchor=(.5,.087),ncol=5,frameon=False)
    fig.text(.075,.058,'Shading: observed IQR. A freed ECS can return live allocations while the system allocator retains physical pages; this alone is not a leak.',fontsize=9,color=MUTED)
    fig.text(.075,.027,'All registration and destruction checkpoints are retained. No explicit allocator purge or forced release is requested.',fontsize=9,color=MUTED)
    save(fig,'repeated-world-memory')

    raw=[json.loads(line) for line in (root/'raw.jsonl').read_text().splitlines()]
    freed={f:[r['malloc_in_use_delta'] for r in raw if r['framework']==f and r['phase'] in ('world_destroyed','destroyed')] for f in FS}
    lines=['# Additional ECS memory benchmarks','',f"Added **ten new scenarios** and completed **{m['processes']:,} fresh Release processes / {m['checkpoints']:,} checkpoints**. Both Cedar policies, EnTT, pico_ecs and Flecs use identical live values. Five repetitions per case and backend.",'',
           'Test populations: '+', '.join(f'{n:,}' for n in sizes)+'. These bracket common capacity boundaries and include one entity beyond 262,144. The original v1 results remain retained.','',
           '![All new memory scenarios](additional-memory-comparison.png)','',
           f'## Largest population: {largest:,}','',
           'Median live heap in MiB above the pre-world baseline. No pre-reserve, shrink, purge or engine changes. The final named phase is used for each row; all earlier phases and observed IQRs remain in the CSV.','',
           '| Scenario / final named phase | '+' | '.join(NAMES[f] for f in FS)+' |', '| --- | '+' | '.join('---:' for _ in FS)+' |']
    for s,phase,label in SCENARIOS:lines.append('| '+label+' (`'+phase+'`) | '+' | '.join(f'{value(row(s,phase,f)):.2f}' for f in FS)+' |')
    lines+=['','## Allocation boundaries','',
            'Live heap bytes per live entity at the full `growth_steps` population. The external handle/mask arrays were allocated and faulted before the baseline.','',
            '| Initial entities | '+' | '.join(NAMES[f] for f in FS)+' |', '| ---: | '+' | '.join('---:' for _ in FS)+' |']
    for n in sizes:lines.append('| '+f'{n:,}'+' | '+' | '.join(f"{float(row('growth_steps','populated',f,n)['heap_bytes_per_live_entity']):.1f}" for f in FS)+' |')
    lines+=['','## Repeated world lifetimes','',
            '![Five world lifetimes](repeated-world-memory.png)','',
            'Residual live-heap deltas across every complete world destruction (including the final destruction) in this run:','',
            '| Backend | Minimum bytes | Maximum bytes |','| --- | ---: | ---: |']
    for f,values in freed.items():lines.append(f'| {NAMES[f]} | {min(values):,} | {max(values):,} |')
    lines+=['','These are observations for the measured lifetimes, not a general leak-proof guarantee. Allocator-owned physical pages may remain after live allocations are freed. Entity/component deletion retains native capacities naturally.','',
            '## Coverage and validation','',
            'The two sparse tests use Payload on ordinals divisible by 1,000 or 10, with dense Position/Velocity. Low/high-slot tests contain only ceil(N/100) Payload components, at the first/last creation ordinals; all other entities are empty. Native numeric slot assignment is not overridden. Complement-signature tests alternate all eight signatures; full refill and component cycles validate every phase. Four staged-growth checkpoints never query uncreated harness handles.','',
            'Full liveness, component-presence and every payload word are checked in C++; the runner requires identical application-ordinal checksums across backends. Python independently verifies expected counts, phase order, paired process order, compiled probe v2 markers, signed deltas, medians and quartiles. Separate Release and ASan/UBSan smokes include both old and new cases. Sanitized memory usage is excluded from this report.','',
            f"Engine source remains `{m['cedar']['snapshot_sha256']}` (`{m['cedar']['label']}`). The newly initialized engine Git repository is excluded from manifests and archives; it has no commits or staged files at creation.",'',
            '[All phases and statistics](summary.csv) · [Every raw checkpoint](raw.jsonl) · [Source/binary identities and pins](metadata.json) · [Methodology and commands](../../bench/memory/README.md).','']
    report=root/'REPORT.md';report.write_text('\n'.join(lines));outputs.append(report)
    shutil.copy2(Path(__file__),root/'report-source.py')
    (root/'figure-provenance.json').write_text(json.dumps(dict(inputs={p.name:sha(p) for p in (root/'summary.csv',root/'metadata.json',root/'raw.jsonl')},outputs={p.name:sha(p) for p in outputs},script_sha256=sha(Path(__file__))),indent=2)+'\n')
    print('Exported additional memory report and figures:',root)

if __name__=='__main__':main()
