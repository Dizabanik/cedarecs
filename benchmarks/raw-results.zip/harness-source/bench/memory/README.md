# ECS memory comparison

## Query-owned binding allocations

The separate `bench/query_binding_memory.py` probe compares frozen v107 and
the selected variant's query-owned allocations at 128, 4,097 and 65,536 entities. It covers zero
through three required fields and full, half-deleted, empty and regrown states,
checking matching live rows and run counts. It records each query's native
`malloc_size` and allocation count, including metadata and binding arrays.
It excludes world storage, malloc bookkeeping, RSS and physical footprint;
use the process-wide suite below for those metrics. It currently targets macOS.

```sh
python3 testing/bench/query_binding_memory.py --variant adaptive-ecs-v121 \
  --output testing/results/NEW-query-memory
```

The [96 retained checkpoints](../../results/adaptive-ecs-v121-query-memory/summary.csv)
show 65,536 per-run bindings becoming one allocation for a fragmented two-field
view. Zero-field views use no binding allocation. Single-field and small-world
views keep their old strategy. Query metadata itself adds 64 allocated bytes
on the tested host. See [the complete tradeoff report](../../AUTOMATIC_OPTIMIZATION.md).

## Current v3 allocation accounting

The current probe reports `probe_version: 3`. The runner rejects stale
executables and the validator also accepts the retained v1/v2 archives.
Scenario operations and payload validation are unchanged.

Some experimental Cedar variants use anonymous mappings. Live malloc alone
therefore omits part of their storage. V3 records full mapped virtual
reservation, page-rounded mapped logical allocations (including headers and
alignment), and mapped resident pages observed with `mincore`. The primary
`accounted_storage` metric is `malloc_in_use + mapped_logical`. It includes
unused logical capacity; full virtual reservation is reported separately.
Physical footprint and RSS retain identical process accounting across all
backends. Resident mapped pages are a diagnostic, not a replacement for
allocated capacity in the comparison.

For these experiments, generate the storage-aware report instead of the
original heap-only charts:

```sh
python3 testing/bench/memory/validate.py testing/results/NEW-v3
python3 testing/bench/memory/report_storage.py testing/results/NEW-v3
```

This writes `STORAGE_REPORT.md` and `storage-comparison.csv`, including every
mutation checkpoint and each Cedar policy separately. The old `report.py`
and `report_additional.py` remain for the archived v1/v2 measurements.
The active source identity comes from `testing/provenance.json`; it is no
longer necessarily the v53 hash described in the historical sections below.

## Additional v2 cases

The original v1 measurements are retained. Ten new scenarios run through the
same five backends (both Cedar policies, EnTT, pico_ecs, Flecs):

| Scenario | New coverage |
| --- | --- |
| `sparse_payload_01` | Payload on 0.1% of entities; Position/Velocity on all |
| `sparse_payload_10` | Payload on 10% of entities; Position/Velocity on all |
| `payload_low_slots` | Only the first ceil(N/100) created entities have Payload; other entities have no components |
| `payload_high_slots` | The same component count at the last created slots |
| `component_cycle` | Four remove/re-add cycles for every Payload, checking both phases |
| `empty_refill` | Four complete delete/refill cycles in one world |
| `delete_99` | Delete 99%, retaining every hundredth application ordinal |
| `world_cycles` | Five world lifetimes in one process; checkpoints after each destruction, registration and refill |
| `signature_cycles` | Four flips between each three-component signature and its complement |
| `growth_steps` | Checkpoint at 25%, 50%, 75% and 100% population |

The additional run brackets common allocation boundaries at 1,023 / 1,025
and 65,535 / 65,537 entities and includes 262,145 entities. Native slot ordering
and growth policies differ; "low/high" refers to creation order, not an imposed
native numeric ID. The payload size remains 256 B. These tests expose capacity
and repeated-lifetime behavior without changing an engine implementation.

```sh
cmake --build testing/build/memory -j3
python3 testing/bench/memory/run.py --smoke --suite all --output testing/results/NEW-v2-smoke
python3 testing/bench/memory/run.py --suite additional --sizes 1023 1025 65535 65537 262145 \
  --repeats 5 --output testing/results/NEW-v2
python3 testing/bench/memory/validate.py testing/results/NEW-v2
```

`--suite baseline` retains the original eleven scenarios; `--suite all`
selects both sets. The validator accepts original v1 archives and the v2 probe
format, and checks the exact phase sequence, analytical counts, all payload
words, cross-backend checksums and every repeated checkpoint. Each v2 binary
reports `probe_version: 2`; the runner rejects stale v1 executables.
New snapshots and source manifests exclude the optimized folder's `.git`
metadata. The engine's source hash remains the benchmarked v53 hash.

## Original suite and accounting

This is a separate memory-usage suite; it does not replace the retained speed
measurements or modify any engine source. It compares packed Cedar, indexed
Cedar, EnTT, pico_ecs and Flecs using public individual entity/component APIs.
The native dependencies use the same pins as the four-framework entity suite.

```sh
cmake -S testing/bench/memory -B testing/build/memory -DCMAKE_BUILD_TYPE=Release
cmake --build testing/build/memory -j3
python3 testing/bench/memory/run.py --smoke --output testing/results/NEW-memory-smoke
python3 testing/bench/memory/run.py --repeats 5 --output testing/results/NEW-memory
python3 testing/bench/memory/validate.py testing/results/NEW-memory
testing/build/plot-env/bin/python testing/bench/memory/report.py testing/results/NEW-memory
```

The build uses the pinned dependencies already bootstrapped under
`testing/build/interop/_deps/`. `REFERENCE_BUILD` can select another equivalent
reference build. macOS is required for the current accounting implementation.

The 34 configurations cover a registered empty world plus eleven scenarios at
1,024, 65,536 and 262,144 entities: empty entities; 16-byte Position; Position
and 16-byte Velocity; dense 256-byte Payload; Payload on 1% of entities; all
eight component signatures; 50% deletion; 95% deletion; removal of every
Payload; four delete/regrow cycles; and deletion of every entity. All three
types are registered in every world. pico_ecs starts with its native 1,024-slot
capacity, matching the earlier integration; no backend reserves for the final
population. Other native capacities and built-in features differ.

Every process preallocates and faults its external entity-handle and mask
buffers before the baseline. Position and Velocity each contain two uint64
words; Payload contains 32. All live component bytes are written with the same
deterministic values. Before each measurement the harness checks liveness,
presence and every word, touches the data, and computes an application-ordinal
checksum independent of native entity IDs. The runner requires cross-backend
checksum equality and analytical counts. Handle arrays remain allocated after
world destruction; their allocation is already included in the baseline.

Each case uses a fresh process, with five serial repetitions and rotating
backend order. Checkpoints cover pre-world baseline, registered world,
population, mutations, each regrowth, and world destruction. No explicit
shrink, purge or allocator replacement is used. The recorded metrics are:

- **Live heap:** all malloc zones' `size_in_use`, including rounded allocations
  and native retained ECS capacity. Signed deltas subtract the pre-world baseline.
- **Allocator reservation:** malloc-zone `size_allocated`; virtual reservation
  is distinct from resident memory and useful component storage.
- **Physical footprint:** macOS `TASK_VM_INFO.phys_footprint`, including dirty
  and compressed accounting. This is a process-level measurement and can retain
  allocator pages after the ECS has freed its allocations.
- **Resident memory and process peaks:** current RSS, peak RSS, footprint peak,
  compressed bytes, and allocation counts. Peaks are lifetime high-water marks,
  not phase-local peaks or net allocation peaks.

Absolute measurements, signed baseline deltas, medians and inclusive quartiles
are retained. Live-heap deltas are the primary comparative metric; they are not
an exact count of user component bytes or complete engine overhead. Physical
footprint includes first-use runtime and code effects. Negative post-destruction
deltas can arise from allocator behavior and must not be clamped away. A high
resident footprint after deletion or destruction alone does not establish a leak.

The raw results archive all probe sources, the complete Cedar implementation,
the Kama header, dependency pins, compiler configuration, binary hashes and
the compiled Cedar source identity. `validate.py` independently recomputes the
summary and checks every recorded process and checkpoint. ASan/UBSan runs use
the same shape/operation checks but their memory figures are excluded from the
Release comparison.

To repeat the sanitizer sweep:

```sh
cmake -S testing/bench/memory -B testing/build/memory-sanitize \
  -DCMAKE_BUILD_TYPE=RelWithDebInfo \
  '-DCMAKE_C_FLAGS=-fsanitize=address,undefined -fno-omit-frame-pointer' \
  '-DCMAKE_CXX_FLAGS=-fsanitize=address,undefined -fno-omit-frame-pointer'
cmake --build testing/build/memory-sanitize -j3
python3 testing/bench/memory/run.py --smoke --build testing/build/memory-sanitize \
  --output testing/results/NEW-memory-sanitize
python3 testing/bench/memory/validate.py testing/results/NEW-memory-sanitize
```
