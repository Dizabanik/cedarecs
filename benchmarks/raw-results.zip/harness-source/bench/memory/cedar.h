#ifndef CEDAR_MEMORY_BRIDGE_H
#define CEDAR_MEMORY_BRIDGE_H
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef struct memory_cedar_world memory_cedar_world;
typedef struct memory_cedar_allocations { uint64_t virtual_bytes, logical_bytes, resident_bytes; } memory_cedar_allocations;
void memory_cedar_measure(const memory_cedar_world *world, memory_cedar_allocations *out);
memory_cedar_world *memory_cedar_new(int indexed);
void memory_cedar_free(memory_cedar_world *world);
uint64_t memory_cedar_entity(memory_cedar_world *world);
void memory_cedar_kill(memory_cedar_world *world, uint64_t e);
void memory_cedar_put(memory_cedar_world *world, uint64_t e, unsigned c, const void *p);
void memory_cedar_remove(memory_cedar_world *world, uint64_t e, unsigned c);
const void *memory_cedar_get(memory_cedar_world *world, uint64_t e, unsigned c);
int memory_cedar_alive(memory_cedar_world *world, uint64_t e);
#ifdef __cplusplus
}
#endif
#endif
