#include "cedar.h"
#include <cedarecs/ecs/internal.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stdlib.h>
struct memory_cedar_world { ced_World *world; ced_Component ids[3]; };
memory_cedar_world *memory_cedar_new(int indexed) {
    memory_cedar_world *b = calloc(1, sizeof(*b));
    if (!b) abort();
    b->world = indexed ? ced_init_indexed() : ced_init();
    if (!b->world) abort();
    b->ids[0] = ced_component_register(b->world, "Position", 16, _Alignof(uint64_t));
    b->ids[1] = ced_component_register(b->world, "Velocity", 16, _Alignof(uint64_t));
    b->ids[2] = ced_component_register(b->world, "Payload", 256, _Alignof(uint64_t));
    for (size_t i = 0; i < 3; ++i) if (b->ids[i] == ced_component_none) abort();
    return b;
}
void memory_cedar_free(memory_cedar_world *b) { ced_drop(b->world); free(b); }
uint64_t memory_cedar_entity(memory_cedar_world *b) { return ced_entity(b->world); }
void memory_cedar_kill(memory_cedar_world *b, uint64_t e) { ced_kill(b->world, e); }
void memory_cedar_put(memory_cedar_world *b, uint64_t e, unsigned c, const void *p) {
    if (c >= 3 || !ced_add_set_component(b->world, e, b->ids[c], p)) abort();
}
void memory_cedar_remove(memory_cedar_world *b, uint64_t e, unsigned c) {
    if (c >= 3) abort();
    ced_remove_component(b->world, e, b->ids[c]);
}
const void *memory_cedar_get(memory_cedar_world *b, uint64_t e, unsigned c) {
    if (c >= 3) abort();
    return ced_get_component_const(b->world, e, b->ids[c]);
}
int memory_cedar_alive(memory_cedar_world *b, uint64_t e) { return ced_is_alive(b->world, e); }
static void memory_cedar_region(memory_cedar_allocations *out, const void *data, size_t size) {
    size_t reserved=ced_storage_virtual_bytes(data,size);
    if (!reserved) return;
    size_t page=(size_t)sysconf(_SC_PAGESIZE);
    size_t logical=ced_storage_logical_bytes(data,size);
    if (logical>SIZE_MAX-(page-1)) abort();
    out->virtual_bytes+=reserved;out->logical_bytes+=(logical+page-1)&~(page-1);
    // mincore observes page residency without reading/faulting the payload.
    // The mapping header is in the page immediately before the aligned data.
    const unsigned char *begin=(const unsigned char *)data-page;
    size_t bytes=page+((size+page-1)&~(page-1));
    while(bytes) {
        char vec[256];size_t chunk=bytes<sizeof(vec)*page?bytes:sizeof(vec)*page;
        if(mincore(begin,chunk,vec))abort();
        for(size_t i=0;i<chunk/page;i++)if(vec[i]&MINCORE_INCORE)out->resident_bytes+=page;
        begin+=chunk;bytes-=chunk;
    }
}
void memory_cedar_measure(const memory_cedar_world *b, memory_cedar_allocations *out) {
    *out=(memory_cedar_allocations){0};if(!b)return;
    const ced_World *w=b->world;
    if(w->entities!=w->_runtime->inline_records && !ced_records_use_native(w->entity_capacity))
        memory_cedar_region(out,w->entities,ced_bytes(w->entity_capacity,sizeof(*w->entities)));
    memory_cedar_region(out,w->_indexed_entities,ced_bytes(w->entity_capacity,sizeof(*w->_indexed_entities)));
    for(size_t c=0;c<w->component_count;c++) {
        const ced_IndexedColumn *col=&w->components[c]->indexed;
        memory_cedar_region(out,col->data,ced_bytes(col->capacity,w->components[c]->size));
        if(col->capacity)memory_cedar_region(out,col->owners,ced_indexed_owner_bytes(w->components[c],col->capacity));
    }
    if(!w->indexed)for(size_t i=0;i<w->archetype_count;i++) {
        const ced_Archetype *a=w->archetypes[i];
        memory_cedar_region(out,a->entities,ced_archetype_storage_bytes(a,a->capacity,sizeof(*a->entities),0));
        for(size_t c=0;c<a->type_count;c++) {
            const void *base=a->_column_allocations[c];
            size_t prefix=base?(size_t)(a->columns[c].data-(const unsigned char *)base):0;
            memory_cedar_region(out,base,ced_archetype_storage_bytes(a,a->capacity,a->columns[c].component_size,prefix));
        }
    }
}
