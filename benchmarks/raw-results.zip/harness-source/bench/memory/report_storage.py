#!/usr/bin/env python3
"""Report native heap plus logical VM allocations, without hiding mmap costs."""
import argparse
import csv
import json
from pathlib import Path

FRAMEWORKS = ('cedar-packed', 'cedar-indexed', 'entt', 'pico', 'flecs')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('results', type=Path)
    args = parser.parse_args()
    root = args.results.resolve()
    metadata = json.loads((root / 'metadata.json').read_text())
    assert metadata['probe_version'] == 3 and metadata.get('completed_utc')
    rows = list(csv.DictReader((root / 'summary.csv').open()))
    groups = {}
    for row in rows:
        key = tuple(row[k] for k in ('scenario', 'entities', 'step', 'phase'))
        groups.setdefault(key, {})[row['framework']] = row
    comparison = []
    for key, values in sorted(groups.items()):
        assert set(values) == set(FRAMEWORKS)
        if key[3] in ('baseline', 'registered', 'registered_again', 'destroyed', 'world_destroyed'):
            continue
        result = dict(zip(('scenario', 'entities', 'step', 'phase'), key))
        result['payload_bytes'] = values['entt']['payload_bytes']
        for framework, row in values.items():
            for metric in ('accounted_storage', 'footprint', 'mapped_virtual', 'mapped_resident'):
                result[framework + '_' + metric] = float(row[metric + '_delta_median'])
        for policy in ('cedar-packed', 'cedar-indexed'):
            for reference in ('entt', 'pico'):
                for metric in ('accounted_storage', 'footprint'):
                    denominator = result[reference + '_' + metric]
                    result[policy + '_over_' + reference + '_' + metric] = (
                        result[policy + '_' + metric] / denominator if denominator > 0 else '')
        comparison.append(result)
    assert comparison
    with (root / 'storage-comparison.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, list(comparison[0]))
        writer.writeheader()
        writer.writerows(comparison)
    largest = max(int(row['entities']) for row in comparison)
    lines = ['# Memory storage comparison', '',
             f"Source: `{metadata['cedar']['snapshot_sha256']}`. "
             f"{metadata['processes']} fresh processes, {metadata['repeats']} repetitions.", '',
             'The primary storage metric adds live malloc allocations to the page-rounded '
             'logical size of mapped allocations, including mapping headers and alignment. '
             'Untouched spare logical capacity remains charged. Full virtual reservation is '
             'reported separately and is not RAM. Physical footprint uses the same macOS '
             'process accounting for every backend; allocator caching and runtime first use '
             'can affect it. All figures below subtract the pre-world process baseline.', '',
             'Heap-only results must not be used to compare Cedar with these native backends. '
             'Mapped resident pages are diagnostic; they are not substituted into the primary '
             'storage metric. The complete CSV includes every repeated mutation checkpoint.', '',
             f'## Populated worlds at {largest:,} entities', '',
             '| Scenario | Payload MiB | Packed MiB | Indexed MiB | EnTT MiB | pico MiB | Flecs MiB | Packed / EnTT | Indexed / EnTT |',
             '| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
    mib = 1024 ** 2
    for row in comparison:
        if int(row['entities']) != largest or row['phase'] != 'populated':
            continue
        cells = [row['scenario'], f"{int(row['payload_bytes']) / mib:.2f}"]
        cells += [f"{row[f + '_accounted_storage'] / mib:.2f}" for f in FRAMEWORKS]
        cells += [f"{row[p + '_over_entt_accounted_storage']:.3f}" for p in FRAMEWORKS[:2]]
        lines.append('| ' + ' | '.join(cells) + ' |')
    lines += ['', '## Complete checkpoint parity with EnTT', '',
              'Counts include all retained populated and mutation checkpoints at every size, '
              'including repeated states. A ratio above 1 is a memory loss.', '',
              '| Cedar policy | Storage at or below EnTT | Footprint at or below EnTT | Checkpoints |',
              '| --- | ---: | ---: | ---: |']
    for policy in FRAMEWORKS[:2]:
        counts = []
        for metric in ('accounted_storage', 'footprint'):
            ratios = [r[policy + '_over_entt_' + metric] for r in comparison]
            counts.append(sum(isinstance(r, (int, float)) and r <= 1 for r in ratios))
        lines.append(f'| {policy} | {counts[0]} | {counts[1]} | {len(comparison)} |')
    lines += ['', '[Every checkpoint and full reservation](storage-comparison.csv). '
              'These memory results alone do not establish the separate 4% timing gate.', '']
    (root / 'STORAGE_REPORT.md').write_text('\n'.join(lines))
    print(root / 'STORAGE_REPORT.md')


if __name__ == '__main__':
    main()
