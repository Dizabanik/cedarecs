#!/usr/bin/env python3
"""All-scenario memory figures and a reproducible report, including tradeoffs."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import shutil
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
import numpy as np

FRAMEWORKS=('cedar-packed','cedar-indexed','entt','pico','flecs')
NAMES={'cedar-packed':'Cedar packed','cedar-indexed':'Cedar indexed','entt':'EnTT','pico':'pico_ecs','flecs':'Flecs'}
BG='#091b18';PANEL='#112923';INK='#f3f6ed';MUTED='#a5b9ae';MINT='#a8f18b';GRID='#29443b'
COLORS={'cedar-packed':MINT,'cedar-indexed':'#4dc49d','entt':'#87a5bf','pico':'#d1b376','flecs':'#b49acb'}
SCENARIOS=[('empty','populated','Empty entities'),('position','populated','16 B Position'),
           ('position_velocity','populated','Position + Velocity'),('dense_payload','populated','+ 256 B Payload on all'),
           ('sparse_payload','populated','+ Payload on 1%'),('fragmented','populated','Eight signatures'),
           ('delete_half','deleted','Delete 50% of dense world'),('delete_95','deleted','Delete 95% of dense world'),
           ('remove_payload','removed','Remove every Payload'),('recycle','regrown','Four delete / regrow cycles'),
           ('clear','deleted','Delete every entity')]
MIB=1048576
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    parser=argparse.ArgumentParser();parser.add_argument('results',type=Path);args=parser.parse_args()
    root=args.results.resolve();meta=json.loads((root/'metadata.json').read_text())
    assert meta['suite'] in ('ecs-memory-v1','ecs-memory-v2') and meta.get('selection','baseline')=='baseline' and not meta['smoke'] and meta['repeats']>=5
    rows=list(csv.DictReader((root/'summary.csv').open()))
    raw=[json.loads(line) for line in (root/'raw.jsonl').read_text().splitlines()]
    returned_to_baseline=all(r['malloc_in_use_delta']==0 for r in raw if r['phase']=='destroyed')
    size=max(c['entities'] for c in meta['configurations'])
    def row(scenario,phase,framework,n=size):
        candidates=[r for r in rows if r['scenario']==scenario and r['phase']==phase and r['framework']==framework and int(r['entities'])==n]
        return max(candidates,key=lambda r:int(r['step']))
    heap=lambda r:float(r['malloc_in_use_delta_median'])/MIB
    physical=lambda r:float(r['footprint_delta_median'])/MIB
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'text.color':INK,
                         'axes.labelcolor':MUTED,'xtick.color':MUTED,'ytick.color':INK,
                         'svg.fonttype':'none','pdf.fonttype':42})
    outputs=[]
    def text(fig,x,y,s,size=11,color=INK,weight='normal'):
        fig.text(x,y,s,fontsize=size,color=color,fontweight=weight)
    def save(fig,name):
        for ext in ('png','svg','pdf'):
            p=root/(name+'.'+ext);fig.savefig(p,facecolor=BG,dpi=190);outputs.append(p)
        plt.close(fig)

    fig=plt.figure(figsize=(13,9),facecolor=BG)
    text(fig,.045,.951,'CEDAR ECS  /  MEMORY UNDER LOAD',12,MINT,'bold')
    text(fig,.045,.890,'Know the cost of a world.',31,INK,'bold')
    text(fig,.045,.848,f'{size:,} initial entities · net live heap in MiB · lower is better · all eleven scenarios',11,MUTED)
    ax=fig.add_axes([.405,.218,.55,.566],facecolor=BG)
    ax.set_xlim(-.5,4.5);ax.set_ylim(10.5,-.5);ax.set_xticks(range(5),[NAMES[f].replace(' ','\n',1) if f.startswith('cedar') else NAMES[f] for f in FRAMEWORKS])
    ax.xaxis.tick_top();ax.tick_params(length=0,pad=13,labelsize=10);ax.set_yticks([])
    for i,(s,p,label) in enumerate(SCENARIOS):
        values=[heap(row(s,p,f)) for f in FRAMEWORKS];best=min(values)
        ax.text(-.65,i,label,va='center',ha='right',fontsize=10,clip_on=False)
        for j,v in enumerate(values):
            # Color highlights the lowest observed median in each complete row.
            color='#315a39' if v==best else PANEL
            ax.add_patch(Rectangle((j-.48,i-.46),.96,.92,color=color,lw=0))
            ax.text(j,i,f'{v:.2f}',ha='center',va='center',fontsize=12,fontweight='bold',color=MINT if v==best else INK)
    for spine in ax.spines.values():spine.set_visible(False)
    dense_c=heap(row('dense_payload','populated','cedar-packed'));dense_f=heap(row('dense_payload','populated','flecs'))
    sparse_c=heap(row('sparse_payload','populated','cedar-packed'));sparse_p=heap(row('sparse_payload','populated','pico'))
    text(fig,.045,.164,f'PACKED CEDAR: {100*(1-dense_c/dense_f):.0f}% less live heap than Flecs in dense payloads; {100*(1-sparse_c/sparse_p):.0f}% less than pico_ecs with 1% payloads.',12,MINT,'bold')
    text(fig,.045,.122,'Green marks the lowest observed median per row. EnTT wins several rows; indexed Cedar allocates component data through world capacity.',9,MUTED)
    text(fig,.045,.094,'5 fresh processes per backend/case · 850 processes overall · three registered types (16 B / 16 B / 256 B) · same initialized values.',9,MUTED)
    text(fig,.045,.066,'Baseline excludes prefaulted harness buffers. Heap includes rounded allocations and retained capacity; no explicit reserve, shrink or purge.',9,MUTED)
    text(fig,.045,.038,'macOS / Apple M4 Pro · fixed native dependency pins · native defaults differ. These are heap deltas, not RSS, peaks or universal memory rankings.',9,MUTED)
    save(fig,'memory-comparison')

    # RSS/footprint must be visible alongside heap; don't conflate freed allocations with reclaimed OS pages.
    fig=plt.figure(figsize=(13,8.6),facecolor=BG)
    text(fig,.045,.947,'CEDAR ECS  /  HEAP IS NOT THE WHOLE FOOTPRINT',12,MINT,'bold')
    text(fig,.045,.885,'Allocated bytes and physical pages.',28,INK,'bold')
    text(fig,.045,.844,f'Dense 288 B of user components per entity · largest population: {size:,} · five-process medians',11,MUTED)
    width=.14;positions=np.arange(3)
    stages=[('populated','Full world'),('deleted','All entities deleted'),('destroyed','World destroyed')]
    for col,(metric,title) in enumerate([('malloc_in_use_delta','LIVE HEAP DELTA'),('footprint_delta','PHYSICAL FOOTPRINT DELTA')]):
        ax=fig.add_axes([.085+col*.47,.228,.39,.51],facecolor=BG)
        for i,f in enumerate(FRAMEWORKS):
            selected=[row('clear',phase,f) for phase,_ in stages]
            values=[float(r[metric+'_median'])/MIB for r in selected]
            q1=[float(r[metric+'_p25'])/MIB for r in selected];q3=[float(r[metric+'_p75'])/MIB for r in selected]
            ax.bar(positions+(i-2)*width,values,width*.93,color=COLORS[f],label=NAMES[f],
                   yerr=[[max(0,v-q) for v,q in zip(values,q1)],[max(0,q-v) for v,q in zip(values,q3)]],
                   error_kw={'ecolor':INK,'elinewidth':.7,'capsize':1.5})
        ax.set_xticks(positions,[s[1] for s in stages]);ax.tick_params(axis='x',length=0,labelsize=8.5,pad=12)
        ax.set_ylabel('MiB above pre-world baseline',fontsize=9);ax.set_title(title,color=INK,loc='left',fontsize=12,fontweight='bold',pad=18)
        ax.grid(axis='y',color=GRID,alpha=.7);ax.set_axisbelow(True)
        for spine in ax.spines.values():spine.set_visible(False)
    handles,labels=fig.axes[0].get_legend_handles_labels()
    fig.legend(handles,labels,loc='lower center',bbox_to_anchor=(.5,.135),ncol=5,frameon=False,labelcolor=INK,fontsize=10)
    lifetime_note=('All backends returned their observed live heap to baseline after world destruction; allocator-owned physical pages can remain resident.'
                   if returned_to_baseline else 'World destruction can free ECS allocations while allocator-owned physical pages remain resident; inspect the raw residual heap deltas.')
    text(fig,.045,.105,lifetime_note,10,MUTED)
    text(fig,.045,.073,'Whiskers show observed IQR. No explicit allocator purge is requested. Retention after deletion is capacity, not evidence of a leak.',9,MUTED)
    text(fig,.045,.041,'macOS TASK_VM_INFO physical footprint includes process-level accounting. Complete RSS, compression, reservation and lifetime peaks are in the CSV.',9,MUTED)
    save(fig,'memory-lifetime')

    content=['# Memory comparison results','',f"Completed {meta['processes']:,} fresh Release processes and {meta['checkpoints']:,} checkpoints: {len(meta['configurations'])} configurations, five backends, {meta['repeats']} repetitions. Every value/presence/liveness check and cross-backend application checksum passed.",'',
             f'Packed Cedar uses **{100*(1-dense_c/dense_f):.1f}% less live heap than Flecs** in the largest dense-payload case and **{100*(1-sparse_c/sparse_p):.1f}% less than pico_ecs** with 1% payloads. These are specific workload results. EnTT uses less heap in several other cases, and indexed Cedar pays for slot-capacity columns even when a component is rare.','',
             '![All memory scenarios](memory-comparison.png)','',f'## Largest population: {size:,} entities','',
             'All figures below are median MiB above the pre-world baseline. Handle/mask buffers were prefaulted before that baseline. Each backend registers Position (16 B), Velocity (16 B), and Payload (256 B). All live component bytes are initialized and checked. Unoccupied capacity is not explicitly touched by the harness. Native capacities/features differ; no final-population reserve, explicit shrink, or allocator purge is used.','',
             '| Scenario / measured state | '+' | '.join(NAMES[f] for f in FRAMEWORKS)+' |',
             '| --- | '+' | '.join('---:' for _ in FRAMEWORKS)+' |']
    for s,p,label in SCENARIOS:
        content.append('| '+label+' | '+' | '.join(f'{heap(row(s,p,f)):.2f}' for f in FRAMEWORKS)+' |')
    content+=['','The recycling row is the fourth regrowth checkpoint. Deletion/removal rows retain native high-water capacity; the 95% deletion case has only '+f'{(size+19)//20:,}'+' live entities. Bytes per live entity therefore rise sharply when capacity is retained. The sparse-payload row has a Payload on ordinals divisible by 100 (ceil(N/100)).','',
              '## Physical footprint','',
              '![Heap versus physical footprint](memory-lifetime.png)','',
              '| Dense populated world | Live heap delta MiB | Physical footprint delta MiB | RSS delta MiB | Process footprint peak MiB |',
              '| --- | ---: | ---: | ---: | ---: |']
    for f in FRAMEWORKS:
        r=row('dense_payload','populated',f)
        content.append(f"| {NAMES[f]} | {heap(r):.2f} | {physical(r):.2f} | {float(r['resident_delta_median'])/MIB:.2f} | {float(r['footprint_peak_median'])/MIB:.2f} |")
    content+=['','The primary metric is all-zone malloc live heap. It includes allocation rounding and retained engine capacity; it is not just useful component bytes. Physical footprint is separately reported because allocator pages, first-use runtime effects and process accounting differ. Peak columns are **absolute process lifetime peaks**, not phase-local or net allocation peaks.','',
              (f"All {len(meta['configurations'])*meta['repeats']} Release processes observed per backend returned live malloc bytes to their pre-world baseline at world destruction. This is evidence for these tested lifetimes, not a general leak-proof guarantee. " if returned_to_baseline else 'Residual live-heap deltas after destruction are retained in the raw data. ')+
              'Physical footprint often remains high because the allocator retains pages. Deleting entities alone does not promise capacity release.','',
              '## Reproduction and evidence','',
              'The separate Release and ASan/UBSan smokes each passed 115 fresh processes / 550 checkpoints, including one entity, a non-power-of-two population of 1,031, sparse values, fragmentation, deletion, and four recycling cycles. Sanitized memory usage is excluded from the Release report.','',
              f"Cedar source: `{meta['cedar']['snapshot_sha256']}` (`{meta['cedar']['label']}`). Engine implementation and the retained speed binaries were unchanged. The other dependencies retain their entity-suite pins.",'',
              'See [all measurements and quartiles](summary.csv), [every raw checkpoint](raw.jsonl), [pins, compiler configuration and binary hashes](metadata.json), and [archived probe sources](source/). The [methodology and commands](../../bench/memory/README.md) explain accounting and limitations.','']
    report=root/'REPORT.md';report.write_text('\n'.join(content));outputs.append(report)
    # Keep the postprocessing source separate from the measured harness archive.
    shutil.copy2(Path(__file__),root/'report-source.py')
    (root/'figure-provenance.json').write_text(json.dumps(dict(
        inputs={p.name:sha(p) for p in (root/'summary.csv',root/'metadata.json',root/'raw.jsonl')},
        outputs={p.name:sha(p) for p in outputs},script_sha256=sha(Path(__file__)),
        scope='All eleven scenarios at largest tested population; complete size sweep retained in CSV; no best-of-policy selection; physical footprint and live heap distinguished.'),indent=2)+'\n')
    print('Exported memory figures (PNG/SVG/PDF), complete report and source hashes:',root)

if __name__=='__main__':main()
