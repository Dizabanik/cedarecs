#!/usr/bin/env python3
"""Serial fresh-process memory sweeps with matching payloads and archived sources."""
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import random
import shutil
import statistics
import subprocess

ROOT = Path(__file__).resolve().parents[2]
FRAMEWORKS = ('cedar-packed', 'cedar-indexed', 'entt', 'pico', 'flecs')
SCENARIOS = ('empty', 'position', 'position_velocity', 'dense_payload', 'sparse_payload',
             'fragmented', 'delete_half', 'delete_95', 'remove_payload', 'recycle', 'clear')
ADDITIONAL = ('sparse_payload_01', 'sparse_payload_10', 'payload_low_slots',
              'payload_high_slots', 'component_cycle', 'empty_refill', 'delete_99',
              'world_cycles', 'signature_cycles', 'growth_steps')
METRICS = ('malloc_in_use', 'malloc_reserved', 'malloc_blocks', 'resident',
           'resident_peak', 'footprint', 'footprint_peak', 'compressed')
EXTRA_METRICS=('mapped_virtual','mapped_logical','mapped_resident','accounted_storage')
def metrics_for(rows):
    return METRICS+tuple(k for k in EXTRA_METRICS if k in rows[0])
PINS = dict(entt='78213075654a688e9da6bc49f7f873d25c26d12c',
            pico='cfd880ec0804c060ad624a19a02a39b0deeb5ba4',
            flecs_reference='02c8c2666b22ccce5706c8f16efaf813704fe31e')

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def validate_process(rows, framework, scenario, entities, snapshot):
    assert rows and [r['step'] for r in rows] == list(range(len(rows)))
    assert [r['phase'] for r in rows[:2]] == ['baseline', 'registered']
    assert rows[-1]['phase'] == 'destroyed'
    assert all(r['framework'] == framework and r['scenario'] == scenario and r['entities'] == entities for r in rows)
    assert all(r['cedar_snapshot'] == (snapshot if framework.startswith('cedar') else '') for r in rows)
    for r in rows:
        assert all(isinstance(r[m], int) and r[m] >= 0 for m in metrics_for(rows))
        if 'accounted_storage' in r:
            assert r['accounted_storage']==r['malloc_in_use']+r['mapped_logical']
            assert r['mapped_resident']<=r['mapped_virtual'] and r['mapped_logical']<=r['mapped_virtual']
        assert r['resident'] > 0 and r['footprint'] > 0
        assert 0 <= r['live'] <= entities and r['payload_bytes'] >= 0
    assert next(r for r in rows if r['phase']=='populated')['live'] == entities
    def counts(phase, step):
        if phase in ('baseline', 'registered', 'destroyed', 'world_destroyed', 'registered_again'): return (0, 0, 0)
        live = entities
        if phase.startswith('grown_'):
            live=(entities*int(phase.split('_')[1])+99)//100
        if phase == 'deleted':
            live = ((entities + 99) // 100 if scenario == 'delete_99' else
                    ((entities + 19) // 20 if scenario == 'delete_95' else
                     (0 if scenario in ('clear','empty_refill') else entities // 2)))
        if scenario == 'empty' or scenario == 'world_only': return live, 0, 0
        if scenario == 'position': return live, live, live * 16
        if scenario == 'position_velocity' or phase == 'removed': return live, live * 2, live * 32
        if scenario in ('sparse_payload','sparse_payload_01','sparse_payload_10'):
            divisor={'sparse_payload':100,'sparse_payload_01':1000,'sparse_payload_10':10}[scenario]
            payloads = (entities + divisor-1) // divisor
            return live, live * 2 + payloads, live * 32 + payloads * 256
        if scenario in ('payload_low_slots','payload_high_slots'):
            payloads=(entities+99)//100
            return live,payloads,payloads*256
        if scenario in ('fragmented','signature_cycles'):
            counts = [sum(1 for i in range(entities % 8) if i & (1 << c)) + (entities // 8) * 4 for c in range(3)]
            if phase=='shifted' and (step-3)%2==0: counts=[entities-n for n in counts]
            return live, sum(counts), counts[0]*16 + counts[1]*16 + counts[2]*256
        return live, live * 3, live * 288
    for r in rows:
        assert (r['live'], r['components'], r['payload_bytes']) == counts(r['phase'],r['step']), (scenario, r)
    phases = [r['phase'] for r in rows]
    expected = ['baseline', 'registered'] + (['grown_25','grown_50','grown_75'] if scenario=='growth_steps' else []) + ['populated']
    if scenario in ('delete_half', 'delete_95', 'delete_99', 'clear', 'recycle'): expected += ['deleted']
    if scenario == 'recycle': expected += ['regrown'] * 4
    if scenario == 'remove_payload': expected += ['removed']
    if scenario == 'component_cycle': expected += ['removed','readded']*4
    if scenario == 'empty_refill': expected += ['deleted','regrown']*4
    if scenario == 'world_cycles': expected += ['world_destroyed','registered_again','recreated']*4
    if scenario == 'signature_cycles': expected += ['shifted']*4
    assert phases == expected + ['destroyed']

def summarize(raw):
    groups = {}
    for r in raw:
        key = (r['scenario'], r['entities'], r['step'], r['phase'], r['framework'])
        groups.setdefault(key, []).append(r)
    out = []
    for key, samples in sorted(groups.items()):
        row = dict(zip(('scenario','entities','step','phase','framework'), key))
        row['samples'] = len(samples)
        for name in ('live','components','payload_bytes','checksum'):
            assert len({s[name] for s in samples}) == 1
            row[name] = samples[0][name]
        for m in metrics_for(samples):
            for suffix in ('', '_delta'):
                name = m + suffix
                values = [s[name] for s in samples]
                q = statistics.quantiles(values, n=4, method='inclusive') if len(values) > 1 else [values[0]]*3
                row[name + '_median'] = statistics.median(values)
                row[name + '_p25'] = q[0]
                row[name + '_p75'] = q[2]
        row['heap_bytes_per_live_entity'] = row['malloc_in_use_delta_median'] / row['live'] if row['live'] else ''
        row['footprint_bytes_per_live_entity'] = row['footprint_delta_median'] / row['live'] if row['live'] else ''
        out.append(row)
    return out

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--build', type=Path, default=ROOT/'build/memory')
    p.add_argument('--references', type=Path, default=ROOT/'build/interop/_deps')
    p.add_argument('--sizes', type=int, nargs='+', default=[1024,65536,262144])
    p.add_argument('--suite', choices=('baseline','additional','all'), default='baseline')
    p.add_argument('--repeats', type=int, default=5)
    p.add_argument('--smoke', action='store_true')
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    assert args.repeats >= 1 and all(0 < n <= 10000000 for n in args.sizes)
    sizes = [1,1031] if args.smoke else args.sizes
    repeats = 1 if args.smoke else args.repeats
    scenarios=SCENARIOS if args.suite=='baseline' else (ADDITIONAL if args.suite=='additional' else SCENARIOS+ADDITIONAL)
    configs = ([] if args.suite=='additional' else [('world_only',0)]) + [(s,n) for n in sizes for s in scenarios]
    provenance = json.loads((ROOT/'provenance.json').read_text())
    for name,h in provenance['cedarecs']['files'].items(): assert digest(ROOT/name) == h, name
    for name,commit in PINS.items():
        location = args.references/(name+'-src')
        assert subprocess.check_output(['git','-C',str(location),'rev-parse','HEAD'],text=True).strip() == commit
        assert not subprocess.check_output(['git','-C',str(location),'status','--porcelain'],text=True).strip()
    binaries = {f:args.build/(f+'-memory') for f in FRAMEWORKS}
    out = args.output.resolve(); out.mkdir(parents=True,exist_ok=False)
    sources = list(Path(__file__).parent.glob('*'))
    sources = [s for s in sources if s.is_file()]
    archive = out/'source'; archive.mkdir()
    for s in sources: shutil.copy2(s,archive/s.name)
    shutil.copytree(ROOT/'cedarecs',archive/'cedarecs',ignore=shutil.ignore_patterns('.git'))
    shutil.copy2(ROOT/'kama/kama.h',archive/'kama.h')
    shutil.copytree(ROOT/'kama',archive/'kama',ignore=shutil.ignore_patterns('.git'))
    shutil.copy2(ROOT/'provenance.json',archive/'provenance.json')
    meta = dict(suite='ecs-memory-v3', selection=args.suite, probe_version=3, metrics=METRICS+EXTRA_METRICS, started_utc=datetime.now(timezone.utc).isoformat(),
                configurations=[dict(scenario=s,entities=n) for s,n in configs], repeats=repeats,
                frameworks=FRAMEWORKS, pins=PINS, cedar=provenance['cedarecs'], kama=provenance['kama'], smoke=args.smoke,
                dependency_sha256={str(s.relative_to(ROOT/'kama')):digest(s)
                                   for s in sorted((ROOT/'kama').rglob('*')) if s.is_file() and '.git' not in s.parts},
                platform=platform.platform(), machine=platform.machine(),
                compiler=subprocess.check_output(['clang++','--version'],text=True),
                cmake_cache=(args.build/'CMakeCache.txt').read_text(),
                environment={k:v for k,v in os.environ.items() if k.startswith(('Malloc','DYLD_','ASAN_','TSAN_'))},
                binary_sha256={f:digest(b) for f,b in binaries.items()},
                source_sha256={s.name:digest(s) for s in sources},
                engine_source_archive=True,
                methodology='Fresh serial process per case/framework/repetition; rotating framework order; handle/mask buffers prefaulted before baseline; all three types registered; same individual create/set APIs and fully written payloads; no reserve, shrink, allocator purge or forced GC; checkpoints after full value/presence/liveness validation; all-zone malloc stats and TASK_VM_INFO; signed deltas from pre-world baseline; absolute figures retained; native default capacities/features differ; raw handles remain outside world after destruction; memory figures are not timings.')
    (out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
    rng=random.Random(0xCEDA); initial=list(FRAMEWORKS); rng.shuffle(initial)
    raw=[]
    with (out/'raw.jsonl').open('w') as raw_file:
        for trial in range(repeats):
            for index,(scenario,n) in enumerate(configs):
                offset=(trial+index)%len(initial); order=initial[offset:]+initial[:offset]
                if trial%2: order=order[::-1]
                expected=None
                for position,framework in enumerate(order):
                    command=[str(binaries[framework].resolve()),scenario,str(n)]
                    process=subprocess.run(command,text=True,capture_output=True,timeout=120)
                    if process.returncode:
                        (out/'failure.json').write_text(json.dumps(dict(command=command,returncode=process.returncode,stdout=process.stdout,stderr=process.stderr),indent=2))
                        raise RuntimeError(f'{framework} {scenario}/{n}: {process.stderr}')
                    assert not process.stderr, process.stderr
                    rows=[json.loads(line) for line in process.stdout.splitlines()]
                    validate_process(rows,framework,scenario,n,provenance['cedarecs']['snapshot_sha256'])
                    assert all(r.get('probe_version')==3 for r in rows), 'Rebuild the memory probe before running v3'
                    logical=[tuple(r[k] for k in ('phase','live','components','payload_bytes','checksum')) for r in rows]
                    if expected is None: expected=logical
                    assert logical==expected,(framework,scenario,n,'logical mismatch')
                    baseline=rows[0]
                    for r in rows:
                        r.update(trial=trial,order=position)
                        for m in metrics_for(rows): r[m+'_delta']=r[m]-baseline[m]
                        raw.append(r); raw_file.write(json.dumps(r)+'\n')
                raw_file.flush()
                print(f'{trial+1}/{repeats} [{index+1}/{len(configs)}] {scenario}/{n}: five backends verified',flush=True)
    rows=summarize(raw)
    with (out/'summary.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,list(rows[0]));writer.writeheader();writer.writerows(rows)
    meta.update(completed_utc=datetime.now(timezone.utc).isoformat(),processes=len(configs)*len(FRAMEWORKS)*repeats,checkpoints=len(raw))
    (out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
    print('Results:',out)

if __name__ == '__main__': main()
