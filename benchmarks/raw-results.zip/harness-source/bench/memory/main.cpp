// One fresh process per population/shape. No framework internals are patched.
#include <array>
#include <cinttypes>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <memory>
#include <string_view>
#include <vector>
#include <mach/mach.h>
#include <mach/task_info.h>
#include <malloc/malloc.h>

struct Position { uint64_t words[2]; };
struct Velocity { uint64_t words[2]; };
struct Payload { uint64_t words[32]; };
static_assert(sizeof(Position) == 16 && sizeof(Velocity) == 16 && sizeof(Payload) == 256);
[[noreturn]] static void fail(const char *s) { std::fprintf(stderr, "%s\n", s); std::abort(); }

#if defined(MEMORY_CEDAR)
#include "cedar.h"
struct Backend {
    using Entity = uint64_t;
    memory_cedar_world *world;
    Backend() {
#ifdef MEMORY_INDEXED
        world = memory_cedar_new(1);
#else
        world = memory_cedar_new(0);
#endif
    }
    ~Backend() { memory_cedar_free(world); }
    Entity create() { return memory_cedar_entity(world); }
    void destroy(Entity e) { memory_cedar_kill(world, e); }
    void put(Entity e, unsigned c, const void *p) { memory_cedar_put(world, e, c, p); }
    void remove(Entity e, unsigned c) { memory_cedar_remove(world, e, c); }
    const void *get(Entity e, unsigned c) { return memory_cedar_get(world, e, c); }
    bool alive(Entity e) { return memory_cedar_alive(world, e); }
};
#elif defined(MEMORY_ENTT)
#include <entt/entt.hpp>
struct Backend {
    using Entity = entt::entity;
    entt::registry world;
    Backend() { world.storage<Position>(); world.storage<Velocity>(); world.storage<Payload>(); }
    Entity create() { return world.create(); }
    void destroy(Entity e) { world.destroy(e); }
    void put(Entity e, unsigned c, const void *p) {
        if (c == 0) world.emplace_or_replace<Position>(e, *static_cast<const Position *>(p));
        else if (c == 1) world.emplace_or_replace<Velocity>(e, *static_cast<const Velocity *>(p));
        else world.emplace_or_replace<Payload>(e, *static_cast<const Payload *>(p));
    }
    void remove(Entity e, unsigned c) {
        if (c == 0) world.remove<Position>(e);
        else if (c == 1) world.remove<Velocity>(e);
        else world.remove<Payload>(e);
    }
    const void *get(Entity e, unsigned c) {
        if (c == 0) return world.try_get<Position>(e);
        if (c == 1) return world.try_get<Velocity>(e);
        return world.try_get<Payload>(e);
    }
    bool alive(Entity e) { return world.valid(e); }
};
#elif defined(MEMORY_PICO)
#include <pico_ecs.h>
struct Backend {
    using Entity = ecs_id_t;
    ecs_t *world = ecs_new(1024, nullptr);
    ecs_id_t ids[3];
    Backend() {
        if (!world) fail("pico world allocation failed");
        ids[0] = ecs_register_component(world, sizeof(Position), nullptr, nullptr);
        ids[1] = ecs_register_component(world, sizeof(Velocity), nullptr, nullptr);
        ids[2] = ecs_register_component(world, sizeof(Payload), nullptr, nullptr);
    }
    ~Backend() { ecs_free(world); }
    Entity create() { return ecs_create(world); }
    void destroy(Entity e) { ecs_destroy(world, e); }
    void put(Entity e, unsigned c, const void *p) {
        void *dst = ecs_add(world, e, ids[c], nullptr);
        if (!dst) fail("pico allocation failed");
        std::memcpy(dst, p, c == 2 ? sizeof(Payload) : sizeof(Position));
    }
    void remove(Entity e, unsigned c) { ecs_remove(world, e, ids[c]); }
    const void *get(Entity e, unsigned c) { return ecs_has(world, e, ids[c]) ? ecs_get(world, e, ids[c]) : nullptr; }
    bool alive(Entity e) { return ecs_is_ready(world, e); }
};
#elif defined(MEMORY_FLECS)
#include <flecs.h>
struct Backend {
    using Entity = ecs_entity_t;
    flecs::world world;
    Backend() { world.component<Position>(); world.component<Velocity>(); world.component<Payload>(); }
    Entity create() { return world.entity().id(); }
    void destroy(Entity e) { world.entity(e).destruct(); }
    void put(Entity e, unsigned c, const void *p) {
        auto entity = world.entity(e);
        if (c == 0) entity.set<Position>(*static_cast<const Position *>(p));
        else if (c == 1) entity.set<Velocity>(*static_cast<const Velocity *>(p));
        else entity.set<Payload>(*static_cast<const Payload *>(p));
    }
    void remove(Entity e, unsigned c) {
        auto entity = world.entity(e);
        if (c == 0) entity.remove<Position>();
        else if (c == 1) entity.remove<Velocity>();
        else entity.remove<Payload>();
    }
    const void *get(Entity e, unsigned c) {
        auto entity = world.entity(e);
        if (c == 0) return entity.get<Position>();
        if (c == 1) return entity.get<Velocity>();
        return entity.get<Payload>();
    }
    bool alive(Entity e) { return world.is_alive(e); }
};
#endif

static Backend *observed_backend;
struct Checkpoint {
    const char *phase;
    uint64_t live{}, components{}, payload_bytes{}, checksum{};
    uint64_t malloc_in_use{}, malloc_reserved{}, malloc_blocks{};
    uint64_t resident{}, resident_peak{}, footprint{}, footprint_peak{}, compressed{};
    uint64_t mapped_virtual{}, mapped_logical{}, mapped_resident{}, accounted_storage{};
};
static void account(Checkpoint &p) {
#if defined(MEMORY_CEDAR)
    memory_cedar_allocations mapped{};
    memory_cedar_measure(observed_backend ? observed_backend->world : nullptr, &mapped);
    p.mapped_virtual=mapped.virtual_bytes;p.mapped_logical=mapped.logical_bytes;p.mapped_resident=mapped.resident_bytes;
#endif
    malloc_statistics_t stats{};
    malloc_zone_statistics(nullptr, &stats); // Sum every malloc zone, including nano.
    task_vm_info_data_t vm{};
    mach_msg_type_number_t count = TASK_VM_INFO_COUNT;
    if (task_info(mach_task_self(), TASK_VM_INFO, reinterpret_cast<task_info_t>(&vm), &count) != KERN_SUCCESS || count < TASK_VM_INFO_REV3_COUNT)
        fail("TASK_VM_INFO accounting failed");
    p.malloc_in_use = stats.size_in_use;
    p.malloc_reserved = stats.size_allocated;
    p.malloc_blocks = stats.blocks_in_use;
    p.accounted_storage=p.malloc_in_use+p.mapped_logical;
    p.resident = vm.resident_size;
    p.resident_peak = vm.resident_size_peak;
    p.footprint = vm.phys_footprint;
    p.footprint_peak = static_cast<uint64_t>(vm.ledger_phys_footprint_peak);
    p.compressed = vm.compressed;
}
static uint64_t word(size_t ordinal, unsigned component, size_t lane) {
    return (static_cast<uint64_t>(ordinal) + 1) * UINT64_C(0x9e3779b97f4a7c15) ^
        (static_cast<uint64_t>(component) + 7) * UINT64_C(0xbf58476d1ce4e5b9) ^ lane;
}
static void populate(Backend &b, Backend::Entity e, size_t ordinal, unsigned mask) {
    Position p{}; Velocity v{}; Payload d{};
    for (unsigned c = 0; c < 3; ++c) {
        if (!(mask & (1u << c))) continue;
        const size_t lanes = c == 2 ? 32 : 2;
        uint64_t *words = c == 0 ? p.words : (c == 1 ? v.words : d.words);
        for (size_t j = 0; j < lanes; ++j) words[j] = word(ordinal, c, j);
        const void *object = c == 0 ? static_cast<const void *>(&p) :
            (c == 1 ? static_cast<const void *>(&v) : static_cast<const void *>(&d));
        b.put(e, c, object);
    }
}
static uint64_t mix(uint64_t h, uint64_t v) { return (h ^ v) * UINT64_C(1099511628211); }
static Checkpoint check(const char *phase, Backend &b, const std::vector<Backend::Entity> &entities,
                        const std::vector<unsigned char> &masks) {
    Checkpoint p{}; p.phase = phase; p.checksum = UINT64_C(1469598103934665603);
    for (size_t i = 0; i < entities.size(); ++i) {
        // 254 denotes preallocated harness space not yet assigned an entity.
        // Its default numeric handle can alias an actual live slot, so it is
        // deliberately excluded from native liveness checks during growth.
        if (masks[i] == 254) { p.checksum = mix(p.checksum, 0); continue; }
        const bool expected_live = masks[i] != 255;
        if (b.alive(entities[i]) != expected_live) fail("liveness mismatch");
        p.checksum = mix(p.checksum, expected_live ? i + 1 : 0);
        if (!expected_live) continue;
        ++p.live;
        p.checksum = mix(p.checksum, masks[i]);
        for (unsigned c = 0; c < 3; ++c) {
            const void *data = b.get(entities[i], c);
            if (static_cast<bool>(data) != static_cast<bool>(masks[i] & (1u << c))) fail("component presence mismatch");
            if (!data) continue;
            ++p.components;
            const size_t lanes = c == 2 ? 32 : 2;
            p.payload_bytes += lanes * sizeof(uint64_t);
            // memcpy reads the object representation without type-punning C++ components.
            for (size_t j = 0; j < lanes; ++j) {
                uint64_t value;
                std::memcpy(&value, static_cast<const unsigned char *>(data) + j * sizeof(value), sizeof(value));
                if (value != word(i, c, j)) fail("payload mismatch");
                p.checksum = mix(p.checksum, value);
            }
        }
    }
    account(p);
    return p;
}
static unsigned shape(std::string_view scenario, size_t i) {
    if (scenario == "world_only" || scenario == "empty") return 0;
    if (scenario == "position") return 1;
    if (scenario == "position_velocity") return 3;
    if (scenario == "sparse_payload") return i % 100 == 0 ? 7 : 3;
    if (scenario == "sparse_payload_01") return i % 1000 == 0 ? 7 : 3;
    if (scenario == "sparse_payload_10") return i % 10 == 0 ? 7 : 3;
    if (scenario == "fragmented" || scenario == "signature_cycles") return static_cast<unsigned>(i % 8);
    return 7;
}
static void prefault(void *data, size_t bytes) {
    auto *p = static_cast<volatile unsigned char *>(data);
    for (size_t i = 0; i < bytes; i += 4096) p[i] = p[i];
    if (bytes) p[bytes - 1] = p[bytes - 1];
}
int main(int argc, char **argv) {
    if (argc != 3) return 2;
    const std::string_view scenario = argv[1];
    constexpr std::array names{"world_only", "empty", "position", "position_velocity", "dense_payload", "sparse_payload", "fragmented", "delete_half", "delete_95", "remove_payload", "recycle", "clear",
        "sparse_payload_01", "sparse_payload_10", "payload_low_slots", "payload_high_slots", "component_cycle", "empty_refill", "delete_99", "world_cycles", "signature_cycles", "growth_steps"};
    bool known = false;
    for (auto name : names) known |= scenario == name;
    char *end = nullptr;
    const unsigned long count = std::strtoul(argv[2], &end, 10);
    if (!known || !end || *end || count > 10000000 || ((scenario == "world_only") != (count == 0))) return 2;
    std::vector<Backend::Entity> entities(count);
    std::vector<unsigned char> masks(count, 254);
    // Allocate and fault the harness's entire handle/mask storage before baseline.
    for (auto &e : entities) e = Backend::Entity{};
    prefault(entities.data(), entities.size() * sizeof(Backend::Entity));
    prefault(masks.data(), masks.size());
    std::array<Checkpoint, 64> points{};
    size_t used = 0;
    Checkpoint warm{}; account(warm);
    points[used].phase = "baseline"; account(points[used++]);
    auto backend = std::make_unique<Backend>();
    observed_backend=backend.get();
    points[used] = check("registered", *backend, {}, {}); ++used;
    auto create_one = [&](size_t i) {
        entities[i] = backend->create();
        const size_t sparse_count = (count + 99) / 100;
        const unsigned mask = scenario == "payload_low_slots" ? (i < sparse_count ? 4 : 0) :
            (scenario == "payload_high_slots" ? (i >= count - sparse_count ? 4 : 0) : shape(scenario, i));
        masks[i] = static_cast<unsigned char>(mask);
        populate(*backend, entities[i], i, masks[i]);
    };
    if (scenario == "growth_steps") {
        constexpr std::array phases{"grown_25", "grown_50", "grown_75", "populated"};
        size_t begin = 0;
        for (size_t part = 1; part <= 4; ++part) {
            const size_t end_count = (count * part + 3) / 4;
            for (size_t i = begin; i < end_count; ++i) create_one(i);
            points[used++] = check(phases[part - 1], *backend, entities, masks);
            begin = end_count;
        }
    } else {
        for (size_t i = 0; i < count; ++i) create_one(i);
        points[used++] = check("populated", *backend, entities, masks);
    }
    if (scenario == "delete_half" || scenario == "delete_95" || scenario == "delete_99" || scenario == "clear" || scenario == "recycle") {
        auto remove_some = [&] {
            for (size_t i = 0; i < count; ++i) {
                const bool remove = scenario == "clear" || (scenario == "delete_95" ? i % 20 != 0 :
                    (scenario == "delete_99" ? i % 100 != 0 : i % 2 == 0));
                if (remove) { backend->destroy(entities[i]); masks[i] = 255; }
            }
        };
        remove_some();
        points[used++] = check("deleted", *backend, entities, masks);
        if (scenario == "recycle") {
            for (unsigned round = 0; round < 4; ++round) {
                if (round) remove_some();
                for (size_t i = 0; i < count; ++i) if (masks[i] == 255) {
                    entities[i] = backend->create(); masks[i] = 7;
                    populate(*backend, entities[i], i, 7);
                }
                points[used++] = check("regrown", *backend, entities, masks);
            }
        }
    } else if (scenario == "remove_payload") {
        for (auto e : entities) backend->remove(e, 2);
        for (auto &mask : masks) mask = 3;
        points[used++] = check("removed", *backend, entities, masks);
    } else if (scenario == "component_cycle") {
        for (unsigned round = 0; round < 4; ++round) {
            for (size_t i = 0; i < count; ++i) { backend->remove(entities[i], 2); masks[i] = 3; }
            points[used++] = check("removed", *backend, entities, masks);
            for (size_t i = 0; i < count; ++i) { populate(*backend, entities[i], i, 4); masks[i] = 7; }
            points[used++] = check("readded", *backend, entities, masks);
        }
    } else if (scenario == "empty_refill") {
        for (unsigned round = 0; round < 4; ++round) {
            for (size_t i = 0; i < count; ++i) { backend->destroy(entities[i]); masks[i] = 255; }
            points[used++] = check("deleted", *backend, entities, masks);
            for (size_t i = 0; i < count; ++i) create_one(i);
            points[used++] = check("regrown", *backend, entities, masks);
        }
    } else if (scenario == "signature_cycles") {
        for (unsigned round = 0; round < 4; ++round) {
            for (size_t i = 0; i < count; ++i) {
                const unsigned mask = masks[i] ^ 7;
                for (unsigned c = 0; c < 3; ++c) if (!(mask & (1u << c))) backend->remove(entities[i], c);
                populate(*backend, entities[i], i, mask); masks[i] = static_cast<unsigned char>(mask);
            }
            points[used++] = check("shifted", *backend, entities, masks);
        }
    } else if (scenario == "world_cycles") {
        for (unsigned round = 0; round < 4; ++round) {
            observed_backend=nullptr;backend.reset();
            points[used].phase = "world_destroyed"; account(points[used++]);
            backend = std::make_unique<Backend>();
            observed_backend=backend.get();
            points[used++] = check("registered_again", *backend, {}, {});
            for (size_t i = 0; i < count; ++i) create_one(i);
            points[used++] = check("recreated", *backend, entities, masks);
        }
    }
    observed_backend=nullptr;backend.reset();
    points[used].phase = "destroyed"; account(points[used++]);
    for (size_t i = 0; i < used; ++i) {
        const auto &p = points[i];
        std::printf("{\"framework\":\"%s\",\"scenario\":\"%s\",\"entities\":%lu,\"step\":%zu,\"phase\":\"%s\","
                    "\"live\":%" PRIu64 ",\"components\":%" PRIu64 ",\"payload_bytes\":%" PRIu64 ",\"checksum\":\"%016" PRIx64 "\","
                    "\"malloc_in_use\":%" PRIu64 ",\"malloc_reserved\":%" PRIu64 ",\"malloc_blocks\":%" PRIu64 ","
                    "\"resident\":%" PRIu64 ",\"resident_peak\":%" PRIu64 ",\"footprint\":%" PRIu64 ",\"footprint_peak\":%" PRIu64 ",\"compressed\":%" PRIu64 ","
                    "\"mapped_virtual\":%" PRIu64 ",\"mapped_logical\":%" PRIu64 ",\"mapped_resident\":%" PRIu64 ",\"accounted_storage\":%" PRIu64 ","
                    "\"probe_version\":3,\"cedar_snapshot\":\"%s\"}\n",
                    MEMORY_FRAMEWORK, argv[1], count, i, p.phase, p.live, p.components, p.payload_bytes, p.checksum,
                    p.malloc_in_use, p.malloc_reserved, p.malloc_blocks, p.resident, p.resident_peak, p.footprint, p.footprint_peak, p.compressed,
                    p.mapped_virtual,p.mapped_logical,p.mapped_resident,p.accounted_storage,
#ifdef MEMORY_CEDAR
                    CEDAR_COMPILED_SNAPSHOT
#else
                    ""
#endif
        );
    }
}
