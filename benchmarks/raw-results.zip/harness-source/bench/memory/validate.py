#!/usr/bin/env python3
"""Recompute all memory summaries and cross-engine logical parity from raw records."""
import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path
from run import FRAMEWORKS, METRICS, metrics_for, digest, summarize, validate_process

def main():
    p=argparse.ArgumentParser();p.add_argument('results',type=Path);args=p.parse_args()
    root=args.results;meta=json.loads((root/'metadata.json').read_text())
    assert meta['suite'] in ('ecs-memory-v1','ecs-memory-v2','ecs-memory-v3') and 'completed_utc' in meta
    for name,h in meta['source_sha256'].items(): assert digest(root/'source'/name)==h,name
    for name,h in meta['cedar']['files'].items():
        assert digest(root/'source'/name)==h,name
    raw=[json.loads(line) for line in (root/'raw.jsonl').read_text().splitlines()]
    assert len(raw)==meta['checkpoints']
    processes=defaultdict(list)
    for r in raw: processes[(r['scenario'],r['entities'],r['trial'],r['framework'])].append(r)
    assert len(processes)==meta['processes']==len(meta['configurations'])*len(FRAMEWORKS)*meta['repeats']
    for c in meta['configurations']:
        for trial in range(meta['repeats']):
            expected=None;orders=set()
            for framework in FRAMEWORKS:
                rows=processes[(c['scenario'],c['entities'],trial,framework)]
                validate_process(rows,framework,c['scenario'],c['entities'],meta['cedar']['snapshot_sha256'])
                if meta['suite']!='ecs-memory-v1': assert all(r.get('probe_version')==meta['probe_version'] for r in rows)
                assert len({r['order'] for r in rows})==1
                orders.add(rows[0]['order'])
                for r in rows:
                    for m in metrics_for(rows): assert r[m+'_delta']==r[m]-rows[0][m]
                logical=[tuple(r[k] for k in ('phase','live','components','payload_bytes','checksum')) for r in rows]
                if expected is None: expected=logical
                assert logical==expected
            assert orders==set(range(len(FRAMEWORKS)))
    summary=list(csv.DictReader((root/'summary.csv').open()))
    expected=summarize(raw)
    assert len(summary)==len(expected)
    for actual,want in zip(summary,expected):
        assert set(actual)==set(want)
        for k,v in want.items():
            if isinstance(v,(int,float)): assert abs(float(actual[k])-v)<=1e-7*max(1,abs(v)),k
            else: assert actual[k]==str(v),k
    print(f'Verified {len(processes)} fresh processes, {len(raw)} checkpoints, five backends, full payload checksums, analytical counts, source archives, baseline deltas and quartiles.')

if __name__=='__main__':main()
