// Allocation accounting diagnostic; not part of timed workloads or public ECS.
#include <cedarecs/ecs/internal.h>
#include <malloc/malloc.h>
#include <inttypes.h>
#include <stdio.h>

static uint64_t heap(void) { malloc_statistics_t s; malloc_zone_statistics(NULL, &s); return s.size_in_use; }
int main(int argc, char **argv) {
    if (argc != 4) return 2;
    size_t n = strtoull(argv[3], NULL, 10);
    if (!n || n > 10000000) return 2;
    const char *scenario=argv[2];
    uint64_t baseline=heap();
    ced_World *w=atoi(argv[1]) ? ced_init_indexed() : ced_init();
    size_t sizes[3]={16,16,256};
    ced_Component ids[3];
    const char *names[3]={"Position","Velocity","Payload"};
    for (size_t c=0;c<3;c++) ids[c]=ced_component_register(w,names[c],sizes[c],8);
    uint64_t data[32]={1};
    for (size_t i=0;i<n;i++) {
        ced_Entity e=ced_entity(w);
        unsigned mask=!strcmp(scenario,"empty")?0:(!strcmp(scenario,"position")?1:3);
        if (!strcmp(scenario,"dense_payload") || (!strcmp(scenario,"sparse_payload") && i%100==0)) mask|=4;
        for (size_t c=0;c<3;c++) if (mask&(1u<<c))
            if (!ced_add_set_component(w,e,ids[c],data)) abort();
    }
    size_t arch_entities=0,packed_data=0,live_data=0,empty_data=0,indexed_data=0,owners=0;
    for (size_t i=0;i<w->archetype_count;i++) {
        ced_Archetype *a=w->archetypes[i];
        if (!w->indexed) arch_entities+=a->capacity*sizeof(*a->entities);
        for (size_t c=0;c<a->type_count;c++) {
            size_t size=a->columns[c].component_size;
            live_data+=a->count*size;
            if (!w->indexed) {
                packed_data+=a->capacity*size;
                if (!a->count) empty_data+=a->capacity*size;
            }
        }
    }
    for (size_t c=0;c<3;c++) {
        indexed_data+=w->components[c]->indexed.capacity*sizes[c];
        owners+=ced_indexed_owner_bytes(w->components[c],w->components[c]->indexed.capacity);
    }
    printf("{\"scenario\":\"%s\",\"entities\":%zu,\"indexed\":%s,\"heap_delta\":%" PRIu64 ",\"entity_capacity\":%zu,"
           "\"record_bytes\":%zu,\"archetype_entity_bytes\":%zu,\"indexed_entity_bytes\":%zu,"
           "\"packed_data_bytes\":%zu,\"indexed_data_bytes\":%zu,\"indexed_owner_bytes\":%zu,"
           "\"logical_live_data_bytes\":%zu,\"empty_archetype_data_bytes\":%zu,\"fixed_world_bytes\":%zu}\n",
           scenario,n,w->indexed?"true":"false",heap()-baseline,w->entity_capacity,
           w->entity_capacity*sizeof(*w->entities),arch_entities,w->_indexed_entities?w->entity_capacity*sizeof(*w->_indexed_entities):0,
           packed_data,indexed_data,owners,live_data,empty_data,sizeof(ced_Allocation));
    ced_drop(w);
}
