/* Query-owned malloc storage only; world/component storage is excluded. */
#include <cedarecs/cedar.h>
#include <assert.h>
#include <malloc/malloc.h>
#include <stdio.h>
#include <stdlib.h>

static void account(const void *pointer, size_t *bytes, size_t *allocations) {
    if (pointer) {
        *bytes += malloc_size(pointer);
        ++*allocations;
    }
}

static void checkpoint(ced_View *query, size_t population, const char *stage) {
    ced_view_refresh(query, query->world);
    size_t bytes = 0, allocations = 0, binding_bytes = 0, binding_allocations = 0;
    account(query, &bytes, &allocations);
    account(query->components, &bytes, &allocations);
    account(query->_field_sizes, &bytes, &allocations);
    account(query->matches, &bytes, &allocations);
    account(query->_dispatch_jobs, &bytes, &allocations);
    account(query->_serial_jobs, &bytes, &allocations);
#if QUERY_BINDING_ARENA
    if (query->_column_slots != SIZE_MAX) {
        account(query->_column_storage, &binding_bytes, &binding_allocations);
    } else
#endif
    {
        for (size_t i = 0; i < query->match_count; ++i)
            account(query->matches[i].column_ptrs, &binding_bytes, &binding_allocations);
    }
    bytes += binding_bytes;
    allocations += binding_allocations;
    printf("{\"population\":%zu,\"stage\":\"%s\",\"fields\":%zu,\"runs\":%zu,"
           "\"rows\":%zu,\"query_bytes\":%zu,\"query_allocations\":%zu,"
           "\"binding_bytes\":%zu,\"binding_allocations\":%zu}\n",
           population, stage, query->component_count, query->match_count,
           ced_view_count(query), bytes, allocations, binding_bytes, binding_allocations);
}

int main(int argc, char **argv) {
    assert(argc == 2);
    size_t population = strtoull(argv[1], NULL, 10);
    assert(population && population <= 65536);
    ced_World *world = ced_init_indexed();
    ced_Component ids[] = {
        ced_component_register(world, "P", 8, 8),
        ced_component_register(world, "V", 8, 8),
        ced_component_register(world, "Tag", 0, 1),
    };
    ced_SpawnPlan plans[] = {
        ced_spawn_plan_init(world, 2, ids), ced_spawn_plan_init(world, 3, ids),
    };
    ced_Entity *entities = malloc(population * sizeof(*entities));
    assert(entities);
    uint64_t value = 42;
    const void *values[] = {&value, &value, NULL};
    for (size_t i = 0; i < population; ++i)
        entities[i] = ced_entity_from_plan_values(world, &plans[i % 2], values);
    ced_View *queries[4];
    for (size_t fields = 0; fields < 4; ++fields) {
        queries[fields] = ced_view_from_ids(world, fields, ids);
        assert(queries[fields]);
        checkpoint(queries[fields], population, "full");
    }
    for (size_t i = 1; i < population; i += 2) ced_kill(world, entities[i]);
    for (size_t fields = 0; fields < 4; ++fields)
        checkpoint(queries[fields], population, "half");
    for (size_t i = 0; i < population; i += 2) ced_kill(world, entities[i]);
    for (size_t fields = 0; fields < 4; ++fields) {
        checkpoint(queries[fields], population, "empty");
        assert(!ced_view_count(queries[fields]));
    }
    assert(ced_entity_from_plan_values(world, &plans[1], values) != ced_entity_none);
    for (size_t fields = 0; fields < 4; ++fields) {
        checkpoint(queries[fields], population, "regrown");
        assert(ced_view_count(queries[fields]) == 1);
        ced_view_free(queries[fields]);
    }
    free(entities);
    ced_drop(world);
}
