#include "bench.h"
#include <cedarecs/cedar.h>

#ifndef CEDAR_SNAPSHOT
#define CEDAR_SNAPSHOT "unrecorded"
#endif
const char *bench_engine(void) { return "cedarecs"; }
const char *bench_version(void) { return CEDAR_SNAPSHOT; }

typedef struct World {
    ced_World *ecs;
    ced_Component position, velocity, health;
    ced_SpawnPlan plans[64];
    ced_Component types[64][8];
    size_t type_counts[64];
    ced_View *query;
    bool deferred, heavy;
} World;

static World *world_new(size_t archetypes) {
    World *w = calloc(1, sizeof(*w)); CHECK(w);
    w->ecs = ced_world(); CHECK(w->ecs);
    w->position = ced_component_register(w->ecs, "Position", sizeof(Position), _Alignof(Position));
    w->velocity = ced_component_register(w->ecs, "Velocity", sizeof(Velocity), _Alignof(Velocity));
    w->health = ced_component_register(w->ecs, "Health", sizeof(Health), _Alignof(Health));
    ced_Component tags[6];
    for (size_t i = 0; i < 6; i++) {
        char name[32]; snprintf(name, sizeof(name), "Group%zu", i);
        tags[i] = ced_component_register(w->ecs, name, 0, 1);
        CHECK(tags[i] != ced_component_none);
    }
    for (size_t group = 0; group < archetypes; group++) {
        size_t count = 2;
        w->types[group][0] = w->position; w->types[group][1] = w->velocity;
        for (size_t i = 0; i < 6; i++) if (group & ((size_t)1 << i)) w->types[group][count++] = tags[i];
        w->type_counts[group] = count;
        w->plans[group] = ced_spawn_plan_init(w->ecs, count, w->types[group]);
        CHECK(w->plans[group].archetype);
    }
    return w;
}
static void world_delete(World *w) { ced_drop(w->ecs); free(w); }
static inline Entity entity_new_empty(World *w) { return ced_entity(w->ecs); }
static inline Entity entity_new_pv(World *w, size_t group) { return ced_entity_from_plan(w->ecs, &w->plans[group]); }
static inline void assign_initial(World *w, Entity e, size_t i) {
    *(Position *)ced_get_component(w->ecs, e, w->position) = initial_position(i);
    *(Velocity *)ced_get_component(w->ecs, e, w->velocity) = initial_velocity(i);
}
static inline const Position *entity_position(World *w, Entity e) { return ced_get_component_const(w->ecs, e, w->position); }
static inline void entity_write_position(World *w, Entity e, Position p) { *(Position *)ced_get_component(w->ecs, e, w->position) = p; }
static inline void entity_set_position(World *w, Entity e, Position p) { ced_add_set_component(w->ecs, e, w->position, &p); }
static inline void entity_delete(World *w, Entity e) { ced_kill(w->ecs, e); }
static inline bool entity_alive(World *w, Entity e) { return ced_is_alive(w->ecs, e); }
static inline uint64_t entity_health_value(World *w, Entity e) { return ((const Health *)ced_get_component_const(w->ecs, e, w->health))->value; }
static inline bool entity_has_health(World *w, Entity e) { return ced_has_component(w->ecs, e, w->health); }
static inline void changes_begin(World *w, bool defer) { w->deferred = defer; if (defer) CHECK(ced_commands_begin(w->ecs)); }
static inline void changes_end(World *w, bool defer) { if (defer) { CHECK(ced_commands_end(w->ecs)); ced_flush(w->ecs); } w->deferred = false; }
static inline void entity_health(World *w, Entity e, uint64_t value) {
    Health health = {value};
    if (w->deferred) ced_defer_add_set_component(w->ecs, e, w->health, &health);
    else ced_add_set_component(w->ecs, e, w->health, &health);
}
static inline void entity_remove_health(World *w, Entity e) {
    if (w->deferred) ced_defer_remove_component(w->ecs, e, w->health);
    else ced_remove_component(w->ecs, e, w->health);
}
static void query_prepare(World *w) {
    ced_Component ids[] = {w->position, w->velocity};
    w->query = ced_view_from_ids(w->ecs, 2, ids); CHECK(w->query);
}
static void query_move(World *w) {
    ced_view_each(w->query, batch) {
        bench_light(ced_field(batch, Position, 0), ced_field_const(batch, Velocity, 1), batch->count);
    }
}
static size_t query_entity_count(World *w) { return ced_view_count(w->query); }
static void frame_callback(ced_World *ecs, const ced_Batch *batch, void *ctx) {
    (void)ecs;
    World *w = ctx;
    Position *p = ced_field(batch, Position, 0);
    const Velocity *v = ced_field_const(batch, Velocity, 1);
    if (w->heavy) bench_heavy(p, v, batch->count); else bench_light(p, v, batch->count);
}
static World *active_world;
static uint8_t frame_system(ced_World *ecs, int id, double dt) {
    (void)ecs; (void)id; (void)dt;
    CHECK(ced_parallel_each_auto(active_world->query, frame_callback, active_world));
    return 0;
}
static void frame_prepare(World *w, size_t threads, bool heavy) {
    query_prepare(w); w->heavy = heavy; active_world = w;
    CHECK(ced_set_threads(w->ecs, threads));
    ced_add_update_system(w->ecs, frame_system);
}
static void frame_move(World *w) { ced_update_frame(w->ecs, 1.0 / 60.0); }
#include "workloads.inc"
