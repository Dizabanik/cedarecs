// Adversarial lifetime workload: clear, then recreate a slightly larger world.
// This catches repeated allocation costs hidden by fixed-size recycle loops.
#include <cedarecs/cedar.h>
#include <cedarecs/ecs/internal.h>
#include <inttypes.h>

#ifndef CEDAR_SNAPSHOT
#define CEDAR_SNAPSHOT "unrecorded"
#endif
static void require(bool ok) { if (!ok) abort(); }
static uint64_t now_ns(void) {
    struct timespec ts;
    require(clock_gettime(CLOCK_MONOTONIC, &ts) == 0);
    return (uint64_t)ts.tv_sec * UINT64_C(1000000000) + (uint64_t)ts.tv_nsec;
}
int main(int argc, char **argv) {
    if (argc != 6) return 2;
    bool indexed = strtoul(argv[1], NULL, 10) != 0;
    size_t initial = strtoull(argv[2], NULL, 10);
    size_t cycles = strtoull(argv[3], NULL, 10);
    size_t step = strtoull(argv[4], NULL, 10);
    bool reverse = strtoul(argv[5], NULL, 10) != 0;
    if (!initial || !cycles || cycles > 1024 || !step || step > 65536 ||
        initial > 2000000 || cycles * step > 2000000) return 2;
    size_t maximum = initial + cycles * step;
    ced_Entity *entities = ced_xmalloc(ced_bytes(maximum, sizeof(*entities)));
    unsigned char *seen = ced_xcalloc(maximum, 1);
    // Keep external handle-buffer page faults outside the ECS timing loop.
    for (size_t i = 0; i < maximum; ++i) ((volatile ced_Entity *)entities)[i] = 0;
    ced_World *w = indexed ? ced_init_indexed() : ced_init();
    for (size_t i = 0; i < initial; ++i) entities[i] = ced_entity(w);
    size_t count = initial;
    uint64_t operations = 0;
    uint64_t begin = now_ns();
    for (size_t cycle = 0; cycle < cycles; ++cycle) {
        for (size_t i = 0; i < count; ++i)
            ced_kill(w, entities[reverse ? count - i - 1 : i]);
        operations += count;
        count += step;
        for (size_t i = 0; i < count; ++i) entities[i] = ced_entity(w);
        operations += count;
    }
    uint64_t elapsed = now_ns() - begin;
    require(count == maximum && w->alive_count == count && !w->free_count);
    uint64_t checksum = 0;
    for (size_t i = 0; i < count; ++i) {
        ced_Entity e = entities[i];
        uint32_t index = ced_entity_index(e);
        require(index < maximum && !seen[index] && ced_is_alive(w, e));
        seen[index] = 1;
        size_t age = index < initial ? cycles : cycles - 1 - (index - initial) / step;
        require(ced_entity_generation(e) == age);
        if (age) require(!ced_is_alive(w, e - (UINT64_C(1) << 32)));
        checksum += e;
    }
    require(operations == cycles * (2 * initial + step) + step * cycles * (cycles - 1));
    printf("{\"version\":\"%s\",\"indexed\":%s,\"initial\":%zu,\"cycles\":%zu,\"step\":%zu,\"reverse\":%s,\"operations\":%" PRIu64 ",\"checksum\":%" PRIu64 ",\"ns_per_op\":%.9f}\n",
        CEDAR_SNAPSHOT, indexed ? "true" : "false", initial, cycles, step,
        reverse ? "true" : "false", operations, checksum, (double)elapsed / (double)operations);
    ced_drop(w);
    free(seen);
    free(entities);
    return 0;
}
