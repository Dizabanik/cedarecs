#include <cedarecs/cedar.h>
#include <pthread.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#ifndef CEDAR_BUILD_SNAPSHOT
#define CEDAR_BUILD_SNAPSHOT "unknown"
#endif
typedef struct { ced_World **worlds; size_t count, passes, index; unsigned commands;
    ced_Entity (*entities)[16]; atomic_size_t *ready, *done; atomic_bool *go; } job;
static void require(bool ok) { if (!ok) abort(); }
static void *worker(void *pointer) {
    job *j = pointer;
    for (size_t i = 0; i < j->count; ++i) {
        require(ced_commands_begin(j->worlds[i])); require(ced_commands_end(j->worlds[i]));
    }
    atomic_fetch_add_explicit(j->ready, 1, memory_order_release);
    while (!atomic_load_explicit(j->go, memory_order_acquire)) { }
    for (size_t p = 0; p < j->passes; ++p)
        for (size_t i = 0; i < j->count; ++i) {
            require(ced_commands_begin(j->worlds[i]));
            if (j->commands) {
                uint64_t value = p;
                ced_defer_set_component(j->worlds[i], j->entities[i][j->index], 0, &value);
            }
            require(ced_commands_end(j->worlds[i]));
        }
    atomic_fetch_add_explicit(j->done, 1, memory_order_release);
    return NULL;
}
static uint64_t clock_ns(void) {
    struct timespec t; clock_gettime(CLOCK_MONOTONIC_RAW, &t);
    return (uint64_t)t.tv_sec * UINT64_C(1000000000) + (uint64_t)t.tv_nsec;
}
int main(int argc, char **argv) {
    if (argc != 5) return 2;
    size_t threads = strtoull(argv[1], NULL, 10), worlds = strtoull(argv[2], NULL, 10), passes = strtoull(argv[3], NULL, 10);
    require(threads > 0 && threads <= 16 && worlds > 0 && worlds <= 16 && passes);
    unsigned commands = (unsigned)strtoul(argv[4], NULL, 10); require(commands <= 1);
    ced_World *w[16]; for (size_t i = 0; i < worlds; ++i) w[i] = ced_world();
    ced_Entity entities[16][16] = {{0}};
    if (commands) for (size_t i = 0; i < worlds; ++i) {
        ced_Component c = ced_component_register(w[i], "Value", sizeof(uint64_t), _Alignof(uint64_t)); require(c == 0);
        ced_SpawnPlan plan = ced_spawn_plan_init(w[i], 1, &c);
        for (size_t t = 0; t < threads; ++t) entities[i][t] = ced_entity_from_plan(w[i], &plan);
    }
    atomic_size_t ready = 0, done = 0; atomic_bool go = false;
    job jobs[16]; pthread_t pool[16];
    for (size_t i = 0; i < threads; ++i) {
        jobs[i] = (job){w, worlds, passes, i, commands, entities, &ready, &done, &go};
        require(!pthread_create(pool + i, NULL, worker, jobs+i));
    }
    while (atomic_load_explicit(&ready, memory_order_acquire) != threads) { }
    uint64_t start = clock_ns(); atomic_store_explicit(&go, true, memory_order_release);
    while (atomic_load_explicit(&done, memory_order_acquire) != threads) { }
    uint64_t elapsed = clock_ns() - start;
    for (size_t i = 0; i < threads; ++i) require(!pthread_join(pool[i], NULL));
    uint64_t checksum = 0;
    for (size_t i = 0; i < worlds; ++i) {
        ced_flush(w[i]); require(w[i]->alive_count == (commands ? threads : 0));
        if (commands) for (size_t t = 0; t < threads; ++t) {
            const uint64_t *v = ced_get_component_const(w[i], entities[i][t], 0);
            require(v && *v == passes-1); checksum += *v;
        }
        ced_drop(w[i]);
    }
    printf("{\"version\":\"%s\",\"threads\":%zu,\"worlds\":%zu,\"operations\":%zu,\"checksum\":%" PRIu64 ",\"commands\":%u,\"ns_per_op\":%.9f}\n",
           CEDAR_BUILD_SNAPSHOT, threads, worlds, threads * worlds * passes, checksum, commands,
           (double)elapsed / (double)(threads * worlds * passes));
}
