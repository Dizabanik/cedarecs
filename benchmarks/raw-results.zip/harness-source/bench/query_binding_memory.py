"""Compare query-owned native allocations; does not measure total engine RAM."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--variant', required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
out = args.output.resolve()
out.mkdir(parents=True, exist_ok=False)
rows, commands, versions, binaries = [], [], {}, {}
for label, mode in [('kama-registry-v107', 0), (args.variant, 1)]:
    source = ROOT / 'variants' / label
    manifest = json.loads((source / 'provenance.json').read_text())
    for name, digest in manifest['cedarecs']['files'].items():
        assert hashlib.sha256((source / name).read_bytes()).hexdigest() == digest
    versions[label] = manifest['cedarecs']['snapshot_sha256']
    binary = out / label
    command = ['clang', '-std=c11', '-D_POSIX_C_SOURCE=200809L', '-D_DARWIN_C_SOURCE',
               '-pthread', '-O3', '-march=native', '-Wall', '-Wextra', '-Wpedantic', '-Werror',
               '-I' + str(source), '-DQUERY_BINDING_ARENA=' + str(mode),
               str(ROOT / 'bench/query_binding_memory.c'),
               *map(str, sorted((source / 'cedarecs/ecs').glob('*.c'))),
               str(source / 'cedarecs/wexds.c'), '-lm', '-o', str(binary)]
    subprocess.run(command, check=True)
    commands.append(command)
    binaries[label] = hashlib.sha256(binary.read_bytes()).hexdigest()
    for population in (128, 4097, 65536):
        result = subprocess.run([str(binary), str(population)], capture_output=True,
                                text=True, check=True)
        assert not result.stderr
        rows += [dict(variant=label, **json.loads(line)) for line in result.stdout.splitlines()]
keys = ['population', 'stage', 'fields', 'runs', 'rows']
before = {tuple(row[key] for key in keys): row for row in rows if row['variant'] == 'kama-registry-v107'}
after = {tuple(row[key] for key in keys): row for row in rows if row['variant'] == args.variant}
assert before.keys() == after.keys() and len(before) == 48
(out / 'raw.jsonl').write_text(''.join(json.dumps(row) + '\n' for row in rows))
with (out / 'summary.csv').open('w', newline='') as stream:
    writer = csv.DictWriter(stream, list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)
(out / 'workload.c').write_bytes((ROOT / 'bench/query_binding_memory.c').read_bytes())
(out / 'runner.py').write_bytes(Path(__file__).read_bytes())
(out / 'metadata.json').write_text(json.dumps(dict(
    versions=versions, binaries=binaries, commands=commands, checkpoints=len(rows),
    accounting='macOS malloc_size for allocations owned by four indexed queries. '
               'Includes query struct, ID/field arrays, batch capacity and column bindings. '
               'World storage, allocator metadata, RSS and physical footprint excluded. '
               'Assertions enabled; matching population/stage/fields/run/row counts required.',
), indent=2) + '\n')
print(f'{len(rows)} query-allocation checkpoints passed')
