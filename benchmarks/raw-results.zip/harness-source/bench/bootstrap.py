#!/usr/bin/env python3
"""Restore the exact upstream Flecs checkout used by this benchmark."""
import json
from pathlib import Path
import subprocess
ROOT = Path(__file__).resolve().parents[1]
source = json.loads((ROOT / "provenance.json").read_text())["flecs"]
target = ROOT / "flecs"
if target.exists():
    head = subprocess.check_output(["git", "-C", str(target), "rev-parse", "HEAD"], text=True).strip()
    if head != source["commit"]:
        raise SystemExit("Existing Flecs checkout differs from provenance.json; leaving it untouched")
else:
    subprocess.run(["git", "clone", "--no-checkout", "--filter=blob:none", source["url"], str(target)], check=True)
    subprocess.run(["git", "-C", str(target), "checkout", "--detach", source["commit"]], check=True)
print("Flecs pinned at", source["commit"])
