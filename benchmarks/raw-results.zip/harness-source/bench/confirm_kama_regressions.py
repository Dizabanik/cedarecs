"""Investigate every flagged case, without dropping the original measurements."""
import csv
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'validation/kama-refresh-v106'
manifest=[]
for suite in ('original','packed','indexed'):
    table=ROOT/'results'/('kama-v107-'+suite)/'summary.csv'
    flagged=[r['case'] for r in csv.DictReader(table.open()) if float(r['cedar_over_before'])>1.04]
    if not flagged:continue
    destination=ROOT/'results'/('kama-v107-'+suite+'-confirmation')
    command=[sys.executable,str(ROOT/'bench/compare_cedar.py'),'--suite',suite,
             '--control-label','initialized-bundles-v105','--binary-set',str(ROOT/'build/kama-v107-paired'),
             '--repeats','32','--balanced-layout','--target-ms','50',
             '--case-filter','^(?:'+'|'.join(re.escape(case) for case in flagged)+')$',
             '--output',str(destination)]
    print(f'Confirming {suite}: all {len(flagged)} previously flagged cases',flush=True)
    with (OUT/(suite+'-confirmation.log')).open('w') as log:
        result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
    # A performance gate failure is data, not permission to skip later cases.
    if not (destination/'summary.csv').is_file():raise RuntimeError((suite,result.returncode))
    rows=list(csv.DictReader((destination/'summary.csv').open()))
    assert {r['case'] for r in rows}==set(flagged)
    manifest.append(dict(suite=suite,flagged=flagged,command=command,exit_code=result.returncode,
        still_above_four_percent=[r for r in rows if float(r['candidate_over_baseline'])>1.04]))
(OUT/'confirmation.json').write_text(json.dumps(manifest,indent=2)+'\n')
