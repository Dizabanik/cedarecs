#!/usr/bin/env python3
"""Complete white-background benchmark poster and paginated comparison atlas."""
import csv
import hashlib
import json
import math
from pathlib import Path
import shutil
import sys
import textwrap
import zipfile

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.patches import Patch
from matplotlib.ticker import MaxNLocator
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'promotion/complete-comparison-v53'
TEXT='#26374d';MUTED='#58697d';PLOT='#e5ecf6'
COLORS={'cedar':'#33a02c','cedarecs':'#33a02c','cedar-packed':'#33a02c',
        'cedar-indexed':'#249f91','entt':'#0033cc','pico':'#ff9900','flecs':'#ff3300'}
NAMES={'cedar':'Cedar ECS','cedarecs':'Cedar ECS','cedar-packed':'Cedar packed',
       'cedar-indexed':'Cedar indexed','entt':'EnTT','pico':'pico_ecs','flecs':'Flecs'}
SHORT={'cedar':'Cedar','cedarecs':'Cedar','cedar-packed':'Cedar P',
       'cedar-indexed':'Cedar I','entt':'EnTT','pico':'pico','flecs':'Flecs'}
BASES=[('BM_CreateEmptyEntities','Create empty entities'),('BM_CreateEntities','Create with components'),
       ('BM_DestroyEntities','Destroy entities'),('BM_AddComponent','Add a component'),
       ('BM_RemoveAddComponent','Remove + add component'),('BM_UnpackNoComponent','Check absent component'),
       ('BM_UnpackOneComponent','Read one component'),('BM_UnpackTwoComponents','Read two components'),
       ('BM_UnpackThreeComponents','Read three components')]
ENTITY='multi-ecs-checked-final-v53'
ORIGINAL='checked-final-v53-original'
PACKED='checked-final-v53-packed'
INDEXED='checked-final-v53-slots'
MEMORY='memory-v1'
INPUTS=[];OUTPUTS=[];PLOTTED=[];PAGES=[]
plt.rcParams.update({'font.family':'DejaVu Sans','text.color':TEXT,'axes.labelcolor':TEXT,
                     'xtick.color':TEXT,'ytick.color':TEXT,'font.size':10,
                     'svg.fonttype':'none','pdf.fonttype':42})

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(run,name):
    p=ROOT/'results'/run/name
    if p not in INPUTS:INPUTS.append(p)
    if name.endswith('.csv'):return list(csv.DictReader(p.open()))
    if name.endswith('.jsonl'):return [json.loads(line) for line in p.read_text().splitlines()]
    return json.loads(p.read_text())
def number(v):
    if v==0:return '0'
    if abs(v)<.01:return f'{v:.2g}'
    if abs(v)<10:return f'{v:.2f}'
    if abs(v)<1000:return f'{v:.1f}'
    return f'{v:,.0f}'
def compact(n):return f'{n//1000000}M' if n and n%1000000==0 else (f'{n//1000}k' if n and n%1000==0 else f'{n:,}')
def title(fig,heading,subtitle,frameworks,legend_y=.925,big=False):
    fig.text(.065,.976 if big else .973,heading,fontsize=30 if big else 23,fontweight='bold',va='top')
    fig.text(.065,.953 if big else .945,subtitle,fontsize=12 if big else 10,color=MUTED,va='top')
    handles=[Patch(facecolor=COLORS[f],label=NAMES[f]) for f in frameworks]
    fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.5,legend_y),
               ncol=len(frameworks),frameon=False,fontsize=12 if big else 10,labelcolor=TEXT,columnspacing=2.2)
def footer(fig,lines,big=False):
    top=.054 if len(lines)==3 else .039
    for i,line in enumerate(lines):
        fig.text(.065,top-i*.014,line,fontsize=9.3 if big else 8.2,color=MUTED)
def draw(ax,card,small=False):
    ax.set_facecolor(PLOT);ax.grid(axis='y',color='white',lw=1.1);ax.set_axisbelow(True)
    for spine in ax.spines.values():spine.set_visible(False)
    fs=8 if small else 10
    ax.tick_params(length=0,pad=6,labelsize=fs)
    values=[s['median'] for s in card['series']]
    low=[s['p25'] for s in card['series']];high=[s['p75'] for s in card['series']]
    assert all(math.isfinite(v) for v in values+low+high)
    assert all(a<=b<=c for a,b,c in zip(low,values,high))
    bars=ax.bar(np.arange(len(values)),values,width=.62,
                color=[COLORS[s['framework']] for s in card['series']],
                yerr=[[v-a for v,a in zip(values,low)],[c-v for c,v in zip(high,values)]],
                error_kw={'elinewidth':.8,'capsize':2,'ecolor':TEXT})
    ax.bar_label(bars,labels=[number(v) for v in values],padding=5,fontsize=fs,color=TEXT)
    minval=min([0]+low);maxval=max([0]+high);span=maxval-minval
    if span==0:span=1
    ax.set_ylim(minval-(span*.13 if minval<0 else 0),maxval+span*.30)
    ax.yaxis.set_major_locator(MaxNLocator(nbins=3))
    ax.set_xticks(range(len(values)),[SHORT[s['framework']] for s in card['series']],fontsize=fs)
    ax.set_ylabel(card['unit'],fontsize=fs,labelpad=6)
    ax.set_title(card['title'],loc='left',fontsize=9 if small else 11,fontweight='bold',pad=13)
def series(framework,median,p25,p75,denominator=1):
    return dict(framework=framework,median=float(median)/denominator,
                p25=float(p25)/denominator,p75=float(p75)/denominator)

def entity_cards():
    meta=read(ENTITY,'metadata.json');assert meta['cedar_read_mode']=='checked' and meta['repeats']==9
    rows={r['benchmark']:r for r in read(ENTITY,'summary.csv')};raw=read(ENTITY,'raw.jsonl')
    order=[(base+'/'+str(n),label,n) for base,label in BASES for n in (1,1024,65536)]
    order.append(('BM_CreateNoEntities','Empty-world lifecycle',0))
    assert set(rows)=={x[0] for x in order} and len(rows)==28
    cards=[]
    for key,label,n in order:
        counts={int(r['entities']) for r in raw if r['name']==key};assert len(counts)==1
        count=counts.pop();denominator=max(1,count);r=rows[key]
        values=[series(f,r[f+'_cpu_median_ns'],r[f+'_cpu_p25_ns'],r[f+'_cpu_p75_ns'],denominator)
                for f in ('cedar','entt','pico','flecs')]
        cards.append(dict(dataset=ENTITY,key=key,metric='cpu_time',
                          title=label+'\n'+(f'Input {n:,} · {count:,} visited' if n else 'No entities · cost per world'),
                          unit='ns / visited entity' if count else 'ns / world',denominator=denominator,series=values))
    return cards

def native_cards(run,expanded=False):
    meta=read(run,'metadata.json');assert meta['repeats']==9
    rows=read(run,'summary.csv');assert len(rows)==(386 if expanded else 50)
    if expanded:
        assert len({r['case'] for r in rows})==386
        rows.sort(key=lambda r:(r['family'],r['scenario'],int(r['entities']),int(r['threads']),r['case']))
    else:rows.sort(key=lambda r:(r['scenario'],int(r['entities']),int(r['threads'])))
    cards=[]
    for r in rows:
        key=r['case'] if expanded else f"{r['scenario']}/entities={r['entities']},threads={r['threads']}"
        if expanded:
            scenario,params=key.split('/',1)
            caption=scenario+'\n'+'\n'.join(textwrap.wrap(params,width=47,break_long_words=False))
            unit='ns / '+r['unit']
        else:
            caption=r['scenario']+f"\nEntities {compact(int(r['entities']))} · threads {r['threads']}"
            unit='ns / operation'
        values=[series(f,r[f+'_median_ns'],r[f+'_p25_ns'],r[f+'_p75_ns']) for f in ('cedarecs','flecs')]
        cards.append(dict(dataset=run,key=key,metric='wall_time',title=caption,
                          unit=unit,denominator=1,series=values))
    return cards

def memory_cards():
    meta=read(MEMORY,'metadata.json');assert meta['repeats']==5 and not meta['smoke']
    rows=read(MEMORY,'summary.csv');assert len(rows)==815
    groups={}
    for r in rows:groups.setdefault((r['scenario'],int(r['entities']),int(r['step']),r['phase']),{})[r['framework']]=r
    assert len(groups)==163 and all(len(g)==5 for g in groups.values())
    cards=[]
    frameworks=('cedar-packed','cedar-indexed','entt','pico','flecs')
    # Every checkpoint is shown for both primary memory measures, including
    # registration, baseline, all four regrowths, and world destruction.
    for (scenario,n,step,phase),group in sorted(groups.items()):
        for metric,label in [('malloc_in_use_delta','Live heap'),('footprint_delta','Physical footprint')]:
            values=[series(f,group[f][metric+'_median'],group[f][metric+'_p25'],group[f][metric+'_p75'],1048576) for f in frameworks]
            key=f'{scenario}/entities={n},step={step},phase={phase}'
            cards.append(dict(dataset=MEMORY,key=key,metric=metric,
                              title=f'{scenario} · {n:,} initial entities\nStep {step}: {phase} · {label}',
                              unit='MiB above baseline',denominator=1048576,series=values))
    return cards

def remember(card):
    for s in card['series']:
        PLOTTED.append(dict(dataset=card['dataset'],case=card['key'],metric=card['metric'],
                            unit=card['unit'],normalization_denominator=card['denominator'],**s))

def poster(cards,filename,heading,subtitle,frameworks,columns=3,rows=None):
    rows=rows or math.ceil(len(cards)/columns)
    fig,axes=plt.subplots(rows,columns,figsize=(18.7,rows*2.95+2.6),facecolor='white')
    fig.subplots_adjust(left=.065,right=.976,bottom=.079,top=.884,hspace=.68,wspace=.29)
    title(fig,heading,subtitle,frameworks,legend_y=.935,big=True)
    for ax,card in zip(axes.flat,cards):draw(ax,card)
    for ax in list(axes.flat)[len(cards):]:ax.axis('off')
    if len(cards)==28 and rows*columns==30:
        ax=axes.flat[-2];ax.axis('off')
        ax.text(0,.95,'83 / 84 median matchups won',fontsize=17,fontweight='bold',color=COLORS['cedar'],va='top',transform=ax.transAxes)
        ax.text(0,.57,'Cedar vs EnTT: 27 / 28\nCedar vs pico_ecs: 28 / 28\nCedar vs Flecs: 28 / 28',fontsize=11,color=TEXT,linespacing=1.55,va='top',transform=ax.transAxes)
        ax=axes.flat[-1];ax.axis('off')
        ax.text(0,.95,'All sizes. Every entity case.',fontsize=16,fontweight='bold',va='top',transform=ax.transAxes)
        ax.text(0,.60,'CPU-time medians; lower is faster.\nZero-origin linear axes per panel.\nWhiskers: observed IQR.\n\nFull atlas includes the C and memory suites.',fontsize=10,color=MUTED,linespacing=1.3,va='top',transform=ax.transAxes)
    footer(fig,['Checked indexed Cedar v53 · 9 independent process rounds / 30 ms · Apple M4 Pro / macOS · pinned EnTT 3.13.2 / pico_ecs / Flecs 4.0.1.',
                'Every retained entity case is shown. Medians are divided by actual visited-entity counters; empty-world cost uses ns/world. Each panel has its own zero-origin scale.',
                'Native timing boundaries include teardown. Per-addition timer pause/resume dominates that case; observed IQRs overlap in three pico additions. One-host comparison.'],big=True)
    for ext in ('png','svg','pdf'):
        p=OUT/(filename+'.'+ext);fig.savefig(p,dpi=180,facecolor='white');OUTPUTS.append(p)
    plt.close(fig)

def page(pdf,cards,heading,subtitle,frameworks,footnotes,page_number):
    fig,axes=plt.subplots(4,3,figsize=(15.4,18),facecolor='white')
    fig.subplots_adjust(left=.073,right=.975,bottom=.085,top=.873,hspace=.90,wspace=.32)
    title(fig,heading,subtitle,frameworks,legend_y=.922)
    for ax,card in zip(axes.flat,cards):draw(ax,card,small=True);remember(card)
    for ax in list(axes.flat)[len(cards):]:ax.axis('off')
    footer(fig,footnotes)
    fig.text(.97,.015,str(page_number),fontsize=9,color=MUTED,ha='right')
    pdf.savefig(fig,facecolor='white')
    PAGES.append(dict(page=page_number,section=heading,
                      plots=[dict(dataset=c['dataset'],case=c['key'],metric=c['metric']) for c in cards]))
    if page_number in (2,10,43,76,100):
        p=OUT/f'atlas-preview-page-{page_number}.png';fig.savefig(p,dpi=100,facecolor='white');OUTPUTS.append(p)
    plt.close(fig)

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    entities=entity_cards();original=native_cards(ORIGINAL);packed=native_cards(PACKED,True)
    indexed=native_cards(INDEXED,True);memory=memory_cards()
    assert len(entities)+len(original)+len(packed)+len(indexed)==850
    poster(entities,'comparison-all-entity-cases','Complete Entity Component System comparison',
           'All 28 configurations · all three input sizes · empty-world lifecycle included · lower is faster',
           ('cedar','entt','pico','flecs'),columns=3,rows=10)
    print('Rendered all 28 entity cases to large PNG/SVG/PDF poster.',flush=True)
    if '--poster-only' in sys.argv:
        path=OUT/'coverage-and-provenance.json';manifest=json.loads(path.read_text())
        for name,h in manifest['source_inputs'].items():assert sha(ROOT/name)==h
        for p in OUTPUTS:manifest['outputs'][p.name]=sha(p)
        manifest['script_sha256']=sha(Path(__file__))
        path.write_text(json.dumps(manifest,indent=2)+'\n')
        shutil.copy2(Path(__file__),OUT/'plot-source.py')
        bundle=OUT/'complete-comparison.zip'
        with zipfile.ZipFile(bundle,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as archive:
            for p in sorted(OUT.iterdir()):
                if p.is_file() and p!=bundle:archive.write(p,arcname='complete-comparison/'+p.name)
        with zipfile.ZipFile(bundle) as archive:assert archive.testzip() is None
        print('Refreshed poster and verified atlas bundle; retained PDF pages unchanged.',flush=True)
        return
    atlas=OUT/'complete-benchmark-atlas.pdf'
    with PdfPages(atlas,metadata={'Title':'Complete Cedar ECS benchmark comparison',
                                 'Author':'Cedar ECS benchmark workspace',
                                 'Subject':'850 timing configurations and every memory checkpoint; retained checked v53 results'}) as pdf:
        fig=plt.figure(figsize=(15.4,18),facecolor='white')
        fig.text(.08,.91,'Complete ECS\nbenchmark comparison',fontsize=37,fontweight='bold',linespacing=1.25)
        fig.text(.08,.78,'850 timing configurations. Every retained memory checkpoint.',fontsize=18,color=MUTED)
        sections=[('Entity integration',28,3),('Original C suite',50,5),('Expanded packed C',386,33),('Expanded indexed C',386,33),('Memory: heap + footprint',326,28)]
        first=2
        for i,(name,n,count) in enumerate(sections):
            y=.68-i*.075
            fig.text(.08,y,name,fontsize=19,fontweight='bold')
            fig.text(.67,y,f'{n} plots · pages {first}–{first+count-1}',fontsize=15,color=MUTED)
            first+=count
        notes=['All figures use the retained final checked-v53 datasets; no new performance measurements.',
               'Entity comparisons use CPU-time medians; C comparisons use wall-time medians.',
               'Memory reports signed changes from the pre-world baseline in MiB, separately for heap and footprint.',
               'Zero-origin linear axes per panel; scales vary between panels. Whiskers show observed IQR.',
               'Each storage policy remains fixed; native framework versions and timing boundaries differ.',
               'Memory baseline, registration, every mutation/regrowth and world destruction are all included.',
               'Apple M4 Pro / macOS ARM64. These workloads do not establish a universal ECS ranking.']
        for i,line in enumerate(notes):fig.text(.08,.245-i*.022,line,fontsize=11,color=MUTED)
        pdf.savefig(fig);plt.close(fig)
        page_number=2
        for cards,heading,subtitle,frameworks,footnotes in [
            (entities,'Entity integration · complete set','28 cases · every input size and empty-world lifecycle · 9 rounds / 30 ms',
             ('cedar','entt','pico','flecs'),
             ['Checked indexed Cedar v53 · EnTT 3.13.2 / pinned pico_ecs / Flecs 4.0.1 · CPU medians / actual visited entities; empty world uses ns/world.',
              'Native timing includes teardown; per-addition timer pause/resume dominates that case. Zero-origin axes; individual panel scales and units differ.',
              'Whiskers are observed IQR, not confidence intervals. Apple M4 Pro / macOS. No best-case or best-policy substitution.']),
            (original,'Original C suite · complete set','50 configurations · all sizes and thread counts · 9 paired rounds',
             ('cedarecs','flecs'),
             ['Cedar v53 vs pinned Flecs development revision · wall-time medians per operation · all original sizes and thread counts.',
              'Original Cedar frame adapter uniformly uses automatic batching. Shared workloads, kernels, updates and checksums remain fixed.',
              'Operation definitions differ by scenario. Every panel starts at zero; scales differ. Whiskers show observed IQR. One Apple M4 Pro / macOS host.']),
            (packed,'Expanded C · packed Cedar','386 configurations · all families and parameters · 9 paired rounds',
             ('cedarecs','flecs'),
             ['Fixed packed Cedar policy vs pinned Flecs development revision · wall-time medians · every expanded case, including losses.',
              'Every explicit grain and the common workload/kernel remain unchanged. Per-panel labels show full case parameters and operation units.',
              'Zero-origin linear axes; individual scales differ. Whiskers show observed IQR. Apple M4 Pro / macOS.']),
            (indexed,'Expanded C · indexed Cedar','386 configurations · all families and parameters · 9 paired rounds',
             ('cedarecs','flecs'),
             ['Fixed indexed Cedar policy vs pinned Flecs development revision · wall-time medians · no best-of-policy selection.',
              'Every explicit grain and the common workload/kernel remain unchanged. Per-panel labels show full case parameters and operation units.',
              'Zero-origin linear axes; individual scales differ. Whiskers show observed IQR. Indexed storage has slot-capacity memory costs.']),
            (memory,'Memory · every checkpoint','34 configurations · 163 checkpoints × 2 metrics · 850 fresh Release processes · 5 repetitions',
             ('cedar-packed','cedar-indexed','entt','pico','flecs'),
             ['Both primary metrics at every checkpoint, including baseline and all four regrowths. Cumulative slot/allocator capacity is retained naturally.',
              'Signed MiB deltas from pre-world baseline; harness buffers are prefaulted first. No explicit shrink, reserve or allocator purge.',
              'Heap allocations and physical footprint are different measures. No sanitized memory figures are used. Whiskers show observed IQR.'])]:
            for start in range(0,len(cards),12):
                page(pdf,cards[start:start+12],heading,subtitle,frameworks,footnotes,page_number)
                page_number+=1
            print(f'Rendered {heading}: {len(cards)} plots.',flush=True)
        assert page_number==104
    OUTPUTS.append(atlas)
    expected={(c['dataset'],c['key'],c['metric'],s['framework']) for cards in (entities,original,packed,indexed,memory) for c in cards for s in c['series']}
    actual=[(r['dataset'],r['case'],r['metric'],r['framework']) for r in PLOTTED]
    assert set(actual)==expected and len(actual)==len(expected)==3386
    csv_path=OUT/'all-plotted-values.csv'
    with csv_path.open('w',newline='') as out:
        writer=csv.DictWriter(out,list(PLOTTED[0]));writer.writeheader();writer.writerows(PLOTTED)
    OUTPUTS.append(csv_path)
    manifest=dict(cedar_snapshot=read(ENTITY,'metadata.json')['cedar']['snapshot_sha256'],
                  source_inputs={str(p.relative_to(ROOT)):sha(p) for p in INPUTS},
                  outputs={p.name:sha(p) for p in OUTPUTS},script_sha256=sha(Path(__file__)),
                  coverage=dict(entity_configurations=28,original_C_configurations=50,packed_C_configurations=386,indexed_C_configurations=386,
                                total_timing_configurations=850,memory_configurations=34,memory_checkpoints=163,memory_metrics_per_checkpoint=2,
                                timing_bar_series=1756,memory_bar_series=1630,total_bar_series=3386,atlas_pages=103),
                  pages=PAGES,limits='All cases of the final v53 datasets, with fixed policies, including losses. Historical optimization probes and correctness/sanitizer smokes are excluded from performance charts. Primary memory metrics are shown at every checkpoint; reservation, RSS and process peak measures remain in the complete source CSV.')
    (OUT/'coverage-and-provenance.json').write_text(json.dumps(manifest,indent=2)+'\n')
    shutil.copy2(Path(__file__),OUT/'plot-source.py')
    (OUT/'README.md').write_text('''# Complete white-background benchmark comparison

- [All 28 entity configurations](comparison-all-entity-cases.png): a large poster
  in the previous comparison style, exported as PNG, SVG and PDF. Includes all
  three input sizes, the empty-world case and the single EnTT loss.
- [Complete benchmark atlas](complete-benchmark-atlas.pdf): 103 vector pages.
  Covers every one of the 850 timing configurations plus every memory
  checkpoint for both live heap and macOS physical footprint.

| Section | PDF pages | Coverage |
| --- | --- | --- |
| Contents and methodology | 1 | Timing/memory definitions and limits |
| Entity integration | 2–4 | All 28 cases; Cedar, EnTT, pico_ecs, Flecs |
| Original C | 5–9 | All 50 configurations; Cedar vs Flecs |
| Expanded packed C | 10–42 | All 386 configurations, fixed policy |
| Expanded indexed C | 43–75 | All 386 configurations, fixed policy |
| Memory | 76–103 | All 163 checkpoints × heap/footprint; five backends |

Every bar shows a retained median with observed IQR. Timing axes start at zero;
scales differ per panel. Entity CPU medians are normalized by the actual visited
entity count, and the empty-world test is ns/world. C wall-time medians retain
each scenario's operation definition. Memory deltas can be signed and include
baseline, registration, population, deletion/removal, every regrowth and world
destruction. Native timing boundaries, features and dependency pins differ.

[Every plotted value](all-plotted-values.csv) and [coverage and input/output
hashes](coverage-and-provenance.json) allow auditing the 3,386 bar series.
The remaining raw memory metrics (reservation, RSS, allocation count,
compression and process peaks) are in the [source CSV](../../results/memory-v1/summary.csv).
Historical optimization probes and sanitizer smokes are retained separately
and are excluded from these final performance comparisons.

Reproduce from the retained results:

```sh
testing/build/plot-env/bin/python testing/bench/comparison_complete.py
```
''')
    bundle=OUT/'complete-comparison.zip'
    with zipfile.ZipFile(bundle,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as archive:
        for p in sorted(OUT.iterdir()):
            if p.is_file() and p!=bundle:archive.write(p,arcname='complete-comparison/'+p.name)
    with zipfile.ZipFile(bundle) as archive:assert archive.testzip() is None
    print(f'Exported complete poster, 103-page atlas, all 3,386 plotted values and verified ZIP: {OUT}',flush=True)

if __name__=='__main__':main()
