#!/usr/bin/env python3
"""White grouped-bar comparisons inspired by the cloned ecs_benchmark plots."""
import csv
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.ticker import MaxNLocator
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'results/multi-ecs-checked-final-v53'
OUT=ROOT/'promotion/white-comparison-v53'
REFERENCE=ROOT/'build/references/ecs_benchmark'
FRAMEWORKS=('cedar','entt','pico','flecs')
NAMES={'cedar':'Cedar ECS','entt':'EnTT','pico':'pico_ecs','flecs':'Flecs'}
COLORS={'cedar':'#33a02c','entt':'#0033cc','pico':'#ff9900','flecs':'#ff3300'}
TEXT='#26374d';MUTED='#58697d';PLOT='#e5ecf6'
CASES=[('BM_CreateEmptyEntities','Create empty\nentities'),
       ('BM_CreateEntities','Create with\ncomponents'),
       ('BM_DestroyEntities','Destroy\nentities'),
       ('BM_AddComponent','Add a\ncomponent'),
       ('BM_RemoveAddComponent','Remove + add\ncomponent'),
       ('BM_UnpackNoComponent','Check absent\ncomponent'),
       ('BM_UnpackOneComponent','Read one\ncomponent'),
       ('BM_UnpackTwoComponents','Read two\ncomponents'),
       ('BM_UnpackThreeComponents','Read three\ncomponents')]

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(fig,stem):
    for ext in ('png','svg','pdf'):
        p=OUT/(stem+'.'+ext);fig.savefig(p,dpi=200,facecolor='white');outputs.append(p)
    plt.close(fig)
def style(ax):
    ax.set_facecolor(PLOT);ax.grid(axis='y',color='white',linewidth=1.2)
    ax.set_axisbelow(True);ax.tick_params(length=0,labelcolor=TEXT,pad=9)
    for spine in ax.spines.values():spine.set_visible(False)
def legend(fig,y):
    handles=[Patch(facecolor=COLORS[f],label=NAMES[f]) for f in FRAMEWORKS]
    fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.5,y),ncol=4,
               frameon=False,fontsize=12,labelcolor=TEXT,handlelength=1.3,columnspacing=2.6)

OUT.mkdir(parents=True,exist_ok=True)
meta=json.loads((RUN/'metadata.json').read_text())
assert meta['cedar_read_mode']=='checked' and meta['repeats']==9 and meta['configurations']==28
all_rows=list(csv.DictReader((RUN/'summary.csv').open()))
rows={r['benchmark']:r for r in all_rows}
raw=[json.loads(line) for line in (RUN/'raw.jsonl').read_text().splitlines()]
data=[]
for base,label in CASES:
    case=base+'/65536';r=rows[case]
    counts={int(s['entities']) for s in raw if s['name']==case}
    assert len(counts)==1
    count=counts.pop();assert count==(32768 if base=='BM_UnpackThreeComponents' else 65536)
    for f in FRAMEWORKS:
        samples=[s['cpu_time'] for s in raw if s['name']==case and s['framework']==f]
        assert len(samples)==9
        median=float(r[f+'_cpu_median_ns'])
        data.append(dict(case=case,label=label.replace('\n',' '),framework=f,
                         reported_entities=count,cpu_median_ns=median,
                         relative_time=median/float(r['cedar_cpu_median_ns']),
                         ns_per_visited_entity=median/count,
                         p25_ns_per_entity=float(r[f+'_cpu_p25_ns'])/count,
                         p75_ns_per_entity=float(r[f+'_cpu_p75_ns'])/count))
outputs=[]
plt.rcParams.update({'font.family':'DejaVu Sans','text.color':TEXT,'axes.labelcolor':TEXT,
                     'font.size':11,'svg.fonttype':'none','pdf.fonttype':42})

# Compact comparison: the same zero-origin linear axis for all 36 bars.
fig=plt.figure(figsize=(14.5,8.2),facecolor='white')
fig.text(.063,.929,'Entity Component System comparison',fontsize=26,fontweight='bold')
fig.text(.063,.879,'Cedar ECS vs EnTT, pico_ecs and Flecs  ·  65,536-input configurations',fontsize=12,color=MUTED)
legend(fig,.839)
ax=fig.add_axes([.076,.266,.897,.484]);style(ax)
x=np.arange(len(CASES));width=.19
for i,f in enumerate(FRAMEWORKS):
    values=[next(d['relative_time'] for d in data if d['case']==base+'/65536' and d['framework']==f) for base,_ in CASES]
    bars=ax.bar(x+(i-1.5)*width,values,width*.94,color=COLORS[f],zorder=3)
    labels=[f'{v:.3f}×' if 1<v<1.01 else (f'{v:.2f}×' if v<1.05 and v!=1 else f'{v:.1f}×') for v in values]
    ax.bar_label(bars,labels=labels,padding=4,fontsize=8,color=TEXT,rotation=90)
ax.axhline(1,color=COLORS['cedar'],ls='--',linewidth=1,alpha=.7,zorder=2)
ax.set_xticks(x,[label for _,label in CASES],fontsize=10)
ax.set_xlim(-.65,len(CASES)-.35);ax.set_ylim(0,17.5)
ax.set_yticks([0,1,4,8,12,16],['0','1×','4×','8×','12×','16×'])
ax.set_ylabel('Relative CPU time (Cedar = 1×)\nLower is faster',fontsize=11,labelpad=14)
fig.text(.076,.145,'Every operation at the largest retained input setting. Bars share a linear scale starting at zero; 1× is Cedar’s time.',fontsize=10,color=MUTED)
fig.text(.076,.112,'9 independent process rounds · checked indexed Cedar v53 · Apple M4 Pro / macOS · native factory timing boundaries.',fontsize=9.5,color=MUTED)
fig.text(.076,.079,'Includes teardown; addition timing is dominated by timer pause/resume. Three-component reads visit 32,768 entities at this input.',fontsize=9,color=MUTED)
fig.text(.076,.046,'Other sizes and the empty-world case remain in the complete 28-case dataset. EnTT 3.13.2 / pinned pico_ecs / Flecs 4.0.1.',fontsize=9,color=MUTED)
save(fig,'comparison')

# Absolute cost follows the upstream per-entity convention. Each panel starts at zero.
fig,axes=plt.subplots(3,3,figsize=(13.3,11.2),facecolor='white')
fig.subplots_adjust(left=.075,right=.975,bottom=.184,top=.80,hspace=.56,wspace=.30)
fig.text(.075,.946,'Entity Component System comparison',fontsize=25,fontweight='bold')
fig.text(.075,.906,'Absolute CPU time per visited entity  ·  lower is faster  ·  all nine operations at the largest retained input',fontsize=11.5,color=MUTED)
legend(fig,.873)
for ax,(base,label) in zip(axes.flat,CASES):
    style(ax)
    group=[next(d for d in data if d['case']==base+'/65536' and d['framework']==f) for f in FRAMEWORKS]
    values=[d['ns_per_visited_entity'] for d in group]
    qlo=[d['p25_ns_per_entity'] for d in group];qhi=[d['p75_ns_per_entity'] for d in group]
    bars=ax.bar(np.arange(4),values,width=.62,color=[COLORS[f] for f in FRAMEWORKS],
                yerr=[[v-q for v,q in zip(values,qlo)],[q-v for v,q in zip(values,qhi)]],
                error_kw={'elinewidth':.8,'capsize':2,'ecolor':TEXT})
    ax.bar_label(bars,labels=[f'{v:.2f}' if v<10 else f'{v:.1f}' for v in values],padding=5,fontsize=9,color=TEXT)
    ax.set_title(label.replace('\n',' '),loc='left',fontsize=12,pad=13,fontweight='bold')
    ax.set_xticks(range(4),['Cedar','EnTT','pico','Flecs'],fontsize=9)
    ax.set_ylim(0,max(qhi)*1.30);ax.yaxis.set_major_locator(MaxNLocator(nbins=4))
    ax.set_ylabel('ns / entity',fontsize=9,labelpad=7)
fig.text(.075,.116,'Zero-origin linear axes; scales differ between panels. Whiskers show the observed IQR across nine independent process rounds.',fontsize=9.3,color=MUTED)
fig.text(.075,.088,'65,536-input configurations; three-component reads visit 32,768 entities. CPU medians are divided by the matching raw entity counter.',fontsize=9.3,color=MUTED)
fig.text(.075,.060,'Checked indexed Cedar v53 · Apple M4 Pro / macOS · includes native teardown; per-addition timer pause/resume dominates that case.',fontsize=9.1,color=MUTED)
fig.text(.075,.032,'EnTT 3.13.2 / pinned pico_ecs / Flecs 4.0.1. Source: retained checked-final-v53 results; no new timings or engine changes.',fontsize=9.1,color=MUTED)
save(fig,'comparison-times')

p=OUT/'plotted-values.csv'
with p.open('w',newline='') as out:
    writer=csv.DictWriter(out,list(data[0]));writer.writeheader();writer.writerows(data)
outputs.append(p)
inputs=[RUN/'summary.csv',RUN/'raw.jsonl',RUN/'metadata.json']
manifest=dict(cedar_snapshot=meta['cedar']['snapshot_sha256'],
              inputs={str(p.relative_to(ROOT)):sha(p) for p in inputs},
              style_reference={str(p.relative_to(ROOT)):sha(p) for p in
                               [REFERENCE/'img/CreateEntities.svg',REFERENCE/'scripts/gen-benchmark-report/gen_benchmark_report/core.py']},
              outputs={p.name:sha(p) for p in outputs},script_sha256=sha(Path(__file__)),
              scope='All nine entity operations at /65536. Normalized plot uses CPU median / Cedar CPU median. Absolute plot uses CPU median / actual visited entities from raw counters. No result selection within a case; original 28-case dataset retained separately. Linear zero-origin bars; per-panel scales labeled in absolute view.')
(OUT/'provenance.json').write_text(json.dumps(manifest,indent=2)+'\n')
(OUT/'README.md').write_text('''# White-background ECS comparisons

Inspired by the grouped bars, colors and pale plotting area in the cloned
abeimler/ecs_benchmark charts. Uses our retained checked-final-v53 results.

- [Compact comparison](comparison.png): all nine operations at the /65536 input,
  relative CPU time with Cedar = 1×. The common linear axis starts at zero.
- [Absolute timing comparison](comparison-times.png): the same nine operations,
  CPU nanoseconds per visited entity; each panel starts at zero and shows IQR.

Both are exported to PNG, SVG and PDF. Green denotes Cedar, blue EnTT,
orange pico_ecs and red Flecs. The input is 65,536 for every case; the upstream
three-component workload actually visits 32,768 entities. The absolute figure
uses that actual raw counter, not the input argument, as its denominator.
Includes native teardown and timer-dominated additions. The /1, /1024 and
empty-world results remain in the [complete entity matrix](../checked-v53/cedar-all-entity-cases.png).

[Plotted values](plotted-values.csv) and [input/output hashes](provenance.json)
make both figures auditable. Regenerate with:

```sh
testing/build/plot-env/bin/python testing/bench/comparison_white.py
```
''')
print('Exported white comparisons as PNG/SVG/PDF:',OUT)
