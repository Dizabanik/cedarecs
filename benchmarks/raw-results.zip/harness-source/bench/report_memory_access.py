#!/usr/bin/env python3
"""Report the retained v42 candidate, including losses and rejected experiments."""
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / 'results'
ENTITY = 'multi-ecs-memory-access-v42'
PACKED = 'memory-access-v42-packed'
INDEXED = 'memory-access-v42-slots'


def rows(run):
    return list(csv.DictReader((RESULTS / run / 'summary.csv').open()))


def stats(data, competitor, cedar='cedar', entity=True):
    suffix = '_cpu_' if entity else '_'
    key = lambda framework, statistic: framework + suffix + statistic + '_ns'
    wins = sum(float(r[key(cedar, 'median')]) < float(r[key(competitor, 'median')]) for r in data)
    ahead = sum(float(r[key(cedar, 'p75')]) < float(r[key(competitor, 'p25')]) for r in data)
    behind = sum(float(r[key(competitor, 'p75')]) < float(r[key(cedar, 'p25')]) for r in data)
    return wins, ahead, behind, len(data) - ahead - behind


def main():
    entity = rows(ENTITY)
    old_entity = rows('multi-ecs-indexed-initialized-v24')
    packed, indexed = rows(PACKED), rows(INDEXED)
    old_packed = {r['case']: r for r in rows('indexed-v25-packed')}
    focused = {r['case']: r for r in rows('owner-v37-creation')}
    raw = [json.loads(s) for s in (RESULTS / ENTITY / 'raw.jsonl').read_text().splitlines()]
    counts = {r['name']: r.get('entities', 0) for r in raw}
    text = [
        '# Memory initialization and prepared access (v42)', '',
        'This iteration improves component initialization, small overlapping copies, and prepared mutable access. All final entity reads are checked. The requested 90% win rate against every competitor is **not established**; the complete results below include losses and overlapping measurements.', '',
        'Measurements are from one Apple M4 Pro/macOS host. The four-framework integration covers the upstream entity suite at populations 1, 1,024 and 65,536, plus empty-world teardown. It does not cover every ECS framework or their full application/system suites. Versions remain pinned to the existing compatible adapters, not necessarily current releases.', '',
        '## Checked four-framework results', '',
        'Nine independent process rounds per framework, a 30 ms minimum Google Benchmark target, 28 shared cases, and 1,008 retained samples. Framework order rotates. Lower CPU-time medians count as wins; no best-of-variant result is substituted.', '',
        '| Competitor | Previous checked v24 | Current checked v42 | Cedar disjoint IQR | Competitor disjoint IQR | Overlap |',
        '| --- | ---: | ---: | ---: | ---: | ---: |',
    ]
    for f in ('entt', 'pico', 'flecs'):
        w, ahead, behind, overlap = stats(entity, f)
        old = stats(old_entity, f)[0]
        text.append(f'| {f} | {old}/28 | {w}/28 ({100*w/28:.1f}%) | {ahead} | {behind} | {overlap} |')
    text += ['', 'IQR separation describes observed spread, not a significance test. The addition benchmark pauses/resumes its timer inside each entity loop; timer overhead dominates it, so very close medians there are not precise insertion-cost evidence.', '',
             'Cedar validates bounds, presence and the full 64-bit generational handle. pico_ecs retains its native Release getter, whose assertions compile out and which directly computes a component-slot address. Native competitors and upstream templates are unchanged. The separately available known-live Cedar executable is tested for correctness but is **not used in this final comparison**.', '',
             '### Current entity cases Cedar loses', '',
             '| Competitor | Case | Cedar / competitor median | IQRs overlap |',
             '| --- | --- | ---: | --- |']
    for f in ('entt', 'pico', 'flecs'):
        for r in entity:
            a, b = float(r['cedar_cpu_median_ns']), float(r[f+'_cpu_median_ns'])
            if a >= b:
                overlap = not (float(r['cedar_cpu_p75_ns']) < float(r[f+'_cpu_p25_ns']) or float(r[f+'_cpu_p75_ns']) < float(r['cedar_cpu_p25_ns']))
                text.append(f"| {f} | {r['benchmark']} | {a/b:.3f} | {'yes' if overlap else 'no'} |")
    text += ['', '### Entity access at requested population 1,024', '',
             'CPU ns per actually iterated entity. The three-component template creates 1,024 entities but iterates 512; normalization uses the retained upstream counter. Creation/destruction include upstream teardown and are not interchangeable with the C suite.', '',
             '| Case | Cedar | EnTT | pico_ecs | Flecs |', '| --- | ---: | ---: | ---: | ---: |']
    for r in entity:
        if r['benchmark'].endswith('/1024'):
            n = counts[r['benchmark']]
            text.append('| '+r['benchmark'].removesuffix('/1024')+' | '+' | '.join(f"{float(r[f+'_cpu_median_ns'])/n:.3f}" for f in ('cedar','entt','pico','flecs'))+' |')
    text += ['', '## Complete C comparisons', '',
             'Each storage policy is fixed for the whole run. The common C workloads, case catalog, driver, shared kernels, and Flecs adapter are fixed. Both policies use checked access. The packed Cedar adapter now binds the public mutable accessor once per world, for every random read/write and setup access; indexed mode keeps its prepared indexed readers. This adapter change is included in the archived sources.', '',
             '| Dataset / policy | Cases | Cedar lower median | Cedar disjoint IQR | Flecs disjoint IQR | Overlap |',
             '| --- | ---: | ---: | ---: | ---: | ---: |']
    for label, run in [('Previous packed v25', 'indexed-v25-packed'), ('Current packed default', PACKED), ('Current indexed', INDEXED), ('Original frozen suite', 'memory-access-v42-original')]:
        data = rows(run)
        w, ahead, behind, overlap = stats(data, 'flecs', 'cedarecs', False)
        text.append(f'| {label} | {len(data)} | {w} ({100*w/len(data):.1f}%) | {ahead} | {behind} | {overlap} |')
    text += ['', '![All 386 packed cases, before and after](results/memory-access-v42-packed/before-after.png)', '',
             '### Selected lifecycle effects', '',
             'These explain the initialization changes, not the overall score. The complete matrix above and raw files include every other case. Before is the v37 focused control; after is the final complete v42 packed run. All values are median ns/op.', '',
             '| Case | v37 Cedar | v42 Cedar | Paired Flecs | Cedar speedup |',
             '| --- | ---: | ---: | ---: | ---: |']
    selected = [
        'create/entities=100000,threads=1,width=32',
        'create/entities=100000,threads=1,width=32,reserve=1',
        'create/entities=100000,threads=1,width=8,reserve=1',
        'create_incremental/entities=100000,threads=1,width=32',
        'recycle/entities=10000,threads=1,width=8',
        'recycle/entities=10000,threads=1,width=8,bytes=256,shuffled=1',
    ]
    current = {r['case']: r for r in packed}
    for name in selected:
        a, b = float(focused[name]['cedarecs_median_ns']), float(current[name]['cedarecs_median_ns'])
        text.append(f"| {name} | {a:.3f} | {b:.3f} | {float(current[name]['flecs_median_ns']):.3f} | {a/b:.2f}x |")
    text += ['', 'The `reserve=1` C workload performs equal spawn/delete warmup for both engines; it is not an allocation-only reserve. Reused rows can contain old data and still require clearing. This differs from fresh capacity and explains why some warm cases remain slower.', '',
             '### Packed results by family', '',
             '| Family | Cedar lower median | Cases |', '| --- | ---: | ---: |']
    for family in dict.fromkeys(r['family'] for r in packed):
        group = [r for r in packed if r['family'] == family]
        text.append(f"| {family} | {stats(group,'flecs','cedarecs',False)[0]} | {len(group)} |")
    text += ['', '### Regressions against the previous packed run', '',
             'Largest increases in Cedar median ns/op are shown below. These are separate runs, so both paired Flecs medians are included; changes cannot all be attributed to one implementation detail. The original 50-case median-win count also fell from 46 to 42; its eight current losses are within 2.2% of Flecs and six have overlapping IQRs. Lifecycle gains do not erase those results.', '',
             '| Case | Previous Cedar | Current Cedar | Previous Flecs | Current Flecs | Cedar current / previous |',
             '| --- | ---: | ---: | ---: | ---: | ---: |']
    regressions = sorted(packed, key=lambda r: float(r['cedarecs_median_ns'])/float(old_packed[r['case']]['cedarecs_median_ns']), reverse=True)
    for r in regressions[:10]:
        old = old_packed[r['case']]
        factor = float(r['cedarecs_median_ns'])/float(old['cedarecs_median_ns'])
        text.append(f"| {r['case']} | {float(old['cedarecs_median_ns']):.3f} | {float(r['cedarecs_median_ns']):.3f} | {float(old['flecs_median_ns']):.3f} | {float(r['flecs_median_ns']):.3f} | {factor:.2f}x |")
    text += ['', '## Retained implementation', '',
             '- Packed column growth zeroes unused capacity in bulk. A high-water boundary records rows that may contain prior data. Untouched zero rows can be exposed directly; recycled rows are cleared. Initialized spawning writes provided values and keeps omitted values zero.',
             '- Homogeneous signatures resolve their zeroing width once per row. Mixed signatures, tags, arbitrary widths and over-aligned storage keep the general path.',
             '- Small copies snapshot the complete source before storing, preserving memmove semantics for overlaps. Guarded Clang inline copy/zero builtins prevent small operations from being merged into out-of-line library calls. Other compilers use ordinary C library operations; `CEDARECS_PORTABLE_MEMORY` exercises that path. See the [Clang memory builtin contract](https://clang.llvm.org/docs/LanguageExtensions.html#memory-builtins).',
             '- `ced_Access access = ced_access(world)` and `ced_access_get(&access, entity, component)` expose checked mutable prepared access without const casts. It follows storage growth, rejects stale/absent handles, and keeps ordinary owner/disjoint-worker synchronization and pointer lifetime rules. It does not open a mutation scope.',
             '- Indexed presence stores the complete 64-bit owner handle. UINT64_MAX is unambiguous because entity index UINT32_MAX is never allocated. This removes the final-generation overflow slow path, while retaining all generation bits. It adds four bytes per allocated component slot compared with v25; smaller column metadata does not offset that cost in large worlds.',
             '- Metadata accessors carry pure/nothrow facts, reader bindings remain immutable, and fresh world allocation is annotated where the compiler contract permits. GCC is deliberately not given the malloc attribute for pointer-containing initialized world storage.', '',
             'The full-owner experiment did not establish an extra checked win against pico_ecs on confirmation. Its memory increase and the remaining multi-component read losses are explicit tradeoffs, not a claim that every change wins every case. Indexed worlds still allocate through the world slot capacity and can be much slower for fragmented queries. Packed storage remains the default.', '',
             '## Preserved experiments', '',
             'Short probes use five rounds/10 ms; final v37 and v42 confirmations use nine rounds/30 ms. Counts from short probes are diagnostic and are not substituted into the final table. Failed caching, bitmap, branch-layout, and compact-handle experiments remain archived.', '',
             '| Entity experiment | Rounds | EnTT wins | pico wins | Flecs wins |',
             '| --- | ---: | ---: | ---: | ---: |']
    for run in sorted(RESULTS.glob('multi-ecs-*')):
        p = run / 'metadata.json'
        if not p.exists() or not (run / 'summary.csv').exists(): continue
        m = json.loads(p.read_text())
        label = m.get('cedar',{}).get('label','')
        if label.rsplit('-v',1)[-1].isdigit() and int(label.rsplit('-v',1)[-1]) >= 26:
            data = rows(run.name)
            text.append(f"| {label} | {m['repeats']} | "+' | '.join(str(stats(data,f)[0]) for f in ('entt','pico','flecs'))+' |')
    text += ['', 'The focused C controls/prototypes are retained as `owner-v37-creation`, `inline-zero-v38-creation`, `uniform-zero-v39-creation`, `zero-capacity-v40-creation`, and `inline-memory-v41-creation`; each has all 66 cases and nine paired repetitions.', '',
             '## Validation and limits', '',
             'Core ASan/UBSan and TSan, 65/320-component configurations, parking-only workers, and the portable memory fallback pass. Both storage modes are exercised. New tests cover dirty recycled rows, homogeneous and mixed signatures, tags, odd sizes, partial initialized spawning, mutable prepared access across growth/recycling, and C++ final-generation/non-default-constructible value reads. Checked and known-live C++ correctness tests pass ASan/UBSan and CTest.', '',
             'Expanded release and ASan/UBSan smokes cover 374 parameter/size cases per engine per fixed policy. Cedar TSan worker-command checks cover both policies. The original 50-case and both complete 386-case comparisons retain every sample and cross-engine checksum/counter. All native competitor binaries and shared kernels remain identical to the previous comparison. Earlier Flecs development pipeline TSan diagnostics remain separate and unresolved; no competitor source patches or suppressions were added.', '',
             'All work stays under `testing/`. Production `include/cedarecs/` remains equal to the original isolated baseline. Exposed experimental layouts changed, so consumers must rebuild. Windows, other architectures, application workloads and additional native ECS adapters remain unvalidated. These results cannot establish a universal ranking.', '',
             'Reproduce with the pinned dependencies:', '', '```sh',
             'make -C testing all expanded expanded-indexed',
             'python3 testing/interop/abeimler/run.py --repeats 9 --min-time 0.03 --output testing/results/NEW-entities',
             'python3 testing/bench/run.py --output results/NEW-original',
             'python3 testing/bench/expanded/run.py --output results/NEW-packed',
             'python3 testing/bench/expanded/run.py --cedar-storage indexed --output results/NEW-indexed',
             '```', '',
             f'Sources: [checked entity CSV](results/{ENTITY}/summary.csv), [packed C comparison](results/{PACKED}/comparison.md), [indexed C comparison](results/{INDEXED}/comparison.md), [audit](validation/memory-access-v42/verification.json).', '']
    (ROOT / 'OPTIMIZATIONS_MEMORY.md').write_text('\n'.join(text))
    print('Wrote OPTIMIZATIONS_MEMORY.md')


if __name__ == '__main__':
    main()
