#define _POSIX_C_SOURCE 200809L
#include "bench.h"
#include <errno.h>
#include <time.h>
#include <sys/resource.h>
#if defined(__APPLE__)
#include <pthread/qos.h>
#endif

uint64_t bench_now(void) {
    struct timespec ts;
    CHECK(!clock_gettime(CLOCK_MONOTONIC, &ts));
    return (uint64_t)ts.tv_sec * UINT64_C(1000000000) + (uint64_t)ts.tv_nsec;
}
static size_t number(const char *text) {
    char *end;
    errno = 0;
    unsigned long long value = strtoull(text, &end, 10);
    CHECK(!errno && *text && !*end && value > 0 && value <= SIZE_MAX && text[0] != '-');
    return (size_t)value;
}
int main(int argc, char **argv) {
    CHECK(argc == 5);
    Config config = {argv[1], number(argv[2]), number(argv[3]), number(argv[4])};
    CHECK(config.entities <= 10000000 && config.iterations <= 100000 && config.threads <= 256);
#if defined(__APPLE__)
    CHECK(!pthread_set_qos_class_self_np(QOS_CLASS_USER_INITIATED, 0));
#endif
    Result result = bench_execute(&config);
    CHECK(result.operations);
    struct rusage usage;
    CHECK(!getrusage(RUSAGE_SELF, &usage));
    uint64_t rss = (uint64_t)usage.ru_maxrss;
#if !defined(__APPLE__)
    rss *= 1024;
#endif
    printf("{\"engine\":\"%s\",\"version\":\"%s\",\"scenario\":\"%s\","
           "\"entities\":%zu,\"iterations\":%zu,\"threads\":%zu,\"archetypes\":%zu,"
           "\"elapsed_ns\":%llu,\"operations\":%llu,\"ns_per_op\":%.9f,"
           "\"checksum\":\"%016llx\",\"peak_rss_bytes\":%llu}\n",
        bench_engine(), bench_version(), config.scenario,
        config.entities, config.iterations, config.threads, result.archetypes,
        (unsigned long long)result.elapsed_ns, (unsigned long long)result.operations,
        (double)result.elapsed_ns / (double)result.operations,
        (unsigned long long)result.checksum, (unsigned long long)rss);
    return 0;
}
