#!/usr/bin/env python3
"""Audit the final candidate, unchanged comparisons, and retained experiments."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[1]
VALID = ROOT / 'validation/memory-access-v42'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def meta(run):
    return json.loads((ROOT / 'results' / run / 'metadata.json').read_text())


def validate(script, run):
    subprocess.run(['python3', str(ROOT / script), str(ROOT / 'results' / run)], check=True)


def main():
    manifest = json.loads((ROOT / 'provenance.json').read_text())
    assert manifest['cedarecs']['label'] == 'memory-access-v42'
    snapshot = ROOT / 'variants/memory-access-v42'
    for name, h in manifest['cedarecs']['files'].items():
        assert digest(ROOT / name) == digest(snapshot / name) == h, name
    baseline = ROOT / 'variants/baseline'
    # Finder metadata predates the snapshot and was not copied into the baseline.
    assert {p.relative_to(baseline/'cedarecs') for p in (baseline/'cedarecs').rglob('*') if p.is_file()} == {p.relative_to(ROOT.parent/'include/cedarecs') for p in (ROOT.parent/'include/cedarecs').rglob('*') if p.is_file() and p.name != '.DS_Store'}
    for p in (baseline / 'cedarecs').rglob('*'):
        if p.is_file():
            assert p.read_bytes() == (ROOT.parent / 'include/cedarecs' / p.relative_to(baseline / 'cedarecs')).read_bytes()
    for name in ('workloads.inc', 'kernel.c', 'main.c', 'flecs_backend.c', 'bench.h'):
        assert (ROOT / 'bench' / name).read_bytes() == (baseline / name).read_bytes()
    assert digest(ROOT / 'kama/kama.h') == manifest['kama']['header_sha256']
    assert subprocess.check_output(['git','-C',str(ROOT/'flecs'),'rev-parse','HEAD'],text=True).strip() == manifest['flecs']['commit']
    assert not subprocess.check_output(['git','-C',str(ROOT/'flecs'),'status','--porcelain'],text=True).strip()

    original = 'memory-access-v42-original'
    validate('bench/validate_results.py', original)
    old = meta('indexed-v25-original')
    current = meta(original)
    assert current['binaries_sha256']['flecs'] == old['binaries_sha256']['flecs']
    assert current['kernel_object_sha256'] == old['kernel_object_sha256']
    assert digest(ROOT/'build/bench_cedarecs') == current['binaries_sha256']['cedarecs']
    assert digest(ROOT/'build/bench_flecs') == current['binaries_sha256']['flecs']

    prior = meta('indexed-v25-packed')
    c_runs = ['memory-access-v42-packed', 'memory-access-v42-slots']
    for run, mode in zip(c_runs, ('archetype','indexed')):
        m = meta(run)
        assert m['cedar_storage'] == mode
        assert m['cases'] == prior['cases'] and len(m['cases']) == 386
        assert m['binaries_sha256']['flecs'] == prior['binaries_sha256']['flecs']
        assert m['kernel_object_sha256'] == prior['kernel_object_sha256']
        for name in ('catalog.py','flecs.c','kernels.c','main.c','suite.h','workloads.inc'):
            key = 'bench/expanded/' + name
            assert m['harness_sha256'][key] == prior['harness_sha256'][key], key
        # Cedar's prepared-access adapter change is explicit, with identical workloads.
        for name, h in m['harness_sha256'].items():
            assert digest(ROOT/'results'/run/'source'/name) == h
        binary = ROOT/'build'/('expanded-indexed' if mode == 'indexed' else 'expanded')/'cedarecs'
        assert digest(binary) == m['binaries_sha256']['cedarecs']
        assert ('cedar-storage:'+mode).encode() in binary.read_bytes()
        validate('bench/expanded/validate.py', run)

    entity_run = 'multi-ecs-memory-access-v42'
    final_entity = meta(entity_run)
    assert final_entity['repeats'] == 9 and final_entity['min_time'] == .03
    assert final_entity['cedar_read_mode'] == 'checked'
    assert final_entity['cedar']['snapshot_sha256'] == manifest['cedarecs']['snapshot_sha256']
    assert digest(ROOT/'build/interop/cedar-entities') == final_entity['binary_sha256']['cedar']
    old_entity = meta('multi-ecs-indexed-initialized-v24')
    for f in ('entt','pico','flecs'):
        assert final_entity['binary_sha256'][f] == old_entity['binary_sha256'][f]
        assert digest(ROOT/'build/interop'/(f+'-entities')) == final_entity['binary_sha256'][f]

    experiments = []
    for run in sorted((ROOT/'results').glob('multi-ecs-*')):
        p = run/'metadata.json'
        if not p.exists() or not (run/'summary.csv').exists(): continue
        m = json.loads(p.read_text())
        label = m.get('cedar',{}).get('label','')
        version = label.rsplit('-v',1)[-1]
        if not version.isdigit() or int(version) < 26: continue
        archived = run/'source'
        archived.mkdir(exist_ok=True)
        for name, h in m['adapter_sha256'].items():
            source = ROOT/'variants'/label/'interop'/name
            assert digest(source) == h, (run.name,name)
            target = archived/name
            if target.exists(): assert digest(target) == h
            else: shutil.copy2(source,target)
        for f in ('entt','pico','flecs'):
            assert m['binary_sha256'][f] == old_entity['binary_sha256'][f]
        validate('interop/abeimler/validate.py',run.name)
        experiments.append(run.name)

    focused = ['owner-v37-creation','inline-zero-v38-creation','uniform-zero-v39-creation',
               'zero-capacity-v40-creation','inline-memory-v41-creation']
    for run in focused:
        m = meta(run)
        assert len(m['cases']) == 66 and m['repeats'] == 9
        for name,h in m['harness_sha256'].items():
            assert digest(ROOT/'results'/run/'source'/name) == h
        assert m['binaries_sha256']['flecs'] == prior['binaries_sha256']['flecs']
        assert m['kernel_object_sha256'] == prior['kernel_object_sha256']
        validate('bench/expanded/validate.py',run)

    checks = (VALID/'checks.log').read_text()
    assert checks.count('ECS tests passed (archetype and indexed storage)') == 6
    assert 'Container tests passed' in checks
    assert 'ASan/UBSan passed: checked' in checks and 'ASan/UBSan passed: known-live' in checks
    smoke = (VALID/'smoke.log').read_text()
    assert smoke.count('Expanded smoke passed: 374') == 4
    assert smoke.count('Expanded smoke passed: 12') == 2
    assert '100% tests passed' in (VALID/'interop.log').read_text()

    plots = json.loads((ROOT/'results/memory-access-v42-packed/memory-plot-metadata.json').read_text())
    for p,h in plots['inputs'].items(): assert digest(ROOT/p) == h
    for p,h in plots['outputs'].items(): assert digest(ROOT/'results/memory-access-v42-packed'/p) == h
    tests = VALID/'source/tests'
    tests.mkdir(parents=True,exist_ok=True)
    for p in (ROOT/'tests').iterdir():
        if p.is_file(): shutil.copy2(p,tests/p.name)
    record = dict(
        verified_utc=datetime.now(timezone.utc).isoformat(),
        cedar_snapshot=manifest['cedarecs']['snapshot_sha256'],
        production_equals_initial_baseline=True,
        production_comparison_excludes=['.DS_Store (pre-existing Finder metadata)'],
        original_five_common_files_unchanged=True,
        expanded_common_workloads_catalog_driver_kernels_and_flecs_adapter_unchanged=True,
        expanded_cedar_adapter_uses_checked_mutable_prepared_access=True,
        shared_kernels_and_all_competing_executables_unchanged=True,
        final_entity_access_contract='checked, full 64-bit generational handles',
        fixed_C_policies_reported_separately=True,
        final_entity_samples=1008,
        final_C_samples=900+2*6948,
        retained_entity_experiments=experiments,
        retained_focused_C_experiments=focused,
        test_source_sha256={str(p.relative_to(ROOT)):digest(p) for p in (ROOT/'tests').iterdir() if p.is_file()},
        evidence_sha256={p.name:digest(p) for p in VALID.glob('*.log') if p.name!='audit.log'},
        tests='Core ASan/UBSan/TSan; 65/320 components; parking-only workers; portable memory fallback; both C++ contracts; expanded release+ASan/UBSan both engines and policies; Cedar TSan worker commands both policies',
        limits='One macOS ARM64 host; entity suite covers three competitors and compatible pins; no claim of universal 90% wins; prior Flecs native pipeline TSan diagnostic remains unresolved')
    (VALID/'verification.json').write_text(json.dumps(record,indent=2)+'\n')
    print('Verified final source/binary provenance, all retained results, fixed workloads, competitors, tests and plot data.')


if __name__ == '__main__':
    main()
