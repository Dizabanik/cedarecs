#!/usr/bin/env python3
"""Build the measured v16 report; inputs remain retained, per-case datasets."""
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / 'results'

def rows(name):
    return list(csv.DictReader((RESULTS / name / 'summary.csv').open()))

def c_counts(data):
    median = sum(float(r['flecs_over_cedar']) > 1 for r in data)
    cedar = sum(float(r['cedarecs_p75_ns']) < float(r['flecs_p25_ns']) for r in data)
    flecs = sum(float(r['flecs_p75_ns']) < float(r['cedarecs_p25_ns']) for r in data)
    return median, cedar, flecs, len(data) - cedar - flecs

expanded = rows('query-access-v16-expanded')
previous = {r['case']: r for r in rows('expanded-confirmation-20261026')}
interop = rows('multi-ecs-query-access-v16')
old_interop = {r['benchmark']: r for r in rows('multi-ecs-20261026')}
raw = [json.loads(s) for s in (RESULTS / 'multi-ecs-query-access-v16/raw.jsonl').read_text().splitlines()]
counts = {r['name']: r.get('entities', 0) for r in raw}
frameworks = ('cedar', 'entt', 'pico', 'flecs')
text = ['# Cedar optimization: deferred runs, initialized creation, and query plans', '',
    'Measured October 26, 2026 on the same Apple M4 Pro. Changes remain in `testing/cedarecs/`; production is byte-identical to the initial isolated snapshot. Active source: `query-access-v16` (`e41c24f47779d8b51e0304509f49b01d3de9f3b72425aed33bc3c985f694abd0`).', '',
    'Cedar now leads all 28 median cases against Flecs 4.0.1 in the shared upstream entity suite. It also wins cases against EnTT and pico_ecs, including populated creation at 1,024 and 65,536 entities. It does not lead every framework or every workload.', '',
    '## Changes', '',
    '- Fold adjacent deferred commands for the same handle into their final signature; preserve FIFO value semantics and perform at most one migration. Compact commands from 40 to 24 bytes on this target.',
    '- Add optional nested producer scopes to lock once per command group. Unscoped writes retain individual mutex protection. C adapters use scopes around the same existing command sequences.',
    '- Inline presence membership directly, retaining entity generation and ID validation.',
    '- Add `ced_entity_from_plan_values` to initialize directly in the final archetype, including alias-safe initialization when columns grow. The C++ factory uses it for the same upstream default values.',
    '- Add plain C/C++ `access.h` metadata and inline reads, without assuming a C++ layout for C atomics or Kama maps. Component data still copies into C++ Position/Velocity objects.',
    '- Cache eight recent transition edges per archetype, with Kama retaining the authoritative map.',
    '- Keep dispatch slices per query so alternating systems retain their prepared plans. Each query retains one slice per grain-sized chunk of each matched archetype until freed; revisions or a changed grain rebuild its plan.', '',
    '## Fixed C comparison', '',
    'Nine paired samples per engine/configuration, two discarded process warmups, identical iterations and checksums. Median wins are case counts, not a combined performance score. Disjoint IQR means the winner’s p75 is below the other engine’s p25; it is descriptive, not a significance test.', '',
    '| Dataset | Configurations | Cedar lower median | Cedar disjoint IQR | Flecs disjoint IQR | Overlap |',
    '| --- | ---: | ---: | ---: | ---: | ---: |']
for label,name in [('Previous expanded','expanded-confirmation-20261026'),('Current expanded','query-access-v16-expanded'),('Current original','query-access-v16-original'),('Current sustained frames','query-access-v16-sustained')]:
    data = rows(name)
    text.append(f'| {label} | {len(data)} | ' + ' | '.join(map(str,c_counts(data))) + ' |')
text += ['', 'Selected before/after cases below use the same workload and units. Complete results retain all wins and losses.', '',
    '| Case | Previous Cedar ns/op | Current Cedar ns/op | Current Flecs ns/op | Cedar improvement |',
    '| --- | ---: | ---: | ---: | ---: |']
selected = [('defer_phase',10000,32,8,0,10),('defer_cancel',10000,32,8,0,10),('has_mixed',100000,1,8,1,50)]
for scenario,n,width,size,shuffle,percent in selected:
    r = next(r for r in expanded if r['scenario']==scenario and int(r['entities'])==n and int(r['width'])==width and int(r['bytes'])==size and int(r['shuffled'])==shuffle and int(r['percent'])==percent)
    old=float(previous[r['case']]['cedarecs_median_ns']); new=float(r['cedarecs_median_ns'])
    text.append(f"| {r['case']} | {old:.3f} | {new:.3f} | {float(r['flecs_median_ns']):.3f} | {old/new:.2f}× |")
text += ['', 'The sustained profile raises the operation cap from five million to 500 million while preserving the complete 85-case frame/command/system matrix. Keep these longer samples separate from the short-burst full suite. At one million entities, 14 threads, one uint64 field and grain 1,024, the sustained median is about 42 µs/frame for Cedar versus 89 µs for Flecs. Very fine grains and some tiny workloads still favor Flecs.', '', '### Expanded families', '', '| Family | Cases | Cedar lower median | Cedar disjoint IQR | Flecs disjoint IQR | Overlap |','| --- | ---: | ---: | ---: | ---: | ---: |']
for family in sorted({r['family'] for r in expanded}):
    data=[r for r in expanded if r['family']==family]
    text.append(f'| {family} | {len(data)} | ' + ' | '.join(map(str,c_counts(data))) + ' |')
text += ['', '## Four-framework entity suite', '',
    'Five independent Google Benchmark process rounds per framework with rotating order; 560 samples across 28 cases. All three competing executables are byte-identical to the previous run. Native factories, benchmark templates, and dependency pins are unchanged. Cedar’s public API and factory usage changed as described above. This comparison covers entity operations, not full game/system integration for EnTT or pico_ecs.', '',
    '| Competitor | Cedar lower median / 28 | Cedar disjoint IQR | Competitor disjoint IQR | Overlap |',
    '| --- | ---: | ---: | ---: | ---: |']
for f in frameworks[1:]:
    wins=sum(float(r['cedar_cpu_median_ns'])<float(r[f+'_cpu_median_ns']) for r in interop)
    a=sum(float(r['cedar_cpu_p75_ns'])<float(r[f+'_cpu_p25_ns']) for r in interop)
    b=sum(float(r['cedar_cpu_p25_ns'])>float(r[f+'_cpu_p75_ns']) for r in interop)
    text.append(f'| {f} | {wins} | {a} | {b} | {len(interop)-a-b} |')
text += ['', 'CPU ns per **reported iterated entity** at the requested population of 1,024 (lower is better). Creation/destruction include the upstream teardown boundaries. The three-component case creates 1,024 entities but iterates only the 512 stored in its output vector; normalization uses that actual counter. The raw CSV stores total CPU ns per complete pass.', '',
    '| Case | Previous Cedar | Current Cedar | EnTT 3.13.2 | pico_ecs (2024 pin) | Flecs 4.0.1 |',
    '| --- | ---: | ---: | ---: | ---: | ---: |']
for r in interop:
    if r['benchmark'].endswith('/1024'):
        n=counts[r['benchmark']]
        old=float(old_interop[r['benchmark']]['cedar_cpu_median_ns'])/n
        text.append('| '+r['benchmark'].split('/')[0]+' | '+f'{old:.3f} | '+' | '.join(f"{float(r[f+'_cpu_median_ns'])/n:.3f}" for f in frameworks)+' |')
text += ['', '![Four-framework comparison](results/query-access-v16-expanded/entity-comparison.png)', '',
    '## Remaining deficits and tradeoffs', '',
    'Immediate remove/add still costs more than EnTT and pico_ecs. Archetype migration copies retained columns and compacts the source table twice per cycle; the small edge cache reduces lookup overhead but does not eliminate that storage work. Deferred folding cannot replace the immediate API’s visibility guarantees.', '',
    'Several individual component reads remain slower than pico_ecs, and absent reads remain slower than EnTT. The new read interface removes external calls but still validates generations and traverses archetype/column metadata. Wide creation, wide recycling, some large payload writes, and some frame configurations still favor Flecs; query comparisons include overlapping IQRs in the expanded suite. Multi-query slice caching consumes additional retained memory for every dispatched query; free unused queries to release it.', '',
    '## Validation and reproduction', '',
    '`make -C testing check check-tsan check-config check-parking smoke smoke-expanded sanitize-expanded tsan-expanded` passed. These include 374 expanded parameter/size cases per engine, ASan/UBSan, Cedar thread-sanitizer checks with concurrent producers, 65/320 component configurations, and parking without spinning. The C++ bridge check also passes under ASan/UBSan via `make -C testing check-interop`. Differential tests compare deferred runs to immediate execution, including tags, resets, stale handles, kill prefixes, late registration, aliasing during growth, wide initialized plans, alternating queries, and query/pool lifetime changes.', '',
    'The previous Flecs development native-pipeline TSan diagnostics remain unresolved and are retained in `validation/expanded/`; passing correctness and ASan/UBSan here does not establish Flecs race freedom.', '',
    'Release runs (one at a time):', '',
    '```sh', 'python3 testing/bench/run.py --output results/NEW-original', 'python3 testing/bench/expanded/run.py --output results/NEW-expanded', 'python3 testing/interop/abeimler/run.py --output testing/results/NEW-multi-ecs', '```', '',
    'See [expanded results](results/query-access-v16-expanded/comparison.md), [original results](results/query-access-v16-original/comparison.md), [four-framework raw summary](results/multi-ecs-query-access-v16/summary.csv), and [validation evidence](validation/query-access-v16/verification.json). Historical inputs and the intermediate v15 measurements are preserved. The original five frozen C workload/Flecs files, expanded workload/catalog/kernel/Flecs adapter, shared kernel object, and all competitor binaries are unchanged. Source manifests and measured adapters are archived with results and variants.', '']
(ROOT/'OPTIMIZATIONS_V16.md').write_text('\n'.join(text))
print('Wrote', ROOT/'OPTIMIZATIONS_V16.md')
