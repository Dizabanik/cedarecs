"""Complete predeclared paired map/registry probe with retained samples."""
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import itertools
import json
import os
from pathlib import Path
import shutil
import statistics
import subprocess

ROOT = Path(__file__).resolve().parents[1]
p = argparse.ArgumentParser()
p.add_argument('--suite', choices=('map', 'registry'), required=True)
p.add_argument('--output', type=Path, required=True)
p.add_argument('--repeats', type=int, default=16)
p.add_argument('--new-binary', type=Path, help='Alternate measured new dependency/configuration binary')
args = p.parse_args()
assert args.repeats % 16 == 0
out = args.output.resolve(); out.mkdir(parents=True, exist_ok=False)
versions = ('old', 'new') if args.suite == 'map' else ('old', 'new', 'conc')
binaries = {}
for key, letter in zip(versions, 'abc'):
    binaries[key] = out / ('engine-' + letter)
    source = args.new_binary if key == 'new' and args.new_binary else ROOT / 'build/kama-refresh' / (args.suite + '-' + key)
    shutil.copy2(source, binaries[key])
if args.suite == 'map':
    jobs = [(kind, count, (1 << 22) // count, long_names)
            for kind, count in itertools.product(range(7), (4096, 65536))
            for long_names in ((0, 1) if kind in (3, 4) else (0,))]
else:
    jobs = [(threads, worlds, (100000 if not commands else 20000) // worlds, commands)
            for threads, worlds, commands in itertools.product((1, 4, 8), (1, 2, 8), (0, 1))]
shutil.copy2(__file__, out/'runner.py')
shutil.copy2(ROOT/'bench'/(args.suite == 'map' and 'kama_workloads.c' or 'registry_workloads.c'), out/'workload.c')
shutil.copy2(ROOT/'build/kama-refresh/build.json', out/'build.json')
meta = dict(suite=args.suite, repeats=args.repeats, started_utc=datetime.now(timezone.utc).isoformat(),
            cases=len(jobs), versions=versions,
            binaries={k: hashlib.sha256(v.read_bytes()).hexdigest() for k,v in binaries.items()},
            methodology='Sequential processes, equal-length executable paths, rotated/reversed order, eight crossed environment paddings; all samples retained. Raw monotonic complete-loop timing, post-timing value validation. Registry scope begin/end compares old/current ordinary locks and isolated lazy eight-shard map; it is not a full command throughput benchmark.')
(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
summary = []
with (out/'raw.jsonl').open('w') as log:
    for index, job in enumerate(jobs):
        samples = {k: [] for k in versions}; checksums = set()
        for trial in range(-2, args.repeats):
            order = list(versions[trial % len(versions):] + versions[:trial % len(versions)])
            if trial % 2: order.reverse()
            for position,key in enumerate(order):
                result = subprocess.run([str(binaries[key]), *map(str, job)], check=True,
                    capture_output=True,text=True,timeout=120,
                    env=dict(os.environ,LC_ALL='C',CEDAR_BENCH_STACK_PAD='x'*((max(trial,0)//2)%8)*16))
                assert not result.stderr, result.stderr
                row = json.loads(result.stdout); assert row['version'] == key
                checksums.add((row['checksum'], row['operations']))
                if trial >= 0:
                    samples[key].append(row['ns_per_op'])
                    log.write(json.dumps(dict(case=list(job),trial=trial,position=position,**row))+'\n')
        assert len(checksums)==1
        row = dict(case='/'.join(map(str,job)))
        for key,values in samples.items():
            q=statistics.quantiles(values,n=4,method='inclusive')
            row.update({key+'_median_ns':statistics.median(values),key+'_p25_ns':q[0],key+'_p75_ns':q[2]})
        row['new_over_old']=row['new_median_ns']/row['old_median_ns']
        if 'conc' in samples: row['conc_over_new']=row['conc_median_ns']/row['new_median_ns']
        summary.append(row); log.flush(); print(row,flush=True)
with (out/'summary.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,list(summary[0]));w.writeheader();w.writerows(summary)
meta['completed_utc']=datetime.now(timezone.utc).isoformat()
(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
