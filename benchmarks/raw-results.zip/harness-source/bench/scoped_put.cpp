#include <cedarecs/access.h>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>

extern "C" {
ced_World *ced_init_indexed(void);
ced_Component ced_component_register(ced_World *, const char *, size_t, size_t);
ced_Entity ced_entity_init(ced_World *);
bool ced_reserve_entities(ced_World *, size_t);
void ced_free(ced_World *);
}

static void require(bool condition) {
    if (!condition) { std::fputs("scoped put validation failed\n", stderr); std::abort(); }
}
template<size_t Bytes> struct Payload { uint64_t words[Bytes / 8]; };

// No per-operation timer pause: a complete checked write loop is measured.
// Each pass changes its input, and all resulting payload words are verified.
template<size_t Bytes> static int run(size_t count, size_t passes, bool cycle) {
    using T = Payload<Bytes>;
    auto *world = ced_init_indexed();
    auto component = ced_component_register(world, "Payload", sizeof(T), alignof(T));
    require(ced_reserve_entities(world, count));
    std::vector<ced_Entity> entities;
    for (size_t i = 0; i < count; ++i) entities.push_back(ced_entity_init(world));
    auto scope = ced_indexed_write_begin(world);
    auto binding = ced_indexed_bind(&scope, component);
    require(ced_indexed_prepare(&binding));
    ced_IndexedMutate<T> write(binding);
    ced_IndexedRead<T> read(ced_indexed_reader(world, component));
    T value{};
    for (size_t j = 0; j < Bytes / 8; ++j) value.words[j] = UINT64_C(0x5a6218c) ^ j;
    for (auto e : entities) require(write.put(e, value));
    const auto before = std::chrono::steady_clock::now();
    for (size_t pass = 0; pass < passes; ++pass) {
        value.words[0] = pass;
        for (auto e : entities) {
            if (cycle) write.remove(e);
            require(write.put(e, value));
        }
    }
    const auto after = std::chrono::steady_clock::now();
    uint64_t checksum = 0;
    for (auto e : entities) {
        const T actual = read.value(e);
        require(std::memcmp(&actual, &value, sizeof(T)) == 0);
        for (auto word : actual.words) checksum += word;
    }
    require(ced_indexed_write_end(&scope));
    ced_free(world);
    const double ns = std::chrono::duration<double, std::nano>(after - before).count();
    std::printf("{\"bytes\":%zu,\"entities\":%zu,\"passes\":%zu,\"cycle\":%s,\"ns_per_op\":%.9f,\"checksum\":%llu}\n",
                Bytes, count, passes, cycle ? "true" : "false", ns / double(count * passes),
                static_cast<unsigned long long>(checksum));
    return 0;
}

int main(int argc, char **argv) {
    if (argc != 5) return 2;
    size_t bytes = std::strtoull(argv[1], nullptr, 10);
    size_t count = std::strtoull(argv[2], nullptr, 10);
    size_t passes = std::strtoull(argv[3], nullptr, 10);
    bool cycle = std::strcmp(argv[4], "cycle") == 0;
    if (!count || !passes || count > SIZE_MAX / passes) return 2;
    switch (bytes) {
    case 8: return run<8>(count, passes, cycle);
    case 48: return run<48>(count, passes, cycle);
    case 256: return run<256>(count, passes, cycle);
    case 512: return run<512>(count, passes, cycle);
    default: return 2;
    }
}
