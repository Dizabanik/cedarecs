#include <cedarecs/cedar.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <inttypes.h>
static uint64_t now(void) {
    struct timespec t;clock_gettime(CLOCK_MONOTONIC_RAW,&t);
    return (uint64_t)t.tv_sec*UINT64_C(1000000000)+(uint64_t)t.tv_nsec;
}
static void scope(ced_World *w) { if(!ced_commands_begin(w)||!ced_commands_end(w))abort(); }
int main(int argc,char **argv) {
    if(argc!=4)return 2;
    size_t kind=strtoull(argv[1],NULL,10),n=strtoull(argv[2],NULL,10);if(kind>3||!n)return 2;
    uint64_t start=now();
    switch(kind) {
    case 0:for(size_t i=0;i<n;++i){ced_World *w=ced_world();ced_drop(w);}break;
    case 1:for(size_t i=0;i<n;++i){ced_World *w=ced_world();scope(w);ced_drop(w);}break;
    case 2:for(size_t i=0;i<n;++i){ced_World *w=ced_world();for(size_t k=0;k<16;++k)scope(w);ced_drop(w);}break;
    case 3:for(size_t i=0;i<n;++i){ced_World *w=ced_world();ced_View *q=ced_cached_view(w,0,NULL);if(!q||q!=ced_cached_view(w,0,NULL)||ced_view_count(q))abort();ced_drop(w);}break;
    }
    uint64_t elapsed=now()-start;
    printf("{\"version\":\"%s\",\"kind\":%zu,\"worlds\":%zu,\"ns_per_world\":%.9f}\n",argv[3],kind,n,(double)elapsed/n);
}
