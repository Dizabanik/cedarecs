"""Minimal white comparisons; exact times and gaps, with every loss retained."""
import csv
import hashlib
import json
import math
from pathlib import Path
import shutil
import textwrap

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.ticker import MaxNLocator
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'promotion/kama-v107'
COLORS={'cedar':'#15976b','cedar-packed':'#15976b','cedar-indexed':'#138a96',
        'entt':'#3864c7','pico':'#dc8c20','flecs':'#d95263','before':'#7a8390','new':'#15976b',
        'old':'#7a8390','conc':'#138a96','ordinary':'#15976b','concurrent':'#138a96'}
NAMES={'cedar':'Cedar','cedar-packed':'Cedar packed','cedar-indexed':'Cedar indexed',
       'entt':'EnTT','pico':'pico_ecs','flecs':'Flecs','before':'Before','old':'Kama before',
       'new':'Kama updated','conc':'Concurrent','ordinary':'Cedar ordinary','concurrent':'Cedar concurrent'}
TEXT='#223248'; MUTED='#738092'; INPUTS=set(); PLOTTED=[]; OUTPUTS=[]; PAGES=[]
plt.rcParams.update({'font.family':'DejaVu Sans','text.color':TEXT,'axes.labelcolor':MUTED,
                     'xtick.color':MUTED,'ytick.color':TEXT,'svg.fonttype':'none','pdf.fonttype':42})
FRIENDLY={'BM_CreateNoEntities':'Empty world','BM_CreateEmptyEntities':'Create empty entities',
          'BM_CreateEntities':'Create with components','BM_DestroyEntities':'Destroy entities',
          'BM_AddComponent':'Add component','BM_RemoveAddComponent':'Remove + add component',
          'BM_UnpackNoComponent':'Check absent component','BM_UnpackOneComponent':'Read one component',
          'BM_UnpackTwoComponents':'Read two components','BM_UnpackThreeComponents':'Read three components'}

def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(run,file):
    path=ROOT/'results'/run/file; INPUTS.add(path)
    if file.endswith('.csv'):return list(csv.DictReader(path.open()))
    if file.endswith('.jsonl'):return [json.loads(line) for line in path.read_text().splitlines()]
    return json.loads(path.read_text())
def number(n):
    if n==0:return '0'
    if abs(n)<.1:return f'{n:.4f}'
    if abs(n)<10:return f'{n:.3f}'
    if abs(n)<100:return f'{n:.2f}'
    if abs(n)<1000:return f'{n:.1f}'
    return f'{n:,.0f}'
def tick_label(n):
    return f'{n:g}' if abs(n)<1000 else f'{n:,.0f}'
def gap(n):
    return ('+' if n>0 else '')+f'{n:.2f}%'
def item(key,r,prefix,denominator=1):
    return dict(framework=key,median=float(r[prefix+'median_ns'])/denominator,
                p25=float(r[prefix+'p25_ns'])/denominator,p75=float(r[prefix+'p75_ns'])/denominator)
def short_case(case):
    # Every parameter remains present. Abbreviations are expanded in README.
    for a,b in [('entities=','N='),('threads=','T='),('systems=','sys='),('shuffled=','shuffle='),
                ('1000000','1M'),('100000','100k'),('65536','65,536'),('10000','10k'),('1000','1k')]:
        case=case.replace(a,b)
    return case.replace('/', ' · ').replace(',', ', ')
def entity_cards():
    run='kama-v107-entities'; meta=read(run,'metadata.json'); assert 'completed_utc' in meta
    raw=read(run,'raw.jsonl'); rows=read(run,'summary.csv'); assert len(rows)==28
    cards=[]
    for r in sorted(rows,key=lambda r:(r['benchmark'].split('/')[0],int(r['benchmark'].split('/')[-1]) if '/' in r['benchmark'] else 0)):
        case=r['benchmark']; base=case.split('/')[0]
        counts={int(s['entities']) for s in raw if s['name']==case};assert len(counts)==1
        count=counts.pop(); denominator=max(1,count)
        population=int(case.split('/')[-1]) if '/' in case else 0
        cards.append(dict(dataset=run,key=case,title=FRIENDLY[base]+(f' · N={population:,}' if population else ''),
            unit='ns/entity' if count else 'ns/world',reference='cedar',
            series=[item(f,r,f+'_cpu_',denominator) for f in ('cedar','entt','pico','flecs')]))
    return cards
def native_cards(suite):
    run='kama-v107-'+suite+('-long' if suite=='original' else ''); meta=read(run,'metadata.json');assert 'completed_utc' in meta
    INPUTS.add(ROOT/'results'/run/'raw.jsonl')
    rows=read(run,'summary.csv');assert len(rows)==(50 if suite=='original' else 386)
    cards=[]
    for r in sorted(rows,key=lambda r:r['case']):
        cards.append(dict(dataset=run,key=r['case'],title=suite.capitalize()+' · '+short_case(r['case']),
            unit='ns/op',reference='cedar',series=[item(f,r,f+'_') for f in ('cedar','flecs')]))
    return cards
def memory_cards():
    run='kama-v107-memory'; meta=read(run,'metadata.json');assert 'completed_utc' in meta
    INPUTS.add(ROOT/'results'/run/'raw.jsonl')
    rows=read(run,'summary.csv');groups={}
    for r in rows:groups.setdefault((r['scenario'],int(r['entities']),int(r['step']),r['phase']),{})[r['framework']]=r
    cards=[]
    for (scenario,n,step,phase),by_framework in sorted(groups.items()):
        for metric,label in [('accounted_storage_delta','Accounted storage'),('footprint_delta','Physical footprint')]:
            s=[]
            for f in ('cedar-packed','cedar-indexed','entt','pico','flecs'):
                r=by_framework[f]
                s.append(dict(framework=f,**{stat:float(r[metric+'_'+stat])/1048576 for stat in ('median','p25','p75')}))
            cards.append(dict(dataset=run,key=f'{scenario}/{n}/{step}/{phase}/{metric}',
                title=f'{scenario} · {n:,} · {phase} · step {step}\n{label}',unit='MiB',reference=None,series=s))
    return cards
def dependency_cards():
    read('kama-v106-maps','metadata.json');INPUTS.add(ROOT/'results/kama-v106-maps/raw.jsonl')
    names=['Integer insert','Integer lookup','Integer overwrite','String lookup','String overwrite',
           'Fixed 32-byte lookup','Integer delete + insert']
    cards=[]
    for r in read('kama-v106-maps','summary.csv'):
        kind,count,passes,long_names=map(int,r['case'].split('/'))
        title=names[kind]+(' · long keys' if long_names else ' · short keys' if kind in (3,4) else '')+f' · N={count:,}'
        cards.append(dict(dataset='kama-v106-maps',key=r['case'],title=title,unit='ns/op',reference='old',
            reference_label='previous Kama',series=[item(f,r,f+'_') for f in ('old','new')]))
    return cards
def registry_cards():
    read('kama-v107-registry','metadata.json');INPUTS.add(ROOT/'results/kama-v107-registry/raw.jsonl')
    cards=[]
    for r in read('kama-v107-registry','summary.csv'):
        threads,worlds,passes,commands=map(int,r['case'].split('/'))
        a=item('ordinary',r,'new_');b=item('concurrent',r,'conc_')
        cards.append(dict(dataset='kama-v107-registry',key=r['case'],
            title=('Enqueue value' if commands else 'Command scope')+f' · {threads} threads · {worlds} worlds',
            unit='ns/op',reference='ordinary',reference_label='ordinary registry',series=[a,b]))
    return cards
def remember(card):
    ref=next((s['median'] for s in card['series'] if s['framework']==card['reference']),None)
    for s in card['series']:
        PLOTTED.append(dict(dataset=card['dataset'],case=card['key'],unit=card['unit'],**s,
            time_gap_percent=None if ref is None else (s['median']/ref-1)*100))
def draw(ax,card,small=False):
    ref=next((s['median'] for s in card['series'] if s['framework']==card['reference']),None)
    ax.set_facecolor('#f4f7fa');ax.set_axisbelow(True)
    ax.grid(axis='x',color='white',linewidth=1.1)
    for spine in ax.spines.values():spine.set_visible(False)
    count=len(card['series']); y=np.arange(count)
    med=np.array([s['median'] for s in card['series']]); lo=np.array([s['p25'] for s in card['series']]);hi=np.array([s['p75'] for s in card['series']])
    assert np.all(lo<=med) and np.all(med<=hi)
    if ref is not None:
        values=(med/ref-1)*100; low=(lo/ref-1)*100; high=(hi/ref-1)*100
        # A clearly labeled symlog gap axis expands small differences. This is
        # not a truncated absolute-time bar axis. Exact times accompany gaps.
        ax.set_xscale('symlog',linthresh=.1,linscale=.4)
        left=min(-.1,float(min(low))*1.8);right=max(1,float(max(high))*1.8)
        ticks=[v for v in (-100,-10,-1,0,1,10,100,1000,10000) if left<=v<=right]
        ax.set_xticks(ticks,[tick_label(v) for v in ticks],fontsize=6 if small else 7)
        ax.set_xlim(left,right); ax.axvline(0,color='#a5b3c2',lw=.8)
    else:
        values=med;low=lo;high=hi
        span=max(1,float(max(high)-min(0,min(low))))
        ax.set_xlim(min(0,float(min(low)))-span*.05,max(0,float(max(high)))+span*.15)
        ax.xaxis.set_major_locator(MaxNLocator(nbins=4))
        ax.tick_params(axis='x',labelsize=6 if small else 7)
    for i,(s,value) in enumerate(zip(card['series'],values)):
        color=COLORS[s['framework']]
        ax.plot([0,value],[i,i],color=color,lw=4 if small else 6,solid_capstyle='round',alpha=.8)
        ax.plot(value,i,'o',color=color,ms=4 if small else 5,zorder=4)
        ax.plot([low[i],high[i]],[i,i],color=color,lw=1.2,zorder=5)
        annotation=number(s['median'])+' '+card['unit']
        if ref is not None:annotation+='   '+gap(float(value))
        ax.text(1.06,i,annotation,transform=ax.get_yaxis_transform(),va='center',
                color=color if s['framework']==card['reference'] else TEXT,
                fontsize=7 if small else 9,fontweight='bold' if s['framework']==card['reference'] else 'normal')
    ax.set_yticks(y,[NAMES[s['framework']] for s in card['series']],fontsize=7 if small else 9)
    ax.set_ylim(count-.5,-.6);ax.tick_params(length=0,pad=5)
    ax.set_title('\n'.join(textwrap.wrap(card['title'],65 if small else 52)),loc='left',
                 fontsize=8 if small else 10,fontweight='bold',pad=13)
    ax.set_xlabel('Time gap vs '+card.get('reference_label','Cedar')+' (%) · symlog' if ref is not None else card['unit'],fontsize=6 if small else 7,labelpad=5)
def save(fig,stem,formats=('png','svg','pdf'),dpi=170):
    for ext in formats:
        path=OUT/(stem+'.'+ext);fig.savefig(path,dpi=dpi,facecolor='white');OUTPUTS.append(path)
    plt.close(fig)
def poster(cards,stem,columns=3):
    rows=math.ceil(len(cards)/columns)
    fig,axes=plt.subplots(rows,columns,figsize=(19,rows*3.1+.45),squeeze=False)
    fig.subplots_adjust(left=.065,right=.82,top=.945,bottom=.06 if rows<=3 else .022,hspace=1.05,wspace=1.8)
    for ax,c in zip(axes.flat,cards):draw(ax,c)
    for ax in list(axes.flat)[len(cards):]:ax.axis('off')
    save(fig,stem)
def full_timing_poster(cards):
    columns=4; chunk=math.ceil(len(cards)/columns)
    fig,axes=plt.subplots(1,columns,figsize=(28,chunk*.56+.9))
    fig.subplots_adjust(left=.02,right=.98,top=.995,bottom=.005,wspace=.055)
    for col,ax in enumerate(axes):
        part=cards[col*chunk:(col+1)*chunk]; ax.set_xlim(0,1);ax.set_ylim(chunk,0);ax.axis('off')
        for row,c in enumerate(part):
            ax.axhspan(row+.03,row+.98,color='#f4f7fa' if row%2==0 else 'white',zorder=0)
            label=('Entities · ' if c['dataset'].endswith('-entities') else '')+c['title'].replace('\n',' ')
            ax.text(.02,row+.10,'\n'.join(textwrap.wrap(label,70)),va='top',fontsize=7.2,fontweight='bold',linespacing=1.1)
            ref=next(s['median'] for s in c['series'] if s['framework']==c['reference'])
            segments=[]
            for s in c['series']:
                value=number(s['median'])
                if s['framework']!=c['reference']:value+=' ('+gap((s['median']/ref-1)*100)+')'
                segments.append(NAMES[s['framework']]+' '+value)
            ax.text(.02,row+.67,' · '.join(segments)+' '+c['unit'],va='center',fontsize=7,
                    color='#137e59' if all(s['median']>=ref for s in c['series']) else '#a44955')
    save(fig,'comparison-complete',dpi=150)

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    entities=entity_cards(); original=native_cards('original');packed=native_cards('packed');indexed=native_cards('indexed')
    memory=memory_cards(); all_timing=entities+original+packed+indexed;assert len(all_timing)==850
    compact=[next(c for c in entities if c['key']==base+'/65536') for base in FRIENDLY if base!='BM_CreateNoEntities']
    poster(compact,'comparison');poster(entities,'comparison-all-entities');full_timing_poster(all_timing)
    dependency=dependency_cards();registry=registry_cards()
    poster(dependency,'kama-update');poster(registry,'concurrent-registry')
    for card in all_timing+memory+dependency+registry:remember(card)
    with PdfPages(OUT/'complete-benchmark-atlas.pdf') as pdf:
        for name,cards in [('Entities',entities),('Original C',original),('Packed C',packed),('Indexed C',indexed),('Memory',memory)]:
            for start in range(0,len(cards),12):
                part=cards[start:start+12];fig,axes=plt.subplots(4,3,figsize=(19,13.5))
                fig.subplots_adjust(left=.07,right=.82,top=.94,bottom=.04,hspace=1.1,wspace=1.7)
                for ax,card in zip(axes.flat,part):draw(ax,card,True)
                for ax in list(axes.flat)[len(part):]:ax.axis('off')
                pdf.savefig(fig,facecolor='white');plt.close(fig)
                PAGES.append(dict(section=name,cases=[c['key'] for c in part]))
            print(f'Rendered {name}: {len(cards)} cases',flush=True)
    OUTPUTS.append(OUT/'complete-benchmark-atlas.pdf')
    with (OUT/'plotted-values.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,list(PLOTTED[0]));writer.writeheader();writer.writerows(PLOTTED)
    OUTPUTS.append(OUT/'plotted-values.csv');shutil.copy2(__file__,OUT/'plot-source.py')
    provenance=json.loads((ROOT/'provenance.json').read_text())
    meta=dict(cedar=provenance['cedarecs'],kama=provenance['kama'],
        timing_cases=850,memory_plots=len(memory),pages=PAGES,plotted_series=len(PLOTTED),
        inputs={str(p.relative_to(ROOT)):digest(p) for p in sorted(INPUTS)},
        outputs={p.name:digest(p) for p in OUTPUTS},script_sha256=digest(Path(__file__)),
        encoding='Timing panels plot signed percentage time differences against Cedar on explicitly labeled symlog axes (linear threshold 0.1 percentage point). Exact absolute medians and signed gaps are printed. No truncated absolute bars. Memory axes are ordinary linear MiB delta axes. Full timing PNG/SVG/PDF is a complete numeric comparison table, including every loss. N=entities, T=threads. No cases selected by outcome. Compact subset is the predeclared nine entity operations at the largest input setting.')
    (OUT/'provenance.json').write_text(json.dumps(meta,indent=2)+'\n')
    print('Generated minimal comparisons and complete atlas',flush=True)
if __name__=='__main__': main()
