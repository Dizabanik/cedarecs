#!/usr/bin/env python3
"""Bundle the reviewed exports and underlying datasets for sharing."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parents[1]
out=ROOT/'promotion/cedar-ecs-comparison-kit-v53.zip'
files={}
for folder,stems in [(ROOT/'promotion/checked-v53',('cedar-scorecard','cedar-all-entity-cases','cedar-c-workloads')),
                     (ROOT/'results/memory-v1',('memory-comparison','memory-lifetime'))]:
    for stem in stems:
        for ext in ('png','svg','pdf'):
            p=folder/(stem+'.'+ext);files['figures/'+p.name]=p
files['data/entity-speedups.csv']=ROOT/'promotion/checked-v53/entity-speedups.csv'
for name,label in [('multi-ecs-checked-final-v53','entities'),('checked-final-v53-original','original-c'),
                   ('checked-final-v53-packed','packed-c'),('checked-final-v53-slots','indexed-c'),('memory-v1','memory')]:
    for file in ('summary.csv','metadata.json','raw.jsonl'):
        files['data/'+label+'-'+file]=ROOT/'results'/name/file
files['data/performance-figure-provenance.json']=ROOT/'promotion/checked-v53/provenance.json'
files['data/memory-figure-provenance.json']=ROOT/'results/memory-v1/figure-provenance.json'
files['methodology/memory.md']=ROOT/'bench/memory/README.md'
files['scripts/promotion.py']=ROOT/'bench/promotion.py'
files['scripts/memory-report.py']=ROOT/'bench/memory/report.py'
readme='''# Cedar ECS comparison kit

Five figures, each exported as PNG, editable SVG and vector PDF:

- `figures/cedar-scorecard`: the compact announcement graphic, 83 median wins
  across 84 entity matchups against EnTT, pico_ecs and Flecs.
- `figures/cedar-all-entity-cases`: every one of the 28 × 3 measured speed ratios.
- `figures/cedar-c-workloads`: all expanded C families, with fixed packed and
  indexed policies reported separately.
- `figures/memory-comparison`: every memory scenario at the largest population.
- `figures/memory-lifetime`: live allocations and physical footprint before and
  after deletion/destruction.

The entity speedups (geometric means, every case equally weighted) are 2.30×
against EnTT, 1.34× against pico_ecs and 8.22× against Flecs. Cedar reads remain
checked. Nine independent process rounds, 30 ms target; Apple M4 Pro / macOS.
Native timing boundaries include teardown. Addition timing is dominated by
timer pause/resume; three pico additions have overlapping IQRs. These are
one-host benchmark results, not total application throughput or universal wins.
The expanded C suite uses wall time and a different Flecs development pin;
its 386 cases keep their explicit grains. The original 50-case frame adapter
opts into Cedar automatic batching uniformly.

The memory suite completed 850 fresh Release processes and 4,075 checkpoints,
with five serial repetitions per backend/case. Both Cedar storage policies,
EnTT, pico_ecs and Flecs process identical initialized 16/16/256-byte components.
At 262,144 entities, packed Cedar uses 50.2% less live heap than Flecs in the
dense-payload case and 82.1% less than pico_ecs with 1% payloads. EnTT is leaner
in several other cases; indexed Cedar has a sparse-component capacity cost.
Live malloc allocations returned to baseline after destruction in every tested
Release process. Resident allocator pages can remain; heap and physical
footprint are distinct. Release and ASan/UBSan correctness smokes each passed
115 fresh processes / 550 checkpoints. Sanitized memory usage is excluded.

`data/` retains all five datasets' summary CSVs, raw JSONL and metadata (pins,
compiler flags, sample counts, binary/source hashes). Case-level speedups are
also exported separately. `manifest.json` hashes every bundled file. The two
figure-provenance files preserve original project paths; bundled data names
carry a dataset prefix. `scripts/` contains the plot calculations, intended to
run in the original project checkout with its retained data.

Engine snapshot: checked-final-v53,
09892f998d7e7cb385ace73cca3a4e9b1df898345d6c6687f92db77c77dcb28b.
No engine implementation or historical timing was changed to produce the kit.
'''
contents={name:p.read_bytes() for name,p in files.items()}
contents['README.md']=readme.encode()
manifest=dict(created_utc=datetime.now(timezone.utc).isoformat(),
              files={name:hashlib.sha256(data).hexdigest() for name,data in sorted(contents.items())})
with zipfile.ZipFile(out,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=8) as z:
    for name,data in contents.items():z.writestr('cedar-ecs-comparison-kit/'+name,data)
    z.writestr('cedar-ecs-comparison-kit/manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None
    for name,h in manifest['files'].items():assert hashlib.sha256(z.read('cedar-ecs-comparison-kit/'+name)).hexdigest()==h
print('Verified comparison kit:',out,f'({out.stat().st_size/1048576:.2f} MiB)')
