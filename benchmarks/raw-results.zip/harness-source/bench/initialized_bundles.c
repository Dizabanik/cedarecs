#include <cedarecs/cedar.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#ifndef PAYLOAD_BYTES
#define PAYLOAD_BYTES 16
#endif
typedef struct PartA {
#if PAYLOAD_BYTES >= 512
    _Alignas(64)
#endif
    uint64_t words[PAYLOAD_BYTES / 8];
} PartA;
typedef struct PartB {
#if PAYLOAD_BYTES >= 512
    _Alignas(64)
#endif
    uint64_t words[PAYLOAD_BYTES / 8];
} PartB;
ced_slots_def(PartA, PartB, Marker)
ced_define_bundle(BenchBundle, (PartA, a), (PartB, b), ced_bundle_tag(Marker))
static void check(bool ok) { if (!ok) abort(); }
static uint64_t now(void) {
    struct timespec t;
#ifdef CLOCK_MONOTONIC_RAW
    check(clock_gettime(CLOCK_MONOTONIC_RAW, &t) == 0);
#else
    check(clock_gettime(CLOCK_MONOTONIC, &t) == 0);
#endif
    return (uint64_t)t.tv_sec * UINT64_C(1000000000) + (uint64_t)t.tv_nsec;
}

// Select a complete loop outside timing; no per-entity benchmark dispatch.
static void old_plan(ced_World *w, const BenchBundle_Plan *plan, BenchBundle *value,
                     ced_Entity *entities, size_t n, bool reverse) {
    const void *values[] = {reverse ? (void *)&value->b : (void *)&value->a,
                           reverse ? (void *)&value->a : (void *)&value->b, NULL};
    for (size_t i = 0; i < n; ++i) {
        value->a.words[0] = i;
        entities[i] = ced_entity_from_plan_values(w, &plan->_impl._spawn, values);
    }
}
static void new_plan(ced_World *w, const BenchBundle_Plan *plan, BenchBundle *value,
                     ced_Entity *entities, size_t n, bool reverse) {
    (void)reverse;
    for (size_t i = 0; i < n; ++i) {
        value->a.words[0] = i;
        entities[i] = BenchBundle_spawn(w, plan, value);
    }
}
static void old_one_shot(ced_World *w, const BenchBundle_Plan *plan, BenchBundle *value,
                         ced_Entity *entities, size_t n, bool reverse) {
    (void)plan; (void)reverse;
    for (size_t i = 0; i < n; ++i) {
        value->a.words[0] = i;
        entities[i] = ced_spawn(w, PartA, PartB, Marker);
        check(ced_set_ptr(w, entities[i], PartA, &value->a));
        check(ced_set_ptr(w, entities[i], PartB, &value->b));
    }
}
static void new_one_shot(ced_World *w, const BenchBundle_Plan *plan, BenchBundle *value,
                         ced_Entity *entities, size_t n, bool reverse) {
    (void)plan; (void)reverse;
    for (size_t i = 0; i < n; ++i) {
        value->a.words[0] = i;
        entities[i] = ced_spawn_with(w, ced_value_ptr(PartA, &value->a),
            ced_value_ptr(PartB, &value->b), ced_tag(Marker));
    }
}
int main(int argc, char **argv) {
    if (argc != 7) return 2;
    bool indexed = atoi(argv[1]) != 0;
    size_t n = strtoull(argv[2], NULL, 10);
    bool reverse = atoi(argv[3]) != 0;
    int kind = atoi(argv[4]); // 0 raw prepared; 1 bundle; 2 old one-shot; 3 initialized one-shot
    bool reserved = atoi(argv[5]) != 0;
    size_t passes = strtoull(argv[6], NULL, 10);
    if (!n || n > 1000000 || kind < 0 || kind > 3 || !passes || passes > 32) return 2;
    ced_Entity *entities = malloc(n * sizeof(*entities));
    check(entities != NULL);
    for (size_t i = 0; i < n; ++i) ((volatile ced_Entity *)entities)[i] = 0;
    ced_World *w = indexed ? ced_init_indexed() : ced_init();
    if (reverse) { ced_slot_init(w, PartB); ced_slot_init(w, PartA); }
    else { ced_slot_init(w, PartA); ced_slot_init(w, PartB); }
    ced_tag_init(w, Marker);
    BenchBundle_Plan plan = {0};
    if (kind < 2 || reserved) {
        plan = BenchBundle_prepare(w);
        check(BenchBundle_valid(w, &plan));
        if (reserved) check(BenchBundle_reserve(w, &plan, n));
    }
    BenchBundle value = {0};
    for (size_t j = 0; j < PAYLOAD_BYTES / 8; ++j) {
        value.a.words[j] = UINT64_C(0x1234abcd00000000) ^ j;
        value.b.words[j] = UINT64_C(0x9541c83200000000) ^ j;
    }
    void (*loop)(ced_World *, const BenchBundle_Plan *, BenchBundle *, ced_Entity *, size_t, bool) =
        kind == 0 ? old_plan : kind == 1 ? new_plan : kind == 2 ? old_one_shot : new_one_shot;
    uint64_t elapsed = 0, checksum = 0;
    for (size_t pass = 0; pass < passes; ++pass) {
        value.b.words[0] = pass;
        uint64_t begin = now();
        loop(w, &plan, &value, entities, n, reverse);
        elapsed += now() - begin;
        check(ced_alive_count(w) == n);
        for (size_t i = 0; i < n; ++i) {
            const PartA *a = ced_get_const(w, entities[i], PartA);
            const PartB *b = ced_get_const(w, entities[i], PartB);
            check(a && b && ced_has(w, entities[i], Marker));
            check(a->words[0] == i && b->words[0] == pass);
            for (size_t j = 1; j < PAYLOAD_BYTES / 8; ++j)
                check(a->words[j] == value.a.words[j] && b->words[j] == value.b.words[j]);
            check(ced_entity_generation(entities[i]) == pass);
            checksum += a->words[0] + b->words[0] + (uint32_t)entities[i];
        }
        for (size_t i = 0; i < n; ++i) ced_kill(w, entities[i]);
        check(!ced_alive_count(w));
    }
    printf("{\"bytes\":%d,\"indexed\":%s,\"entities\":%zu,\"reverse\":%s,\"kind\":%d,\"reserved\":%s,\"passes\":%zu,\"checksum\":%llu,\"ns_per_entity\":%.9f}\n",
        PAYLOAD_BYTES, indexed ? "true" : "false", n, reverse ? "true" : "false", kind,
        reserved ? "true" : "false", passes, (unsigned long long)checksum, (double)elapsed / (n * passes));
    ced_drop(w);
    free(entities);
}
