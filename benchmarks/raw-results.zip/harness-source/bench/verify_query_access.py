#!/usr/bin/env python3
"""Audit the measured v16 source, workload, competitor and result identities."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def meta(name):
    return json.loads((ROOT/'results'/name/'metadata.json').read_text())

def audit(command):
    subprocess.run(['python3',str(ROOT/'bench'/command[0]),str(ROOT/'results'/command[1])],check=True)

for script,name in [('validate_results.py','query-access-v16-original'),
                    ('expanded/validate.py','query-access-v16-expanded'),
                    ('expanded/validate.py','query-access-v16-sustained'),
                    ('expanded/validate.py','deferred-spawn-v15-targeted')]:
    audit((script,name))
for name in ('multi-ecs-deferred-spawn-v15','multi-ecs-query-access-v16'):
    subprocess.run(['python3',str(ROOT/'interop/abeimler/validate.py'),str(ROOT/'results'/name)],check=True)
    m=meta(name)
    for name,h in m['adapter_sha256'].items():
        assert digest(ROOT/'results'/('multi-ecs-deferred-spawn-v15' if m['cedar']['label']=='deferred-spawn-v15' else 'multi-ecs-query-access-v16')/'source'/name)==h

manifest=json.loads((ROOT/'provenance.json').read_text())
assert manifest['cedarecs']['label']=='query-access-v16'
for name,h in manifest['cedarecs']['files'].items():
    assert digest(ROOT/name)==h
for file in (ROOT/'variants/baseline/cedarecs').rglob('*'):
    if file.is_file():
        assert file.read_bytes()==(ROOT.parent/'include/cedarecs'/file.relative_to(ROOT/'variants/baseline/cedarecs')).read_bytes()
for name in ('workloads.inc','kernel.c','main.c','flecs_backend.c','bench.h'):
    assert (ROOT/'bench'/name).read_bytes()==(ROOT/'variants/baseline'/name).read_bytes()
assert digest(ROOT/'kama/kama.h')==manifest['kama']['header_sha256']
assert not subprocess.check_output(['git','-C',str(ROOT/'flecs'),'status','--porcelain'],text=True).strip()
assert subprocess.check_output(['git','-C',str(ROOT/'flecs'),'rev-parse','HEAD'],text=True).strip()==manifest['flecs']['commit']
old=meta('expanded-confirmation-20261026')
current=meta('query-access-v16-expanded')
sustained=meta('query-access-v16-sustained')
assert current['binaries_sha256']==sustained['binaries_sha256']
assert old['binaries_sha256']['flecs']==current['binaries_sha256']['flecs']
assert old['kernel_object_sha256']==current['kernel_object_sha256']==sustained['kernel_object_sha256']
for name,h in old['harness_sha256'].items():
    if name in ('bench/expanded/catalog.py','bench/expanded/flecs.c','bench/expanded/kernels.c',
                'bench/expanded/main.c','bench/expanded/suite.h','bench/expanded/workloads.inc',
                'bench/bench.h','bench/run.py'):
        assert current['harness_sha256'][name]==h,name
for run in ('query-access-v16-expanded','query-access-v16-sustained','deferred-spawn-v15-targeted'):
    for name,h in meta(run)['harness_sha256'].items():
        assert digest(ROOT/'results'/run/'source'/name)==h,(run,name)
prior=meta('multi-ecs-20261026')
new=meta('multi-ecs-query-access-v16')
for name in ('entt','pico','flecs'):
    assert prior['binary_sha256'][name]==new['binary_sha256'][name]
    assert digest(ROOT/'build/interop'/(name+'-entities'))==new['binary_sha256'][name]
assert digest(ROOT/'build/interop/cedar-entities')==new['binary_sha256']['cedar']
assert new['cedar']['snapshot_sha256']==manifest['cedarecs']['snapshot_sha256']
for name,path in [('cedarecs',ROOT/'build/expanded/cedarecs'),('flecs',ROOT/'build/expanded/flecs')]:
    assert digest(path)==current['binaries_sha256'][name]
fig=json.loads((ROOT/'results/query-access-v16-expanded/entity-plot-metadata.json').read_text())
for name,h in fig['inputs'].items():
    assert digest(ROOT/name)==h
for name,h in fig['outputs'].items():
    assert digest(ROOT/'results/query-access-v16-expanded'/name)==h
validation=ROOT/'validation/query-access-v16'
checks=(validation/'checks.log').read_text()
assert 'ECS tests passed' in checks and '100% tests passed' in checks
assert 'Expanded smoke passed: 374' in checks and 'Expanded smoke passed: 12' in checks
assert 'C/C++ bridge and inline access ASan/UBSan passed' in (validation/'interop-sanitize.log').read_text()
record=dict(verified_utc=datetime.now(timezone.utc).isoformat(),
    cedar_snapshot=manifest['cedarecs']['snapshot_sha256'],
    production_equals_initial_baseline=True,
    original_five_workload_and_flecs_files_unchanged=True,
    expanded_workload_catalog_kernel_driver_and_flecs_adapter_unchanged=True,
    shared_kernel_and_flecs_executables_unchanged=True,
    entt_pico_flecs_reference_executables_unchanged=True,
    primary_and_sustained_use_identical_executables=True,
    all_retained_results_recomputed_and_audited=True,
    measured_adapters_and_harness_archives_verified=True,
    new_final_c_samples=900+6948+1530,new_final_four_framework_samples=560,
    intermediate_samples=2214+560,
    checks='ASan/UBSan core and expanded suite both engines; Cedar TSan core/producers/worker commands; 65/320 component configs; spin disabled; C++20 bridge and inline reads with ASan/UBSan',
    prior_unresolved_diagnostic='Flecs development native pipeline/query paths report TSan races; retained separately; no suppressions or external patches',
    test_source_sha256={str(p.relative_to(ROOT)):digest(p) for p in sorted((ROOT/'tests').glob('*')) if p.is_file()},
    evidence_sha256={p.name:digest(p) for p in sorted(validation.glob('*.log')) if p.name!='audit.log'})
(validation/'verification.json').write_text(json.dumps(record,indent=2)+'\n')
print('Verified source manifests, fixed workloads, compiled kernels, all competitor binaries, archives, plots and retained results.')
