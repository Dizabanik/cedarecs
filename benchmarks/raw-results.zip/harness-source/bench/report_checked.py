#!/usr/bin/env python3
"""Report the final checked candidate, floors, tradeoffs and all retained probes."""
import csv
import json
from pathlib import Path
from report_memory_access import stats

ROOT = Path(__file__).resolve().parents[1]
PREFIX = 'checked-final-v53'


def rows(run):
    return list(csv.DictReader((ROOT/'results'/run/'summary.csv').open()))


def main():
    gate = json.loads((ROOT/'validation'/PREFIX/'acceptance.json').read_text())
    entity = rows('multi-ecs-'+PREFIX)
    text = ['# Checked ECS optimization and acceptance', '',
            ('All six requested performance floors pass.' if gate['all_passed'] else 'The requested performance floors are not all satisfied.'), '',
            'These are complete retained runs with checked full 64-bit generational handles. Case wins use lower medians, not selected variants or selected samples. Both storage policies and all original cases are reported separately.', '',
            '| Dataset | Required floor | Final wins | Status |', '| --- | ---: | ---: | --- |']
    for name, g in gate['gates'].items():
        text.append(f"| {name} | {g['minimum']}/{g['cases']} | {g['wins']}/{g['cases']} | {'pass' if g['passed'] else 'FAIL'} |")
    text += ['', '## Measurement scope', '',
             'The entity integration uses nine independent process rounds per framework and a 30 ms Google Benchmark target: 28 cases and 1,008 samples. Original C: 50 cases/900 samples. Expanded C: 386 cases/6,948 samples per fixed storage policy. Framework order rotates or alternates. The benchmark binary reports its compiled checked-read contract and Cedar source hash; the runner rejects mismatches.', '',
             'The original native frame adapter now opts uniformly into the public `ced_parallel_each_auto` API. Its earlier hardcoded 1,024-row grain was an adapter choice. Automatic batching permits larger callbacks; the shared kernels, entity updates and checksums are unchanged. The explicit maximum-grain API is retained, and the expanded 386-case adapter, including every explicit grain parameter, is byte-identical to v42. This scheduling choice is part of the original-suite improvement and must not be described as a comparison with identical batch boundaries.', '',
             'All native EnTT, pico_ecs and Flecs executables, upstream templates and shared C kernels remain unchanged. The entity integration retains EnTT 3.13.2, the compatible 2024 pico pin and Flecs 4.0.1; the C comparison retains its separate Flecs development pin. This is one Apple M4 Pro/macOS host, not a universal ranking or validation of every ECS feature/platform.', '',
             '## Checked entity comparison', '',
             '| Competitor | Previous v42 wins | Final wins | Cedar disjoint IQR | Competitor disjoint IQR | Overlap |',
             '| --- | ---: | ---: | ---: | ---: | ---: |']
    previous = rows('multi-ecs-memory-access-v42')
    for framework in ('entt','pico','flecs'):
        w,a,b,o = stats(entity,framework)
        text.append(f'| {framework} | {stats(previous,framework)[0]}/28 | {w}/28 | {a} | {b} | {o} |')
    text += ['', 'Disjoint IQR describes observed spread, not a significance test. The addition case pauses/resumes its timer for every entity; timer cost dominates close differences. pico_ecs retains its native Release getter, whose assertions compile out and which directly computes a slot address. Cedar still checks bounds, presence and complete generation. The explicit known-live Cedar target is tested separately and is not used in these scores.', '',
             '| Remaining entity loss | Case | Cedar / competitor median |', '| --- | --- | ---: |']
    for f in ('entt','pico','flecs'):
        for r in entity:
            ratio=float(r['cedar_cpu_median_ns'])/float(r[f+'_cpu_median_ns'])
            if ratio >= 1: text.append(f"| {f} | {r['benchmark']} | {ratio:.3f} |")
    text += ['', '## C comparisons', '', 'The original floor uses v25 (46/50); the immediate previous v42 run was 42/50. Expanded floors use v42.', '',
             '| Dataset | Previous wins | Final wins | Cedar disjoint IQR | Flecs disjoint IQR | Overlap |',
             '| --- | ---: | ---: | ---: | ---: | ---: |']
    for label,old,new in [('Original','indexed-v25-original',PREFIX+'-original'),('Packed','memory-access-v42-packed',PREFIX+'-packed'),('Indexed','memory-access-v42-slots',PREFIX+'-slots')]:
        data=rows(new);w,a,b,o=stats(data,'flecs','cedarecs',False)
        text.append(f"| {label} | {stats(rows(old),'flecs','cedarecs',False)[0]}/{len(data)} | {w}/{len(data)} | {a} | {b} | {o} |")
    text += ['', '![Every expanded packed case](results/'+PREFIX+'-packed/before-after.png)', '',
             '### Individual timing regressions', '',
             'Passing case floors does not mean every individual timing improves. Below are the largest Cedar median increases against v42 in the unchanged explicit-grain expanded packed dataset. Both paired Flecs medians are included because separate-run hardware effects also vary. Complete CSVs retain all other rows.', '',
             '| Case | v42 Cedar ns/op | Final Cedar | v42 Flecs | Final Flecs | Cedar ratio |',
             '| --- | ---: | ---: | ---: | ---: | ---: |']
    before={r['case']:r for r in rows('memory-access-v42-packed')}
    packed=rows(PREFIX+'-packed')
    ordered=sorted(packed,key=lambda r:float(r['cedarecs_median_ns'])/float(before[r['case']]['cedarecs_median_ns']),reverse=True)
    for r in ordered[:10]:
        old=before[r['case']];ratio=float(r['cedarecs_median_ns'])/float(old['cedarecs_median_ns'])
        text.append(f"| {r['case']} | {float(old['cedarecs_median_ns']):.3f} | {float(r['cedarecs_median_ns']):.3f} | {float(old['flecs_median_ns']):.3f} | {float(r['flecs_median_ns']):.3f} | {ratio:.2f}x |")
    text += ['', '## Retained changes and safety', '',
             '- Checked typed readers hold tracked allocation snapshots. Growth refreshes them; copy/move/assignment re-link registrations; world destruction invalidates them. Const reader objects use mutable internal metadata. Raw borrowed pointers still expire normally.',
             '- The C++ factory uses the idempotent checked add operation, preserving existing values. An explicit preparation API remains available, but eager preparation was removed from the factory after it increased teardown cost without improving additions.',
             '- Small packed archetypes retain ordinary allocation and per-row clearing; wide signatures use bulk zeroing and a dirty-row boundary. Column starts are cache-line spaced, rounded to both component alignment and the configured minimum. True allocation bases are retained for resize/free.',
             '- Iterators snapshot stable match metadata. Batch field bounds come from validated immutable query arity; NULL and ordinal checks remain. Counts fit the existing 32-bit world entity-index limit.',
             '- Stable serial dispatch caches complete batches and bound fields. Structural/grain changes invalidate them; changing workloads use the ordinary binding path. Explicit grain limits and deferred-command completion remain intact.',
             '- Automatic batching is a separate opt-in API. It shares the normal dispatch validation, active-writer exclusion, worker synchronization and flush path. The expanded suite keeps explicit grain settings.', '',
             'Tradeoffs include larger tracked-reader objects, synchronized registration, extra query batch metadata, true-base pointer arrays and cache-line padding rounded to alignment. Indexed storage still allocates through world slot capacity and remains weak for fragmented queries. Exposed experimental layouts changed and require a rebuild.', '',
             'See the [invariant and test matrix](CHECKED_INVARIANTS.md). Core ASan/UBSan/TSan, 65/320-component configurations, parking-only workers, portable memory operations and 256-byte column alignment pass. Tracked access passes full C/C++ ASan/UBSan and TSan, including concurrent registration and world invalidation. Ten invalid required reads abort in optimized NDEBUG builds; no return or segmentation fault is accepted as a passing check. Expanded release/sanitizer smokes and Cedar worker-command TSan checks cover both storage policies.', '',
             '## Retained experiments', '',
             'Short probes and unfavorable confirmations are preserved. They are not substituted into the final table.', '',
             '| Variant | Rounds | EnTT wins | pico wins | Flecs wins |', '| --- | ---: | ---: | ---: | ---: |']
    for run in sorted((ROOT/'results').glob('multi-ecs-*')):
        p=run/'metadata.json'
        if not p.exists() or not (run/'summary.csv').exists():continue
        m=json.loads(p.read_text());label=m.get('cedar',{}).get('label','');version=label.rsplit('-v',1)[-1]
        if version.isdigit() and int(version)>=43:
            data=rows(run.name)
            text.append(f"| {label} | {m['repeats']} | "+' | '.join(str(stats(data,f)[0]) for f in ('entt','pico','flecs'))+' |')
    text += ['', 'The failed initialization and shifted-pointer-free variants were rejected before timing, retained as `rejected-packing-v44` and `rejected-color-v49`. Their diagnostics remain in validation logs. No test assertion was relaxed to accept either defect.', '',
             'The later `packed-count-v54` experiment replaced adjacent batch-count stores with one byte-copy update. Its nine-round, 61-case packed frame probe passed core ASan/UBSan but did not consistently resolve the small-grain regressions. It recorded 44/61 median wins versus v53\'s 42/61 frame wins, alongside large timing outliers; this focused result does not establish the six full-suite floors. The experiment was rejected and the exact measured v53 source and binaries restored. Its [complete probe](results/packed-count-v54-frames/comparison.md), source snapshot and validation logs remain retained.', '',
             'Production `include/cedarecs/` remains equal to the initial source baseline. The audit verifies source manifests, archived adapters, compiler read-mode markers, fixed workloads/kernels and all competing binary hashes. Earlier Flecs development pipeline TSan diagnostics remain separately retained and unresolved; competitor code and suppressions were not changed.', '',
             'Evidence: [acceptance floors](validation/'+PREFIX+'/acceptance.json), [source and correctness audit](validation/'+PREFIX+'/verification.json), [entity CSV](results/multi-ecs-'+PREFIX+'/summary.csv), [original C](results/'+PREFIX+'-original/comparison.md), [packed C](results/'+PREFIX+'-packed/comparison.md), [indexed C](results/'+PREFIX+'-slots/comparison.md).', '']
    (ROOT/'OPTIMIZATIONS_CHECKED.md').write_text('\n'.join(text))
    print('Wrote OPTIMIZATIONS_CHECKED.md')


if __name__=='__main__':main()
