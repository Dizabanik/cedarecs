"""Fresh complete C suite: old Cedar, updated Cedar and unchanged Flecs workloads."""
import argparse
import csv
from datetime import datetime,timezone
import hashlib
import json
import math
import os
from pathlib import Path
import random
import shutil
import statistics
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'bench/expanded'))
from catalog import DEFAULTS,SINGLE_PASS
p=argparse.ArgumentParser();p.add_argument('--suite',choices=('original','packed','indexed'),required=True)
p.add_argument('--output',type=Path,required=True);p.add_argument('--repeats',type=int,default=9)
p.add_argument('--target-ms',type=float,default=20)
p.add_argument('--max-operations',type=int,default=500000000)
p.add_argument('--build-root',type=Path,default=ROOT/'build/kama-v107-paired')
args=p.parse_args(); assert args.repeats>=5
build=args.build_root.resolve(); out=args.output.resolve();out.mkdir(parents=True,exist_ok=False)
current=json.loads((ROOT/'provenance.json').read_text())
for name,h in current['cedarecs']['files'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==h
old=json.loads((build/'baseline/manifest.json').read_text())
candidate=json.loads((build/'candidate/manifest.json').read_text())
assert candidate['engine']['snapshot_sha256']==current['cedarecs']['snapshot_sha256']
for field in ('timer','shared_clocks','shared_kernels'):assert old[field]==candidate[field]
assert candidate['timer']=='CLOCK_MONOTONIC_RAW'
reference=ROOT/'results'/('checked-final-v53-'+dict(original='original',packed='packed',indexed='slots')[args.suite])/'summary.csv'
jobs=list(csv.DictReader(reference.open()))
versions={'before':old['engine']['snapshot_sha256'],'cedar':candidate['engine']['snapshot_sha256'],'flecs':current['flecs']['commit']}
binaries={}
for (key,path),letter in zip([('before',build/'baseline'/args.suite),('cedar',build/'candidate'/args.suite),
             ('flecs',build/'references'/('original' if args.suite=='original' else 'expanded'))],'abc'):
    binaries[key]=out/('engine-'+letter);shutil.copy2(path,binaries[key])
    manifest=(old if key=='before' else candidate) if key!='flecs' else json.loads((build/'references/build.json').read_text())
    expected=manifest['binaries'][args.suite if key!='flecs' else ('original' if args.suite=='original' else 'expanded')]
    assert hashlib.sha256(binaries[key].read_bytes()).hexdigest()==expected
shutil.copy2(__file__,out/'runner.py')
meta=dict(suite=args.suite,repeats=args.repeats,target_ms=args.target_ms,max_operations=args.max_operations,started_utc=datetime.now(timezone.utc).isoformat(),
          cedar=current['cedarecs'],kama=current['kama'],versions=versions,timer='CLOCK_MONOTONIC_RAW',
          binaries={k:hashlib.sha256(v.read_bytes()).hexdigest() for k,v in binaries.items()},
          shared_harness=json.loads((build/'build.json').read_text()),
          reference_build=json.loads((build/'references/build.json').read_text()),
          methodology='Every retained input configuration; old Cedar/current Cedar/Flecs run sequentially, equal-length copied paths, rotated/reversed order and crossed environment paddings. Two discarded warmups per method/case. Identical operation counts and checksums; shared frozen kernels and one generated main object per suite. Any bounded iteration-limit change is recorded in the shared harness manifest. Adaptive untimed calibration targets the fastest implementation. No sample deletion.')
(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
def execute(key,row,iterations,pad=0):
    command=[str(binaries[key]),row['scenario']]
    if args.suite=='original':command += [row['entities'],str(iterations),row['threads']]
    else:
        for field in DEFAULTS:command += ['--'+field,row[field]]
        command += ['--iterations',str(iterations)]
    r=subprocess.run(command,check=True,capture_output=True,text=True,timeout=240,
                     env=dict(os.environ,LC_ALL='C',CEDAR_BENCH_STACK_PAD='x'*pad))
    assert not r.stderr,r.stderr
    result=json.loads(r.stdout);assert result['version']==versions[key]
    if args.suite!='original':assert all(result[field]==int(row[field]) for field in DEFAULTS)
    return result
def parity(results):
    for field in ('scenario','entities','iterations','threads','operations','checksum'):
        assert len({r[field] for r in results})==1,(field,results)
    if args.suite!='original':
        for field in ('matched','unit'):assert len({r[field] for r in results})==1,(field,results)
random.Random(0x106).shuffle(jobs);summary=[]
iteration_limit=100000 if args.suite=='original' else candidate['shared_clocks']['expanded'].get('max_iterations',10000)
meta['max_iterations']=iteration_limit
(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
calibration=[]
with (out/'raw.jsonl').open('w') as log:
    for index,row in enumerate(jobs):
        case=row.get('case') or row['scenario']+'/entities='+row['entities']+',threads='+row['threads']
        single=row['scenario'] in ({'create_empty','create_pv','delete_pv'} if args.suite=='original' else SINGLE_PASS)
        iterations=1
        for attempt in range(6):
            pilot=[execute(k,row,iterations) for k in binaries];parity(pilot)
            calibration.append(dict(case=case,attempt=attempt,results=pilot))
            if single:break
            elapsed=min(r['elapsed_ns'] for r in pilot)
            per_iteration=max(1,pilot[0]['operations']//iterations)
            desired=max(1,min(iteration_limit,args.max_operations//per_iteration,
                math.ceil(iterations*args.target_ms*1e6/max(1,elapsed))))
            if elapsed>=args.target_ms*1e6*.75 or desired==iterations:break
            iterations=desired
        samples={k:[] for k in binaries}
        for trial in range(-2,args.repeats):
            keys=list(binaries);order=keys[trial%3:]+keys[:trial%3]
            if trial%2:order.reverse()
            result=[]
            for position,key in enumerate(order):
                r=execute(key,row,iterations,(max(trial,0)%8)*16); result.append(r)
                if trial>=0:
                    samples[key].append(r['ns_per_op'])
                    log.write(json.dumps(dict(case=case,framework=key,trial=trial,position=position,**r))+'\n')
            parity(result)
        output=dict(case=case,**{k:row[k] for k in row if k!='case'},measured_iterations=iterations)
        for key,values in samples.items():
            q=statistics.quantiles(values,n=4,method='inclusive')
            output.update({key+'_median_ns':statistics.median(values),key+'_p25_ns':q[0],key+'_p75_ns':q[2]})
        output['flecs_over_cedar']=output['flecs_median_ns']/output['cedar_median_ns']
        output['cedar_over_before']=output['cedar_median_ns']/output['before_median_ns']
        summary.append(output); log.flush()
        print(f"{index+1}/{len(jobs)} {case}: vs before {output['cedar_over_before']:.3f}; Flecs/Cedar {output['flecs_over_cedar']:.3f}",flush=True)
        with (out/'summary.csv').open('w',newline='') as f:
            w=csv.DictWriter(f,list(summary[0]));w.writeheader();w.writerows(summary)
meta.update(completed_utc=datetime.now(timezone.utc).isoformat(),cases=len(jobs),
            wins=sum(r['flecs_over_cedar']>1 for r in summary),
            above_four_percent=[r for r in summary if r['cedar_over_before']>1.04])
(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
(out/'calibration.json').write_text(json.dumps(calibration,indent=2)+'\n')
print(f"Completed {len(jobs)}; Cedar/Flecs wins {meta['wins']}; {len(meta['above_four_percent'])} medians above 4% versus before",flush=True)
