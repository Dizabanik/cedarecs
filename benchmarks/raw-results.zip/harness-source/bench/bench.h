#ifndef NT_ECS_BENCH_H
#define NT_ECS_BENCH_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

typedef struct Position { float x, y, z, w; } Position;
typedef struct Velocity { float x, y, z, w; } Velocity;
typedef struct Health { uint64_t value; } Health;
typedef uint64_t Entity;

typedef struct Config {
    const char *scenario;
    size_t entities, iterations, threads;
} Config;
typedef struct Result {
    uint64_t elapsed_ns, operations, checksum;
    size_t archetypes;
} Result;

#define CHECK(condition) do { if (!(condition)) { \
    fprintf(stderr, "CHECK failed: %s (%s:%d)\n", #condition, __FILE__, __LINE__); \
    exit(2); \
} } while (0)

static inline Position initial_position(size_t i) {
    return (Position){(float)(i % 1024), (float)(i % 257), (float)(i % 67), 1.0f};
}
static inline Velocity initial_velocity(size_t i) {
    return (Velocity){(float)(i % 7 + 1) * .125f, .25f, .5f, .125f};
}
static inline uint64_t hash_position(uint64_t h, const Position *p) {
    uint32_t bits[4];
    memcpy(bits, p, sizeof(bits));
    for (size_t i = 0; i < 4; i++) { h ^= bits[i]; h *= UINT64_C(1099511628211); }
    return h;
}
void bench_light(Position *restrict p, const Velocity *restrict v, size_t count);
void bench_heavy(Position *restrict p, const Velocity *restrict v, size_t count);
uint64_t bench_now(void);
Result bench_execute(const Config *config);
const char *bench_engine(void);
const char *bench_version(void);
#endif
