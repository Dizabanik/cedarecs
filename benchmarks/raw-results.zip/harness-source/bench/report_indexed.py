#!/usr/bin/env python3
"""Report fixed-policy indexed experiments without merging best-case results."""
import csv
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / 'results'
CHECKED = 'multi-ecs-indexed-initialized-v24'
KNOWN = 'multi-ecs-indexed-known-live-v25'

def rows(run):
    return list(csv.DictReader((RESULTS/run/'summary.csv').open()))

def wins(data, framework):
    return sum(float(r['cedar_cpu_median_ns']) < float(r[framework+'_cpu_median_ns']) for r in data)

def c_counts(data):
    return (sum(float(r['flecs_over_cedar']) > 1 for r in data),
            sum(float(r['cedarecs_p75_ns']) < float(r['flecs_p25_ns']) for r in data),
            sum(float(r['flecs_p75_ns']) < float(r['cedarecs_p25_ns']) for r in data))

checked,known = rows(CHECKED),rows(KNOWN)
old={r['benchmark']:r for r in rows('multi-ecs-query-access-v16')}
raw=[json.loads(s) for s in (RESULTS/CHECKED/'raw.jsonl').read_text().splitlines()]
counts={r['name']:r.get('entities',0) for r in raw}
text=['# Indexed storage and cross-framework optimization', '',
 'The requested approximately 90% case-win rate is reached in the explicitly labeled **known-live required-read mode** of the 28-case upstream entity suite. Checked mode remains below that target against pico_ecs. Neither fixed policy reaches 90% in the broader 386-case C suite. These are separate access contracts and separate runs, retained in full.', '',
 'All common benchmark templates, populations, operation order, and competing framework versions are fixed. Each final entity run uses nine independent process rounds per framework and a 30 ms minimum Google Benchmark target: 1,008 samples per run. Case counts use lower medians and are not a universal ECS score.', '',
 '## Results by access contract', '',
 '| Cedar access mode | EnTT 3.13.2 | pico_ecs (2024 pin) | Flecs 4.0.1 |',
 '| --- | ---: | ---: | ---: |']
for label,data in [('Previous v16 checked',rows('multi-ecs-query-access-v16')),('Indexed checked',checked),('Indexed known-live required reads',known)]:
    text.append('| '+label+' | '+' | '.join(f'{wins(data,k)}/28 ({100*wins(data,k)/28:.1f}%)' for k in ('entt','pico','flecs'))+' |')
text += ['', '| Final mode / competitor | Cedar disjoint IQR | Competitor disjoint IQR | Overlap |',
         '| --- | ---: | ---: | ---: |']
for label,data in [('Checked',checked),('Known-live',known)]:
    for f in ('entt','pico','flecs'):
        a=sum(float(r['cedar_cpu_p75_ns']) < float(r[f+'_cpu_p25_ns']) for r in data)
        b=sum(float(r[f+'_cpu_p75_ns']) < float(r['cedar_cpu_p25_ns']) for r in data)
        text.append(f'| {label} / {f} | {a} | {b} | {len(data)-a-b} |')
text += ['',
 'Checked access validates bounds, component presence and the complete generation. The optional `value_unchecked` method requires the caller to guarantee that the entity is live, owns the component in that world, and remains valid during the read. It is used only for required Position/Velocity reads in the separately built known-live executable. Optional reads, mutations, destruction and the ordinary APIs retain checks. The unchanged upstream setup guarantees these required components exist throughout each read loop.', '',
 'This distinction matters: the pinned pico_ecs `ecs_get` implementation directly computes the component slot address; its liveness/component assertions compile out in Release, and it performs no presence check. That implementation is retained untouched at `build/interop/_deps/pico-src/pico_ecs.h`. The known-live results do not establish 90% wins for Cedar’s checked API.', '',
 '### Shared cases at requested population 1,024', '',
 'CPU ns per reported iterated entity, lower is better. The three-component template iterates 512 of the 1,024 created entities, so its normalization uses 512. Creation/destruction include upstream registry teardown; these timing boundaries differ from the C suite.', '',
 '| Case | v16 Cedar | Indexed checked | Indexed known-live | EnTT | pico_ecs | Flecs |',
 '| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
by_known={r['benchmark']:r for r in known}
for r in checked:
    name=r['benchmark']
    if not name.endswith('/1024'):continue
    n=counts[name]; k=by_known[name]
    values=[float(old[name]['cedar_cpu_median_ns'])/n,float(r['cedar_cpu_median_ns'])/n,
            float(k['cedar_cpu_median_ns'])/n,*[float(r[f+'_cpu_median_ns'])/n for f in ('entt','pico','flecs')]]
    text.append('| '+name.split('/')[0]+' | '+' | '.join(f'{v:.3f}' for v in values)+' |')
text += ['', 'Competitor columns above come from the checked run; the known-live run also measures all three competitors independently. See its complete CSV for that pairing.', '',
 '## Implementation', '',
 '- Add opt-in `ced_init_indexed()` while keeping compact archetype storage as the default. Component payloads occupy entity slots; signature changes update membership without copying retained columns or compacting payload rows.',
 '- Add generation markers per component slot and stable prepared readers. Markers use four bytes rather than eight. The UINT32_MAX generation checks the authoritative record/signature to disambiguate it from an absent marker; the full generation range remains supported.',
 '- Add owner mutation scopes and prepared component bindings. Immediate add/remove remains visible immediately, zeroes newly added data, preserves existing data, and rejects stale handles. Worker dispatch is rejected until all scopes end. C++ typed bindings resolve byte sizes once; `put` avoids redundant zero initialization before an assignment.',
 '- Support regular queries, filters, optional fields, deferred commands, holes/recycled slots and worker dispatch in indexed worlds. Queries expose contiguous matching live runs and share the existing kernels and batch API.',
 '- Coallocate the world, runtime, component metadata, empty signature and small initial arrays. Larger arrays spill to checked heap allocations. Short component names live in stable metadata. Creation processes payloads and indexed markers in one pass.',
 '- Keep explicit checked and known-live C++ value readers. Both copy bytes into C++ values with `bit_cast`, without imposing a C++ object layout on C storage or invoking a component default constructor during reads.', '',
 '![Required read contracts](results/indexed-v25-packed/read-contracts.png)', '', '## Broader C suite: fixed policies', '',
 'Both storage policies run the same complete 386-case matrix. No case selects a winning policy after measurement. The C suite uses checked access in both policies; it does not use the C++ known-live method.', '',
 '| Fixed dataset / policy | Cases | Cedar lower median | Cedar disjoint IQR | Flecs disjoint IQR | Overlap |',
 '| --- | ---: | ---: | ---: | ---: | ---: |']
for label,run in [('Previous packed v16','query-access-v16-expanded'),('Current packed default','indexed-v25-packed'),('Current indexed','indexed-v25-slots'),('Original frozen suite, packed','indexed-v25-original')]:
    data=rows(run); m,c,f=c_counts(data)
    text.append(f'| {label} | {len(data)} | {m} | {c} | {f} | {len(data)-c-f} |')
text += ['',
 'Disjoint IQR means one p75 is below the other p25. It describes observed spread and is not a significance test. The larger suite is not interchangeable with the upstream entity suite, and its win rates are reported independently.', '',
 '![All fixed-policy C cases](results/indexed-v25-packed/storage-policies.png)', '', '## Tradeoffs and remaining gaps', '',
 'Indexed components reserve payload and marker slots up to the world’s entity capacity, including holes and absent components. This consumes more memory for sparse presence and retains storage until world destruction. Fragmented signatures create many short query runs; rebuilding a query scans the entity slots. Packed storage keeps its strengths for iteration and selective queries. Prepared scopes/bindings are owner-only, must stay at stable addresses, must not be copied while active, and must end before worker dispatch or world destruction.', '',
 'Checked Cedar still trails pico_ecs in several small or multi-component reads. The shared BM_AddComponent timer pauses/resumes inside the entity loop, so timer overhead dominates its roughly 350 ns/entity results; close median differences should not be read as precise component insertion costs. The known-live mode is appropriate only where its preconditions are already guaranteed.', '',
 '## Validation and provenance', '',
 'Core ASan/UBSan, Cedar TSan, 65/320-component configurations and parking-only checks run both storage modes. The expanded release and ASan/UBSan smokes pass 374 parameter/size cases per engine per policy; TSan worker-command checks pass both Cedar policies. Checked and known-live C++ bridges pass ASan/UBSan and CTest. Differential tests cover prepared mutations versus immediate operations, nested scope exclusion, empty/late component allocation, aliasing and growth, stale/recycled handles, final-generation presence/removal/retirement, filters and cached worker plans.', '',
 'The checked final binary is byte-identical to its measured v24 executable; v25 adds the separately compiled optional known-live reader. All competitor executables and the shared C kernels remain byte-identical to the previous comparison. Production `include/cedarecs/` remains equal to the initial isolated baseline. Historical prototypes and unfavorable results are preserved. The older Flecs development native-pipeline TSan diagnostics remain unresolved; no competitor sources or suppressions were changed.', '',
 'Reproduce after restoring the pinned dependencies:', '',
 '```sh', 'make -C testing all expanded expanded-indexed', 'python3 testing/interop/abeimler/run.py --repeats 9 --min-time 0.03 --output testing/results/NEW-checked', 'python3 testing/interop/abeimler/run.py --cedar-read-mode known-live --repeats 9 --min-time 0.03 --output testing/results/NEW-known-live', 'python3 testing/bench/expanded/run.py --output results/NEW-packed', 'python3 testing/bench/expanded/run.py --cedar-storage indexed --output results/NEW-indexed', '```', '',
 'Sources: [checked entity results](results/'+CHECKED+'/summary.csv), [known-live entity results](results/'+KNOWN+'/summary.csv), [packed C results](results/indexed-v25-packed/comparison.md), [indexed C results](results/indexed-v25-slots/comparison.md), [verification](validation/indexed-v25/verification.json).', '']
(ROOT/'OPTIMIZATIONS_INDEXED.md').write_text('\n'.join(text))
print('Wrote', ROOT/'OPTIMIZATIONS_INDEXED.md')
