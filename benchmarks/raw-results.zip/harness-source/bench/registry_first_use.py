import argparse,csv,hashlib,json,os,shutil,statistics,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--build-only',action='store_true');p.add_argument('--variant',default='automatic-tls-cache-v112');p.add_argument('--output',type=Path);args=p.parse_args()
build=ROOT/'build'/args.variant
flags=['clang','-std=c11','-D_POSIX_C_SOURCE=200809L','-D_DARWIN_C_SOURCE','-pthread','-O3','-DNDEBUG','-march=native','-I'+str(ROOT/'variants/kama-registry-v107')]
if args.build_only:
    obj=build/'first-use.o';command=[*flags,'-c',str(ROOT/'bench/registry_first_use.c'),'-o',str(obj)];subprocess.run(command,check=True)
    commands=[command]
    for key in ('before','auto','ordinary','concurrent'):
        folder=ROOT/'build/automatic-registry-v110-paired/baseline' if key=='before' else build/key
        objects=[folder/(p.stem+'.o') for p in [*sorted((ROOT/'cedarecs/ecs').glob('*.c')),ROOT/'cedarecs/wexds.c']]
        command=[*flags,str(obj),*map(str,objects),'-lm','-o',str(build/('first-use-'+key))]
        subprocess.run(command,check=True);commands.append(command)
    (build/'first-use-build.json').write_text(json.dumps(commands,indent=2)+'\n');raise SystemExit
assert args.output
out=args.output.resolve();out.mkdir(parents=True,exist_ok=False);keys=('before','auto','ordinary','concurrent');binaries={}
for key,letter in zip(keys,'abcd'):
    binaries[key]=out/('engine-'+letter);shutil.copy2(build/('first-use-'+key),binaries[key])
shutil.copy2(__file__,out/'runner.py');shutil.copy2(ROOT/'bench/registry_first_use.c',out/'workload.c');shutil.copy2(build/'first-use-build.json',out/'build.json')
summary=[]
with (out/'raw.jsonl').open('w') as log:
    for kind in range(4):
        samples={k:[] for k in keys}
        for trial in range(-2,16):
            order=list(keys[trial%4:]+keys[:trial%4]);
            if trial%2:order.reverse()
            for position,key in enumerate(order):
                r=subprocess.run([str(binaries[key]),str(kind),'100000',key],check=True,text=True,capture_output=True,
                   env=dict(os.environ,LC_ALL='C',CEDAR_BENCH_STACK_PAD='x'*((max(trial,0)//2)%8)*16))
                assert not r.stderr;r=json.loads(r.stdout);assert r['version']==key and r['kind']==kind and r['worlds']==100000
                if trial>=0:
                    samples[key].append(r['ns_per_world']);log.write(json.dumps(dict(trial=trial,position=position,**r))+'\n')
        row=dict(kind=kind)
        for key,values in samples.items():
            q=statistics.quantiles(values,n=4,method='inclusive');row.update({key+'_median_ns':statistics.median(values),key+'_p25_ns':q[0],key+'_p75_ns':q[2]})
        row['auto_over_before']=row['auto_median_ns']/row['before_median_ns'];row['auto_over_ordinary']=row['auto_median_ns']/row['ordinary_median_ns'];summary.append(row);log.flush();print(row,flush=True)
with (out/'summary.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,list(summary[0]));w.writeheader();w.writerows(summary)
(out/'metadata.json').write_text(json.dumps(dict(variant=args.variant,repeats=16,cases=4,worlds=100000,
    binaries={k:hashlib.sha256(v.read_bytes()).hexdigest() for k,v in binaries.items()},
    methodology='One shared byte-identical workload object for four runtimes. Complete world create/use/drop timed, including first registry/view allocation. Single thread, 16 rotated/reversed rounds, eight environment paddings, two discarded warmups, no samples removed.'),indent=2)+'\n')
