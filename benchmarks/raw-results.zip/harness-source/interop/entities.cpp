#include "EntityBenchmark.h"
#if defined(COMPARE_CEDAR)
#include "CedarEntityFactory.h"
using Factory = cedar_interop::Factory;
#define FRAMEWORK_NAME "cedar"
static const bool cedar_context = [] {
    benchmark::AddCustomContext("cedar.snapshot", CEDAR_COMPILED_SNAPSHOT);
#ifdef CEDAR_ASSUME_LIVE
    benchmark::AddCustomContext("cedar.read_contract", "known-live");
#else
    benchmark::AddCustomContext("cedar.read_contract", "checked");
#endif
    return true;
}();
#elif defined(COMPARE_ENTT)
#include "entt/entities/EntityFactory.h"
using Factory = ecs::benchmarks::entt::entities::EntityFactory;
#define FRAMEWORK_NAME "entt"
#elif defined(COMPARE_PICO)
#include "pico_ecs/entities/EntityFactory.h"
using Factory = ecs::benchmarks::pico_ecs::entities::EntityFactory;
#define FRAMEWORK_NAME "pico_ecs"
#elif defined(COMPARE_FLECS)
#include "flecs/entities/EntityFactory.h"
using Factory = ecs::benchmarks::flecs::entities::EntityFactory;
#define FRAMEWORK_NAME "flecs"
#endif
static ecs::benchmarks::base::EntityBenchmark<FRAMEWORK_NAME, Factory> suite;
// The unmodified upstream template and registration macros drive every backend.
// No loop-based imitation of unsupported bulk APIs is registered for Cedar.
ECS_ENTITY_BENCHMARKS(suite)
