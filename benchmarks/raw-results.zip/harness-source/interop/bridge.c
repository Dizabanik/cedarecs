#include "bridge.h"
#include <cedarecs/cedar.h>
#include <stdlib.h>
struct cb_world {
    ced_World *ecs;
    ced_Component ids[3];
    ced_SpawnPlan plans[3];
};
cb_world *cb_new(const cb_type types[3]) {
    cb_world *w = calloc(1, sizeof(*w));
    if (!w)
        abort();
    w->ecs = ced_init_indexed();
    const char *names[] = {"PositionComponent", "VelocityComponent", "DataComponent"};
    for (size_t i = 0; i < 3; i++) {
        w->ids[i] = ced_component_register(w->ecs, names[i], types[i].size, types[i].alignment);
        if (w->ids[i] == ced_component_none)
            abort();
    }
    return w;
}
void cb_free(cb_world *w) {
    if (w) {
        ced_drop(w->ecs);
        free(w);
    }
}
ced_ReadAccess cb_access(cb_world *w) { return ced_read_access(w->ecs); }
ced_IndexedReader cb_reader(cb_world *w, unsigned c) {
    return c < 3 ? ced_indexed_reader(w->ecs, w->ids[c]) : (ced_IndexedReader){0};
}
ced_IndexedWriter cb_writer(cb_world *w) { return ced_indexed_write_begin(w->ecs); }
uint64_t cb_entity(cb_world *w) { return ced_entity(w->ecs); }
uint64_t cb_spawn(cb_world *w, unsigned count, const void *const *values) {
    if (!count || count > 3)
        return ced_entity_none;
    ced_SpawnPlan *plan = &w->plans[count - 1];
    if (!plan->archetype)
        *plan = ced_spawn_plan_init(w->ecs, count, w->ids);
    return ced_entity_from_plan_values(w->ecs, plan, values);
}
void cb_kill(cb_world *w, uint64_t e) { ced_kill(w->ecs, e); }
void cb_put(cb_world *w, uint64_t e, unsigned c, const void *v) {
    if (c >= 3 || !ced_add_set_component(w->ecs, e, w->ids[c], v))
        abort();
}
void cb_remove(cb_world *w, uint64_t e, unsigned c) {
    if (c >= 3)
        abort();
    ced_remove_component(w->ecs, e, w->ids[c]);
}
void *cb_get(cb_world *w, uint64_t e, unsigned c) {
    return c < 3 ? ced_get_component(w->ecs, e, w->ids[c]) : NULL;
}
int cb_alive(cb_world *w, uint64_t e) { return ced_is_alive(w->ecs, e); }
