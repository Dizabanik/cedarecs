#undef NDEBUG
#include "CedarEntityFactory.h"
#include <cassert>
#include <utility>
// Exercise the C++ path at the final generation without billions of recycles.
static void final_generation_reads() {
    using P = cedar_interop::Position;
    static_assert(sizeof(ced_IndexedRead<P>) == 6 * sizeof(void *));
    P values[8]{};
    values[7].x = 13;
    ced_Entity owners[8];
    for (auto &owner : owners) owner = UINT64_MAX;
    const ced_Entity last = (UINT64_C(0xffffffff) << 32) | 7;
    owners[7] = last;
    ced_IndexedColumn column{reinterpret_cast<unsigned char *>(values), owners, 8};
    ced_IndexedRead<P> reader({&column, sizeof(P)});
    assert(reader.get(last) == &values[7] && reader.value(last).x == 13);
    assert(!reader.get(7) && !reader.get(last - (UINT64_C(1) << 32)));
    assert(!reader.get(UINT64_MAX) && !reader.get(last + 1));
    owners[7] = UINT64_MAX;
    assert(!reader.get(last));
    struct NoDefault { NoDefault() = delete; uint64_t value; };
    static_assert(std::is_trivially_copyable_v<NoDefault>);
    uint64_t payload = 42;
    ced_Entity owner = 0;
    ced_IndexedColumn raw{reinterpret_cast<unsigned char *>(&payload), &owner, 1};
    ced_IndexedRead<NoDefault> nondefault({&raw, sizeof(payload)});
    assert(nondefault.value(0).value == 42);
}
static void large_generation_reads() {
    struct Big { uint64_t words[32]; };
    static_assert(sizeof(ced_IndexedRead<Big>) == 6 * sizeof(void *));
    Big values[8]{}; values[7].words[0] = 73; values[0].words[0] = 19;
    ced_Entity owners[8];
    for (auto &owner : owners) owner = UINT64_MAX;
    owners[0] = 0;
    const ced_Entity last = (UINT64_C(0xffffffff) << 32) | 7;
    owners[7] = last;
    ced_IndexedRead<Big> detached;
    {
        ced_IndexedColumn temporary{reinterpret_cast<unsigned char *>(values), owners, 8, nullptr, nullptr};
        detached = ced_IndexedRead<Big>({&temporary, sizeof(Big)});
    } // A detached snapshot must not retain a dangling metadata dependency.
    assert(detached.value(last).words[0] == 73);
    assert(detached.value(0).words[0] == 19);
    assert(!detached.get(UINT64_C(1) << 48));
    assert(!detached.get(7) && !detached.get(last - (UINT64_C(1) << 32)));
    assert(!detached.get(UINT64_MAX));
    ced_IndexedRead<Big> copy(detached), moved(std::move(copy));
    assert(moved.value(last).words[0] == 73 && !copy.get(last));
    owners[7] = UINT64_MAX;
    assert(!detached.get(last) && !moved.get(last));
}
int main() {
    final_generation_reads();
    large_generation_reads();
    using F = cedar_interop::Factory;
    F::EntityManager w;
    auto e = F::create(w);
    auto p = F::getComponentOne(w, e);
    auto v = F::getComponentTwo(w, e);
    assert(p.x == 0 && p.y == 0 && v.x == 1 && v.y == 1 && F::getOptionalComponentThree(w, e));
    cedar_interop::Position assigned{}; assigned.x = 13;
    cb_put(w.raw, e, 0, &assigned);
    F::addComponentOne(w, e);
    assert(F::getComponentOne(w, e).x == 13); // add preserves existing data
    F::removeComponentOne(w, e);
    assert(!cb_get(w.raw, e, 0));
    F::addComponentOne(w, e);
    auto old = e;
    F::destroy(w, e);
    assert(!cb_alive(w.raw, old));
    e = F::createMinimal(w);
    assert(cb_alive(w.raw, e) && !cb_alive(w.raw, old));
    assert(!F::getOptionalComponentThree(w, e));
    assert(!ced_read_get(&w.access, old, 0));
    for (size_t i = 0; i < 4096; i++)
        F::createMinimal(w); // the access interface follows record/column growth
    p = F::getComponentOne(w, e);
    assert(p.x == 0 && p.y == 0);
    assert(!ced_read_get(&w.access, e, UINT16_MAX));
    assert(!ced_read_get(&w.access, UINT64_MAX, 0));
    assert(ced_read_get(&w.access, e, 1) == cb_get(w.raw, e, 1));
    F::removeComponentTwo(w, e);
    assert(!ced_read_get(&w.access, e, 1));
    ced_IndexedRead<cedar_interop::Position> empty;
    assert(!empty.get(e));
    auto wrong = cb_reader(w.raw, 2);
    ced_IndexedRead<cedar_interop::Position> mismatched(wrong);
    assert(!mismatched.get(e));
    assert(!w.position.get(old));
    assert(!w.position.get(UINT64_MAX));
    assert(!w.position.get(UINT64_C(0xfffffffe)));
    assert(!empty.get(UINT64_MAX));
    assert(!mismatched.get(UINT64_MAX));
    F::removeComponentOne(w, e);
    assert(!w.position.get(e));
    F::addComponentOne(w, e);
    assert(w.position.get(e));
    return 0;
}
