# Cedar in abeimler/ecs_benchmark

This is a working integration with the upstream **entity benchmark suite**, using its unmodified `EntityBenchmark` template and registration macros. It builds four executables: Cedar, EnTT, pico_ecs, and Flecs. It does not yet implement the upstream seven-system game application, extended view/event benchmarks, or every supported framework. Additional native entity factories can be wired into the same template without duplicating its loops.

## Build and run

From `testing/`:

```sh
python3 bench/bootstrap.py  # restores the original C comparison's ignored Flecs clone
cmake -S interop/abeimler -B build/interop -DCMAKE_BUILD_TYPE=Release
cmake --build build/interop -j3
ctest --test-dir build/interop --output-on-failure
python3 interop/abeimler/run.py --output results/my-multi-ecs-run
```

CMake fetches pinned sources into the ignored build directory. It imports upstream headers without running upstream's global vcpkg/project-options configuration. For an already cloned upstream repository, configure with `-DECS_BENCHMARK_ROOT=/absolute/path/to/ecs_benchmark`. Use `-DCOMPARE_OTHER_FRAMEWORKS=OFF` to build only Cedar and its bridge check; the four-framework runner requires the default ON setting.

The default runner selects populations 1, 1024, and 65536 plus the zero-entity teardown case. It runs five independent process rounds, rotating framework order, and retains each Google Benchmark JSON and console log. The JSON preserves both wall and CPU time; the CSV reports per-case medians and quartiles. No process runs concurrently with another benchmark process. `--filter`, `--min-time`, and `--repeats` allow broader or longer runs. To list everything registered, run `build/interop/cedar-entities --benchmark_list_tests=true`.

The common surface includes empty/two-component creation, destruction, absent/one/two/optional-third component retrieval, remove/add, and single additions. Cedar does not advertise a bulk operation by looping over individual operations, so unsupported bulk cases are not registered in this common comparison.

## Versions and compatibility

| Dependency | Pin |
| --- | --- |
| abeimler/ecs_benchmark | `98678f746e0e2f04c37a3332453c8d98daa94f92` |
| Google Benchmark 1.9.4 | `eddb0241389718a23a42db6af5f0164b6e0139af` |
| gsl-lite 0.41.0 | `755ba124b54914e672737acace6a9314f59e8d6f` |
| EnTT 3.13.2 | `78213075654a688e9da6bc49f7f873d25c26d12c` |
| pico_headers, compatible 2024 revision | `cfd880ec0804c060ad624a19a02a39b0deeb5ba4` |
| Flecs 4.0.1 | `02c8c2666b22ccce5706c8f16efaf813704fe31e` |

Upstream's adapter targets EnTT 3.13.2 and Flecs 4.0.1. Its pico adapter also predates the current API. The selected pico revision is the last change to `pico_ecs.h` before that upstream snapshot. Building those unchanged adapters against current pico/Flecs development sources exposed API incompatibilities; compatible versions are pinned explicitly rather than patching the adapters or presenting them as latest-version comparisons. The separate expanded C suite still uses Flecs development revision `75fa09f...` and the original experimental Cedar snapshot. Do not merge the two Flecs columns or compare their absolute timings across harnesses.

## Bridge and scope

Cedar stays C11. `bridge.c` includes and compiles the actual Cedar implementation through a small opaque C ABI. The C++20 factory handles the upstream plain-data defaults and passes sizes/alignments to registration. It only accepts trivially copyable component types. Getters copy Position/Velocity bytes into real C++ objects, avoiding typed C++ object access in C-owned storage. The upstream template itself also copies those returned components into local variables. Optional third-component retrieval returns a pointer without constructing or dereferencing a C++ object in that storage.

The bridge introduces function-call and copy overhead relative to direct C access, so this measures Cedar's C++ adapter too. Its active correctness check verifies component defaults, remove/re-add, optional absence, entity destruction, and stale-handle rejection. The independent expanded C suite remains the primary place for detailed Cedar/Flecs performance work.

Upstream timing boundaries are retained exactly. Some creation and destruction tests include registry teardown after resuming timing; the zero-entity test primarily measures teardown. Type registration and first-use component storage also vary across native factory implementations. Google Benchmark pauses/resumes around single additions in another case. These are materially different measurements from the expanded C suite, which excludes world teardown. Component feature guarantees and native factory defaults can differ. The tested host is Apple M4 Pro with Apple Clang on macOS; Windows and other architectures have not been validated. The shared framework counters are checked for agreement, but this upstream harness does not provide the expanded C suite's cross-library value checksums. Treat the results as an initial integration comparison, not a universal ranking or a substitute for application tests.

Sources: [abeimler/ecs_benchmark](https://github.com/abeimler/ecs_benchmark). Its historical README scores were not imported. The original external checkout stays clean, and its MIT-licensed files are consumed from the pinned clone rather than vendored or rewritten here.


The optimized Cedar factory uses the public prepared initialized-spawn API for
single/PV/PVD creation, initializing the same upstream default values directly
in the final signature. Plans initialize on first use. It also uses the public
C/C++ `access.h` read interface; returned Position/Velocity values are still
copied with memcpy into C++ objects. This removes repeated external bridge
calls without caching individual entities or component pointers. Competing
factories and all upstream benchmark templates are unchanged. Historical
`multi-ecs-20261026` results used incremental creation and out-of-line reads;
compare them separately from the new adapter results.


### Indexed worlds and separate read contracts

The v25 Cedar factory selects `ced_init_indexed()` for its whole world and opens
an owner-only write scope while using prepared mutation bindings. Immediate
changes remain visible immediately. No per-case storage choice is made.
`cedar-entities` keeps checked required reads. `cedar-entities-known-live` uses
`value_unchecked` for Position/Velocity, whose presence and liveness are already
guaranteed by the unchanged upstream setup during each read loop. Optional reads
remain checked. The pinned pico_ecs getter itself directly computes a slot
address; its Release assertions do not validate presence or liveness. Keep the
two Cedar contracts separate when interpreting results.

```sh
python3 testing/interop/abeimler/run.py --repeats 9 --min-time 0.03 --output testing/results/NEW-checked
python3 testing/interop/abeimler/run.py --cedar-read-mode known-live --repeats 9 --min-time 0.03 --output testing/results/NEW-known-live
```

See [the indexed optimization report](../../OPTIMIZATIONS_INDEXED.md). Registry
teardown stays within the original template's timing boundaries. All EnTT,
pico_ecs and Flecs factories, sources, dependency pins and executables remain
unchanged. These are entity-operation comparisons rather than system/game
benchmarks for every framework.


### Current checked candidate

The [checked optimization report](../../OPTIMIZATIONS_CHECKED.md) supersedes the
[v42 report](../../OPTIMIZATIONS_MEMORY.md). Its nine-round/30 ms confirmation
records 28/28 wins against pico_ecs, 27/28 against EnTT and 28/28 against Flecs,
using the same native competitor binaries. The Cedar target keeps bounds,
presence and full 64-bit owner-generation checks. Typed readers register tracked
allocation snapshots: growth refreshes them, copy/move operations re-link them,
and world destruction invalidates them. The factory's idempotent checked add
preserves an existing component value. Eager factory preparation was rejected
after increasing teardown cost.

Each Cedar executable reports `cedar.read_contract` and `cedar.snapshot` in its
Google Benchmark JSON context. The runner rejects mismatches with the selected
contract and recorded source hash. The known-live target remains a separate
contract and is excluded from the checked scores. Retained probes include
unfavorable results; close median wins and the remaining EnTT loss are disclosed.
