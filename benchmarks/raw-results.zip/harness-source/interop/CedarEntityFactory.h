#ifndef CEDAR_ABEIMLER_FACTORY_H
#define CEDAR_ABEIMLER_FACTORY_H
#include "bridge.h"
#include "base/components/PositionComponent.h"
#include "base/components/VelocityComponent.h"
#include "base/components/DataComponent.h"
#include <cstring>
#include <cstdlib>
#include <type_traits>
namespace cedar_interop {
using Position = ecs::benchmarks::base::components::PositionComponent;
using Velocity = ecs::benchmarks::base::components::VelocityComponent;
using Data = ecs::benchmarks::base::components::DataComponent;
static_assert(std::is_trivially_copyable_v<Position> && std::is_trivially_copyable_v<Velocity> &&
              std::is_trivially_copyable_v<Data>);
class Manager {
  public:
    cb_world *raw;
    ced_ReadAccess access;
    ced_IndexedReader readers[3];
    ced_IndexedRead<Position> position;
    ced_IndexedRead<Velocity> velocity;
    ced_IndexedRead<Data> data;
    ced_IndexedWriter writer;
    ced_IndexedBinding bindings[3];
    ced_IndexedMutate<Position> position_write;
    static cb_world *create_world() {
        const cb_type types[] = {{sizeof(Position), alignof(Position)},
                                 {sizeof(Velocity), alignof(Velocity)},
                                 {sizeof(Data), alignof(Data)}};
        return cb_new(types);
    }
    __attribute__((always_inline)) Manager() : raw(create_world()), access(cb_access(raw)),
        readers{cb_reader(raw, 0), cb_reader(raw, 1), cb_reader(raw, 2)},
        position(readers[0]), velocity(readers[1]), data(readers[2]),
        writer(cb_writer(raw)),
        bindings{ced_indexed_bind(&writer, 0), ced_indexed_bind(&writer, 1),
                 ced_indexed_bind(&writer, 2)}, position_write(bindings[0]) {}
    ~Manager() { ced_indexed_write_end(&writer); cb_free(raw); }
    Manager(const Manager &) = delete;
    Manager &operator=(const Manager &) = delete;
};
struct Factory {
    using EntityManager = Manager;
    using Entity = uint64_t;
    static Entity createEmpty(Manager &w) { return cb_entity(w.raw); }
    static void addComponentOne(Manager &w, Entity e) {
        if (!w.position_write.add(e)) std::abort();
    }
    static void addComponentTwo(Manager &w, Entity e) {
        Velocity v{};
        cb_put(w.raw, e, 1, &v);
    }
    static void addComponentThree(Manager &w, Entity e) {
        Data d{};
        cb_put(w.raw, e, 2, &d);
    }
    static Entity createSingle(Manager &w) {
        Position p{};
        const void *values[] = {&p};
        return cb_spawn(w.raw, 1, values);
    }
    static Entity createMinimal(Manager &w) {
        Position p{};
        Velocity v{};
        const void *values[] = {&p, &v};
        return cb_spawn(w.raw, 2, values);
    }
    static Entity create(Manager &w) {
        Position p{};
        Velocity v{};
        Data d{};
        const void *values[] = {&p, &v, &d};
        return cb_spawn(w.raw, 3, values);
    }
    static void destroy(Manager &w, Entity e) { cb_kill(w.raw, e); }
    // Required reads preserve validation and copy into live C++ values.
    static Position getComponentOne(Manager &w, Entity e) {
#ifdef CEDAR_ASSUME_LIVE
        return w.position.value_unchecked(e);
#else
        return w.position.value(e);
#endif
    }
    static Velocity getComponentTwo(Manager &w, Entity e) {
#ifdef CEDAR_ASSUME_LIVE
        return w.velocity.value_unchecked(e);
#else
        return w.velocity.value(e);
#endif
    }
    static const void *getOptionalComponentThree(Manager &w, Entity e) { return w.data.get(e); }
    static void removeComponentOne(Manager &w, Entity e) { w.position_write.remove(e); }
    static void removeComponentTwo(Manager &w, Entity e) { cb_remove(w.raw, e, 1); }
    static void removeComponentThree(Manager &w, Entity e) { cb_remove(w.raw, e, 2); }
};
} // namespace cedar_interop
#endif
