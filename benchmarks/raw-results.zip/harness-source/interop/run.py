#!/usr/bin/env python3
"""Run the same upstream entity suite for every built framework; retain JSON."""

import argparse
import csv
import hashlib
import json
from pathlib import Path
import random
import os
import shutil
import statistics
import subprocess
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[2]
FRAMEWORKS = ("cedar", "entt", "pico", "flecs")
PINS = {
    "ecs_benchmark": "98678f746e0e2f04c37a3332453c8d98daa94f92",
    "google_benchmark": "eddb0241389718a23a42db6af5f0164b6e0139af",
    "gsl_lite": "755ba124b54914e672737acace6a9314f59e8d6f",
    "entt": "78213075654a688e9da6bc49f7f873d25c26d12c",
    "pico": "cfd880ec0804c060ad624a19a02a39b0deeb5ba4",
    "flecs_reference": "02c8c2666b22ccce5706c8f16efaf813704fe31e",
}


def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--build", type=Path, default=ROOT / "build/interop")
    p.add_argument("--upstream", type=Path)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--repeats", type=int, default=5)
    p.add_argument("--cedar-read-mode", choices=("checked", "known-live"), default="checked")
    p.add_argument("--min-time", type=float, default=0.01)
    p.add_argument("--balanced-layout",action="store_true",
                   help="32-round cycles balance four process positions at every one of eight environment paddings")
    p.add_argument(
        "--filter", default=r"(^BM_CreateNoEntities$|^BM_.*/(1|1024|65536)$)"
    )
    args = p.parse_args()
    assert args.repeats >= 3 and args.min_time > 0
    if args.balanced_layout:assert args.repeats%32==0
    build = args.build.resolve()
    binaries = {k: build / ("cedar-entities-known-live" if k == "cedar" and args.cedar_read_mode == "known-live" else f"{k}-entities") for k in FRAMEWORKS}
    if args.upstream:
        upstream = args.upstream.resolve()
    else:
        cache = (build / "CMakeCache.txt").read_text()
        configured = next(
            (
                line.split("=", 1)[1]
                for line in cache.splitlines()
                if line.startswith("ECS_BENCHMARK_ROOT:PATH=")
            ),
            "",
        )
        upstream = (
            Path(configured).resolve()
            if configured
            else build / "_deps/ecs_reference-src"
        )
    out = args.output.resolve()
    locations = {
        k: (upstream if k == "ecs_benchmark" else build / "_deps" / f"{k}-src")
        for k in PINS
    }
    for k, location in locations.items():
        actual = subprocess.check_output(
            ["git", "-C", str(location), "rev-parse", "HEAD"], text=True
        ).strip()
        assert actual == PINS[k], (k, actual, PINS[k])
        assert not subprocess.check_output(
            ["git", "-C", str(location), "status", "--porcelain"], text=True
        ).strip(), k
    source = json.loads((ROOT / "provenance.json").read_text())
    for filename, h in source["cedarecs"]["files"].items():
        assert digest(ROOT / filename) == h
    out.mkdir(parents=True, exist_ok=False)
    shutil.copy2(__file__,out/'runner.py')
    archive=out/'source'
    shutil.copytree(Path(__file__).parent,archive/'interop',ignore=shutil.ignore_patterns('__pycache__'))
    shutil.copytree(ROOT/'cedarecs',archive/'cedarecs',ignore=shutil.ignore_patterns('.git'))
    shutil.copytree(ROOT/'kama',archive/'kama',ignore=shutil.ignore_patterns('.git'))
    shutil.copy2(ROOT/'provenance.json',archive/'provenance.json')
    if args.balanced_layout:
        copies={}
        for framework,letter in zip(FRAMEWORKS,'abcd'):
            copies[framework]=out/('engine-'+letter)
            shutil.copy2(binaries[framework],copies[framework])
            assert digest(copies[framework])==digest(binaries[framework])
        binaries=copies
    meta = dict(
        suite="abeimler-entities-v1",
        cedar_read_mode=args.cedar_read_mode,
        cedar_storage="indexed",
        started_utc=datetime.now(timezone.utc).isoformat(),
        pins=PINS,
        cedar=source["cedarecs"],
        kama=source["kama"],
        repeats=args.repeats,
        min_time=args.min_time,
        filter=args.filter,
        binary_sha256={k: digest(binaries[k]) for k in FRAMEWORKS},
        adapter_sha256={
            p.name: digest(p)
            for p in sorted(Path(__file__).parent.glob("*"))
            if p.is_file()
        },
        balanced_layout=args.balanced_layout,
        execution="one independent Google Benchmark process at a time; independent rotation/reversal cycles; optional equal-length paths and balanced position/environment crossings; no combined score",
        cmake_cache=(build / "CMakeCache.txt").read_text(),
    )
    (out / "metadata.json").write_text(json.dumps(meta, indent=2) + "\n")
    initial = list(FRAMEWORKS)
    random.Random(0xCEDA).shuffle(initial)
    raw = []
    for trial in range(args.repeats):
        order = initial[trial % len(initial) :] + initial[: trial % len(initial)]
        if (trial // len(initial)) % 2:
            order = order[::-1]
        for position, framework in enumerate(order):
            destination = out / f"{framework}-{trial}.json"
            timed_destination=(out/f"{'abcd'[FRAMEWORKS.index(framework)]}{trial:03}.json"
                               if args.balanced_layout else destination)
            command = [
                str(binaries[framework]),
                f"--benchmark_filter={args.filter}",
                f"--benchmark_min_time={args.min_time}s",
                "--benchmark_repetitions=1",
                "--benchmark_out_format=json",
                f"--benchmark_out={timed_destination}",
            ]
            environment=dict(os.environ)
            padding=(((trial//8)*2+(trial%2))*16) if args.balanced_layout else None
            if padding is not None:environment['CEDAR_BENCH_STACK_PAD']='x'*padding
            with (out / f"{framework}-{trial}.log").open("w") as log:
                subprocess.run(
                    command,
                    stdout=log,
                    stderr=subprocess.STDOUT,
                    check=True,
                    timeout=300,
                    env=environment,
                )
            if args.balanced_layout:shutil.copy2(timed_destination,destination)
            result = json.loads(destination.read_text())
            if framework == "cedar":
                assert result["context"]["cedar.read_contract"] == args.cedar_read_mode
                assert result["context"]["cedar.snapshot"] == source["cedarecs"]["snapshot_sha256"]
            assert result["context"]["framework.name"] == (
                "pico_ecs" if framework == "pico" else framework
            )
            assert result["benchmarks"]
            for record in result["benchmarks"]:
                assert not record.get("error_occurred") and record["time_unit"] == "ns"
                assert record["real_time"] > 0 and record["cpu_time"] > 0
                raw.append(
                    dict(framework=framework, trial=trial, order=position, stack_padding=padding, **record)
                )
            print(
                f"{trial + 1}/{args.repeats} {framework}: {len(result['benchmarks'])} cases",
                flush=True,
            )
    (out / "raw.jsonl").write_text("".join(json.dumps(r) + "\n" for r in raw))
    names = {r["name"] for r in raw}
    summaries = []
    for name in sorted(names):
        row = {"benchmark": name}
        for framework in FRAMEWORKS:
            samples = [
                r for r in raw if r["framework"] == framework and r["name"] == name
            ]
            assert len(samples) == args.repeats, (framework, name, len(samples))
            for counter in (
                "entities",
                "components_one",
                "components_two",
                "components_three",
            ):
                counter_values = {r.get(counter, 0) for r in raw if r["name"] == name}
                assert len(counter_values) == 1, (name, counter, counter_values)
            values = [r["cpu_time"] for r in samples]
            quartiles = statistics.quantiles(values, n=4, method="inclusive")
            row[f"{framework}_cpu_median_ns"] = statistics.median(values)
            row[f"{framework}_cpu_p25_ns"] = quartiles[0]
            row[f"{framework}_cpu_p75_ns"] = quartiles[2]
            row[f"{framework}_real_median_ns"] = statistics.median(
                r["real_time"] for r in samples
            )
        summaries.append(row)
    with (out / "summary.csv").open("w", newline="") as f:
        w = csv.DictWriter(f, list(summaries[0]))
        w.writeheader()
        w.writerows(summaries)
    meta.update(
        completed_utc=datetime.now(timezone.utc).isoformat(),
        samples=len(raw),
        configurations=len(names),
    )
    (out / "metadata.json").write_text(json.dumps(meta, indent=2) + "\n")
    print("Results:", out)


if __name__ == "__main__":
    main()
