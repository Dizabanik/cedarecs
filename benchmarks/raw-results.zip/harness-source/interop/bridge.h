#ifndef CEDAR_BENCH_CPP_BRIDGE_H
#define CEDAR_BENCH_CPP_BRIDGE_H
#include <stddef.h>
#include <stdint.h>
#include <cedarecs/access.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef struct cb_world cb_world;
typedef struct cb_type {
    size_t size, alignment;
} cb_type;
CEDARECS_ALLOCATOR cb_world *cb_new(const cb_type types[3]);
void cb_free(cb_world *w);
CEDARECS_PURE ced_ReadAccess cb_access(cb_world *w);
CEDARECS_PURE ced_IndexedReader cb_reader(cb_world *w, unsigned component);
ced_IndexedWriter cb_writer(cb_world *w);
uint64_t cb_entity(cb_world *w);
uint64_t cb_spawn(cb_world *w, unsigned count, const void *const *values);
void cb_kill(cb_world *w, uint64_t entity);
void cb_put(cb_world *w, uint64_t entity, unsigned component, const void *value);
void cb_remove(cb_world *w, uint64_t entity, unsigned component);
CEDARECS_PURE void *cb_get(cb_world *w, uint64_t entity, unsigned component);
CEDARECS_PURE int cb_alive(cb_world *w, uint64_t entity);
#ifdef __cplusplus
}
#endif
#endif
