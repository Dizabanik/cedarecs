#!/usr/bin/env python3
"""Audit four-framework entity results and preserved Google Benchmark files."""

import argparse
import csv
import json
import statistics
from pathlib import Path


def validate(root):
    m = json.loads((root / "metadata.json").read_text())
    assert m["suite"] == "abeimler-entities-v1" and "completed_utc" in m
    records = [
        json.loads(line) for line in (root / "raw.jsonl").read_text().splitlines()
    ]
    frameworks = ("cedar", "entt", "pico", "flecs")
    summary = {r["benchmark"]: r for r in csv.DictReader((root / "summary.csv").open())}
    assert len(records) == m["samples"] == len(summary) * len(frameworks) * m["repeats"]
    assert len(summary) == m["configurations"]
    for framework in frameworks:
        for trial in range(m["repeats"]):
            data = json.loads((root / f"{framework}-{trial}.json").read_text())[
                "benchmarks"
            ]
            retained = [
                r
                for r in records
                if r["framework"] == framework and r["trial"] == trial
            ]
            assert (
                {r["name"] for r in data}
                == set(summary)
                == {r["name"] for r in retained}
            )
            for raw in data:
                row = next(r for r in retained if r["name"] == raw["name"])
                assert all(row[k] == v for k, v in raw.items())
    for name, s in summary.items():
        group = [r for r in records if r["name"] == name]
        for counter in (
            "entities",
            "components_one",
            "components_two",
            "components_three",
        ):
            assert len({r.get(counter, 0) for r in group}) == 1
        for framework in frameworks:
            samples = [r for r in group if r["framework"] == framework]
            assert len(samples) == m["repeats"]
            assert {r["trial"] for r in samples} == set(range(m["repeats"]))
            assert all(
                r["time_unit"] == "ns"
                and r["iterations"] > 0
                and not r.get("error_occurred")
                for r in samples
            )
            values = [r["cpu_time"] for r in samples]
            q = statistics.quantiles(values, n=4, method="inclusive")
            for stat, value in [
                ("median", statistics.median(values)),
                ("p25", q[0]),
                ("p75", q[2]),
            ]:
                assert abs(float(s[f"{framework}_cpu_{stat}_ns"]) - value) < 1e-8
            assert (
                abs(
                    float(s[f"{framework}_real_median_ns"])
                    - statistics.median(r["real_time"] for r in samples)
                )
                < 1e-8
            )
    for trial in range(m["repeats"]):
        assert {r["order"] for r in records if r["trial"] == trial} == set(range(4))
    print(
        f"Verified {len(records)} samples, {len(summary)} shared cases, four frameworks, original JSON records, counters, repetitions, and medians/quartiles."
    )


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("results", type=Path)
    validate(p.parse_args().results)
